import { Component, OnInit } from '@angular/core';
import { Constants } from '../constants';
import {
  AuthService,
  FacebookLoginProvider,
  GoogleLoginProvider,
  TwitterLoginProvider
} from 'angular5-social-login';
import { ScreenTemplateJsonBuilder } from '../shared/common/screentemplate-jsonbuilder';
import { Router } from '@angular/router';
import { LoginModel } from './auth.model';
import { AuthGuardService } from '../shared/guard/auth-guard.service';
import { MatSnackBar } from '@angular/material';
import { GlobalFunctionService } from '../shared/services/global-function.service';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit {

  constructor(
    private socialAuthService: AuthService,
    private authGuardService: AuthGuardService,
    private router: Router,
    public snackBar: MatSnackBar,
    public config :Constants,
    private screenTB: ScreenTemplateJsonBuilder,
    public gfService: GlobalFunctionService
  ) {
    this.menuItems = this.screenTB.siteMenu()
    //this.socialStatus('google');
  }
  menuItems: any;
  ngOnInit() {
  }

  public socialSignIn(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform == "Facebook") {
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "Google") {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "Twitter") {
      socialPlatformProvider = TwitterLoginProvider.PROVIDER_ID;
    }

    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        let loginData = {};
        loginData['emailId'] = userData.email;
        loginData['password'] = '';
        loginData['registrationType'] = socialPlatform;
        this.loginUser(loginData);
      }
    );
  }

  private loginUser(loginData) {
    this.authGuardService.login(loginData).subscribe(resp => {
      console.log(resp);
        if (resp.status == 'success') {
          let loginData: LoginModel = new LoginModel();
          loginData.emailId = resp.data.user.emailId;
          loginData.id = resp.data.user.id;
          loginData.mobileNo = resp.data.user.mobileNo;
          loginData.name = resp.data.user.name;
          loginData.company = resp.data.user.companyName;
          loginData.tokenId = resp.data.Header.Token;
          loginData.sessionId = resp.data.Header.SessionID;
          loginData.userType = resp.data.user.userType;
          loginData.roleDetails = resp.data.roleDetails;
          loginData.globalConfiguration = resp.data.globalConfiguration;
          loginData.globalConfiguration['prefferdCurrency'] = 'AED';
          // loginData.time_to_login = Date.now() + 17280000000; // days
          loginData.loggedTime = Date.now();
          loginData.activeTime = Date.now();
          if (localStorage.getItem('currentUser')) {
            let crtData = JSON.parse(localStorage.getItem('currentUser'));
            let finalLoginData = this.gfService.JSONMerge(crtData, loginData);
            localStorage.setItem('currentUser', JSON.stringify(finalLoginData));
          } else {
            loginData.transactionId = resp.data.user.transactionId;
            localStorage.setItem('currentUser', JSON.stringify(loginData));
          }
          this.authGuardService.changeState = { isLogin: true, currentUser: loginData };
          //if(history.length > 1){
          //} else {
          this.router.navigate(['/']);
          //}
        }
        this.openSnackBar({ message: resp.message, status: resp.status });
      });
  }

  // public socialStatus(socialPlatform: string) {
  //   let socialPlatformProvider;
  //   if (socialPlatform == "facebook") {
  //     socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
  //   } else if (socialPlatform == "google") {
  //     socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
  //   } else if (socialPlatform == "twitter") {
  //     socialPlatformProvider = TwitterLoginProvider.PROVIDER_ID;
  //   }

  //   this.socialAuthService.checkStatus(socialPlatformProvider).then(
  //     (userData) => {
  //       if(userData){
  //         //this.router.navigate(['enquiry', '002'])
  //       }
  //     }
  //   );
  // }

  public socialSignUp(socialPlatform: string) {
    let socialPlatformProvider;
    if (socialPlatform == "Facebook") {
      socialPlatformProvider = FacebookLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "Google") {
      socialPlatformProvider = GoogleLoginProvider.PROVIDER_ID;
    } else if (socialPlatform == "Twitter") {
      socialPlatformProvider = TwitterLoginProvider.PROVIDER_ID;
    }

    this.socialAuthService.signIn(socialPlatformProvider).then(
      (userData) => {
        let signupData = {};
        signupData['sigupEmail'] = userData.email;
        signupData['name'] = userData.name;
        signupData['registrationType'] = socialPlatform;
        localStorage.setItem('signupUserData', JSON.stringify(signupData));
        this.router.navigate(['/registration/SignUp']);
      }
    );
  }

  onSubmit(form) {
    if (form.valid) {
      let loginData = form.value;
      loginData.registrationType = "Native";
      this.loginUser(loginData);
    }
  }

  onSignUpSubmit(form) {
    if (form.valid) {
      let signupData = form.value;
      signupData.registrationType = "Native";
      localStorage.setItem('signupUserData', JSON.stringify(signupData));
      this.router.navigate(['/registration/SignUp']);
    }
  }

  openSnackBar(snackData) {
    let message = snackData.message;
    let action = '';
    let classess;

    if (snackData.status == 'success') {
      classess = 'success';
    } else if (snackData.status == 'error') {
      classess = 'error';
    } else {
      classess = 'warn';
    }

    this.snackBar.open(message, action, {
      duration: 2000,
      extraClasses: [classess]
    });
  }

}
