export class LoginModel{
    sessionId: string;
    tokenId: string;
    emailId: string;
    id: number;
    mobileNo: number;
    name: string;
    transactionId: string;
    company: string;
    userType:string;
    roleDetails: JSON;
    globalConfiguration:any;
    loggedTime:number;
    activeTime:number;
}