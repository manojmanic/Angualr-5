import { Injectable } from '@angular/core';
import { Http, Headers, Response } from "@angular/http";
import { GlobalformService } from '../services/globalform.service';
import { Observable } from 'rxjs/Rx';
import { ReactiveFormsModule, FormBuilder, FormControl, FormControlDirective, FormControlName, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
import { retry } from 'rxjs/operators/retry';
import { Router, ActivatedRoute } from '@angular/router';

// const originFormControlNgOnChanges = FormControlDirective.prototype.ngOnChanges;
// FormControlDirective.prototype.ngOnChanges = function () {
//   if ((this.valueAccessor).hasOwnProperty('_elementRef') && (this.valueAccessor._elementRef).hasOwnProperty('nativeElement')) {
//     this.form.nativeElement = this.valueAccessor._elementRef.nativeElement;
//     return originFormControlNgOnChanges.apply(this, arguments);
//   }
//   return false;
// };

// const originFormControlNameNgOnChanges = FormControlName.prototype.ngOnChanges;
// FormControlName.prototype.ngOnChanges = function () {
//   const result = originFormControlNameNgOnChanges.apply(this, arguments);
//   if ((this.valueAccessor).hasOwnProperty('_elementRef') && (this.valueAccessor._elementRef).hasOwnProperty('nativeElement')) {
//     this.control.nativeElement = this.valueAccessor._elementRef.nativeElement;
//     return result;
//   }
//   return false;
// };

@Injectable()
export class FormBuildFunctionsService {
  private returnData: any = {};
  private componentMethodCallSource = new Subject<any>();
  invokeEvent: Subject<any> = new Subject();

  callComponent(value) {
    this.invokeEvent.next({ some: 'aaaaa' })
  }

  constructor(private http: Http, private globalFormService: GlobalformService, private router: Router) {
  }

  //////////// FormView Function //////////////////
  enquiryAddBefore(form) {
    return form;
  }

  enquiryAddAfter(form) {
    let enqCountry = localStorage.getItem('country_selection_others');
    form.formItems.patchValue({ hostCountry: enqCountry });
    return form;
  }

  enquiryAddSubmit(form) {
    if (form.route.snapshot.url[0].path === 'enquiry' && form.formItems.valid) {
      localStorage.removeItem('country_selection_others');
      this.router.navigate(['/enquirySucess']);
    }
    return form;
  }

  registrationAddAfter(form) {
    let lsSignUpData = JSON.parse(localStorage.getItem('signupUserData'));
    if(lsSignUpData != null){
      form.formItems.patchValue({ emailId: lsSignUpData.sigupEmail });
      form.formItems.patchValue({ contactPerson: lsSignUpData.name });
    }
    return form;
  }

  registrationAddSubmit(form) {

    if (form.formItems.valid) {
      let lsSignUpData = JSON.parse(localStorage.getItem('signupUserData'));
      if(lsSignUpData != null){
        form.formItems.value['registrationType'] = lsSignUpData.registrationType;
        localStorage.removeItem('signupUserData');
      }
      for (var menu of form.menuItems) {
        if (menu.mTitle === 'Password Settings') {
          this.router.navigate([menu.mPath + '/' + menu.caseId]);
        }
      }
    }
    return form;
  }

  visaViewBefore(form) {
    return form;
  }

  visaViewAfter(form) {
    return form;
  }

  hostLocViewBefore(form) {
    return form;
  }

  hostLocViewAfter(form) {
    return form;
  }

  docMasterViewBefore(form) {
    return form;
  }

  docMasterViewAfter(form) {
    return form;
  }

  rateCardViewBefore(form) {
    return form;
  }

  rateCardViewAfter(form) {
    return form;
  }

  visaListBefore(form) {
    return form;
  }

  visaListAfter(form) {
    return form;
  }

  hostLocListBefore(form) {
    return form;
  }

  hostLocListAfter(form) {
    return form;
  }

  docMasterListBefore(form) {
    return form;
  }

  docMasterListAfter(form) {
    return form;
  }

  rateCardListBefore(form) {
    return form;
  }

  rateCardListAfter(form) {
    return form;
  }

  resourceAddBefore(form) {
    return form;
  }

  resourceAddAfter(form) {
    return form;
  }

  visaAddBefore(form) {
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    let finalData;
    let subscriptionComplete = false;

    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'country' && (arrData.fieldType == 'termsReferenceList' || arrData.fieldType == 'customList')) {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'documentChecklist' && arrData.fieldType == 'customMultiSelectOptions') {
          let data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data)
            .subscribe(resp => {
              arrData.additionalMetaData = Object.keys(resp.data).map(key => ({ key, value: resp.data[key] }));
            });
        }
        else {
          arrData.additionalMetaData = [];
        }
      });
    });
    return form;
  }

  visaAddAfter(form) {
    return form;
  }

  hostCountryAddBefore(form) {
    const eventCalls = this.globalFormService;
    
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'country' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'country' && arrData.fieldType == 'customList') {
        let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    return form;
  }

  hostCountryAddAfter(form) {
    // let countryField = form.formItems.get('country');
    // countryField.valueChanges.subscribe(resp => {
    //   let countryName = <HTMLElement>document.querySelector('#countryName');
    //   let noOfResource = <HTMLElement>document.querySelector('#noOfResource');
    //   let projectStatus = <HTMLElement>document.querySelector('#projectStatus');
    //   let projectDomain = <HTMLElement>document.querySelector('#projectDomain');
    //   let endClient = <HTMLElement>document.querySelector('#endClient');
    //   let workLocation = <HTMLElement>document.querySelector('#workLocation');
    //   let projectType = <HTMLElement>document.querySelector('#projectType');
    //   if (resp == '10') {
    //     countryName.hidden = false;
    //     noOfResource.hidden = true;
    //     projectStatus.hidden = true;
    //     projectDomain.hidden = true;
    //     endClient.hidden = true;
    //     workLocation.hidden = true;
    //     projectType.hidden = true;
    //     form.formItems.get('countryName').setValidators([Validators.required]);
    //     form.formItems.get('noOfResource').setValidators(null);
    //     form.formItems.get('projectStatus').setValidators(null);
    //     form.formItems.get('projectDomain').setValidators(null);
    //     form.formItems.get('endClient').setValidators(null);
    //     form.formItems.get('workLocation').setValidators(null);
    //     form.formItems.get('projectType').setValidators(null);
    //     form.formItems.get('countryName').updateValueAndValidity();
    //     form.formItems.get('noOfResource').updateValueAndValidity();
    //     form.formItems.get('projectStatus').updateValueAndValidity();
    //     form.formItems.get('projectDomain').updateValueAndValidity();
    //     form.formItems.get('endClient').updateValueAndValidity();
    //     form.formItems.get('workLocation').updateValueAndValidity();
    //     form.formItems.get('projectType').updateValueAndValidity();
    //   } else {
    //     countryName.hidden = true;
    //     noOfResource.hidden = false;
    //     projectStatus.hidden = false;
    //     projectDomain.hidden = false;
    //     endClient.hidden = false;
    //     workLocation.hidden = false;
    //     projectType.hidden = false;
    //     form.formItems.get('countryName').setValidators(null);
    //     form.formItems.get('noOfResource').setValidators([Validators.required]);
    //     form.formItems.get('projectStatus').setValidators([Validators.required]);
    //     form.formItems.get('projectDomain').setValidators([Validators.required]);
    //     form.formItems.get('endClient').setValidators([Validators.required]);
    //     form.formItems.get('workLocation').setValidators([Validators.required]);
    //     form.formItems.get('projectType').setValidators([Validators.required]);
    //     form.formItems.get('countryName').updateValueAndValidity();
    //     form.formItems.get('noOfResource').updateValueAndValidity();
    //     form.formItems.get('projectStatus').updateValueAndValidity();
    //     form.formItems.get('projectDomain').updateValueAndValidity();
    //     form.formItems.get('endClient').updateValueAndValidity();
    //     form.formItems.get('workLocation').updateValueAndValidity();
    //     form.formItems.get('projectType').updateValueAndValidity();
    //   }
    // });
  }

  hostCountryAddSubmit(form) {
    if (form.route.snapshot.url[0].path === 'country-selection' && form.formItems.valid) {
      if ((form.formItems.get('country').value) == '10') {
        for (var menu of form.menuItems) {
          if (menu.mTitle === 'Enquiry') {
            localStorage.setItem('country_selection_others', (form.formItems.get('countryName').value));
            this.router.navigate([menu.mPath + '/' + menu.caseId]);
          }
        }
      }
      else {

        let servicedCountry = {
          country: form.formItems.get('country').value,
          // countryName: this.form.get('countryName').value,
          endClient: form.formItems.get('endClient').value,
          noOfResource: form.formItems.get('noOfResource').value,
          projectDomain: form.formItems.get('projectDomain').value,
          projectStatus: form.formItems.get('projectStatus').value,
          projectType: form.formItems.get('projectType').value,
          workLocation: form.formItems.get('workLocation').value,
        };
        localStorage.setItem("servicedCountry", JSON.stringify(servicedCountry));
        for (var menu of form.menuItems) {
          if (menu.mTitle === 'Registration') {
            this.router.navigate([menu.mPath + '/' + menu.caseId]);
          }
        }
      }
    }
    return form;
  }


  requirementAddBefore(form) {
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'country' && arrData.fieldType == 'termsReferenceList') {
        let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
  }
  requirementAddAfter(form) {
    let countryField = form.formItems.get('country');
    countryField.valueChanges.subscribe(resp => {
      let currentControl = <HTMLElement>document.querySelector('#photoBgColor');
      if (resp == '13') {
        currentControl.hidden = false;
      } else {
        currentControl.hidden = true;
      }
    });
    // form.formItems.patchValue({country:additionalMetaData[1]});
    //form.formItems.patchValue({ visaName: "ff" });
  }
  hostLocAddBefore(form) {
    return form;
  }
  hostLocAddAfter(form) {
    return form;
  }
  docMasterAddBefore(form) {
    return form;
  }
  docMasterAddAfter(form) {
    return form;
  }
  rateCardAddBefore(form) {
    return form;
  }
  rateCardAddAfter(form) {
    return form;
  }
  ///////////////// FormEdit Function ///////////////
  visaEditBefore(form) {
      const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    let finalData;
    let subscriptionComplete = false;

    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'country' && (arrData.fieldType == 'termsReferenceList' || arrData.fieldType == 'customList')) {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'documentChecklist' && arrData.fieldType == 'customMultiSelectOptions') {
          let data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'documentChecklist' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            
            // this.invokeEvent.next({ some: form });
            // alert();
          });
        }
        else if (arrData.fieldColumn == 'countrySimpleMulti' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            
            // this.invokeEvent.next({ some: form });
            // alert();
          });
        }
        
        else if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data)
            .subscribe(resp => {
             // arrData.additionalMetaData = Object.keys(resp.data).map(key => ({ key, value: resp.data[key] }));
              Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            });
        }
        else {
          arrData.additionalMetaData = [];
        }
      });
    });
    return form;
  }
  visaEditAfter(form) {
    return form;
  }
  hostLocEditBefore(form) {
    return form;
  }
  hostLocEditAfter(form) {
    return form;
  }
  docMasterEditBefore(form) {
    return form;
  }
  docMasterEditAfter(form) {
    return form;
  }
  rateCardEditBefore(form) {
    return form;
  }
  rateCardEditAfter(form) {
    return form;
  }




  simpleAddVisaAfter(form) {
    form.formItems.patchValue({ visaName: 'Anish' });
    let data = { "tableName": "Country", "keyValue": "dataId, countryName" };

  }

}
