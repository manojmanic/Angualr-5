import { Injectable } from '@angular/core';
import { AuthGuardService } from '../guard/auth-guard.service';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
@Injectable()
export class AccessControlFunctions {

  role:any;
  constructor(
    private snackBar: MatSnackBar,
    private router: Router,
    private state: ActivatedRoute
  ) {

  }

  canActivate(loginState, userDetails, url): boolean {
    if (loginState) {
       this.role = userDetails.roleDetails;
      if (userDetails.userType == "FFI") {
        
        if (this.role.Permissions.includes('DYADD1')) {
          if (url.match(/(formAdd\/VisaMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYADD2')) {
          if (url.match(/(formAdd\/HostLocationMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYADD3')) {
          if (url.match(/(formAdd\/DocumentMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYADD4')) {
          if (url.match(/(formAdd\/AddOnServiceMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYADD9')) {
          if (url.match(/(formAdd\/TermMaster)/)) {
            return true;
          }
        }
        
        if (this.role.Permissions.includes('DYADD10')) {
          if (url.match(/(formAdd\/VisaPartnerMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYADD19')) {
          if (url.match(/(formAdd\/InsuranceMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYADD20')) {
          if (url.match(/(formAdd\/CurrencyMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD1')) {
          if (url.match(/(FormEdit\/VisaMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD2')) {
          if (url.match(/(FormEdit\/HostLocationMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD3')) {
          if (url.match(/(FormEdit\/DocumentMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD4')) {
          if (url.match(/(FormEdit\/AddOnServiceMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD9')) {
          if (url.match(/(FormEdit\/TermMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD10')) {
          if (url.match(/(FormEdit\/VisaPartnerMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD20')) {
          if (url.match(/(FormEdit\/CurrencyMaster)/)) {
            return true;
          }
        }

        if (this.role.Permissions.includes('DYUPD19')) {
          if (url.match(/(FormEdit\/InsuranceMaster)/)) {
            return true;
          }
        }
        if (this.role.Permissions.includes('LIST')) {
          if (url.match(/(total-list)/)) {
            return true;
          }
        }
        if (url.match(/(users|visa|host-location|document|rate-card|term|visapartner-list|insurance-list|view-contract|single-contract|quotation|currency-list)/)) {
          return true;
        }
       
        else if (url.match(/(country-selection)/)) {
          this.openSnackBar("This Requirement page is not accessable for you.", "");
          return false;
        }
        else if (url.match(/(submit-requirement)/)) {
          this.openSnackBar("This SubmitRequirement page is not accessable for you.", "");
          return false;
        }
        else if(url.match(/(total-list)/)){
          this.openSnackBar("Not Accessable for your role","");
          return false;
        }

        this.openSnackBar("Form Add/Edit is Not Accessable for your role .", "");
        return false;
      } else {

        if (url.match(/(visa|host-location|document|rate-card|term|insurance-list|visapartner-list|currency-list)/)) {
          this.openSnackBar("Masters Screens are not accessable for your role.", "");
          return false;
        }
        else if (url.match(/(users)/)) {
          this.openSnackBar("Admin only access this page.", "");
          return false;
        }

        if (userDetails.hasOwnProperty('transactionId') && url.match(/(country-selection)/)) {
          this.router.navigate(['/submit-requirement/submit-requirement']);
          this.openSnackBar("Requirement selection is already done. Please go to SubmitRequirements.", "");
          return false;
        }

        return true;
      }


    } else {

      if (url.match(/(signin|registration|enquiry|country-selection|password-settings)/)) {
        if (userDetails != null) {
          if (!userDetails.hasOwnProperty('transactionId')) {
            return true;
          }
          if (url.match(/(country-selection)/)) {
            this.openSnackBar("Country selection is already done. Please go to Requirements.", "(submit-requirement)");
            return false;
          }
        }
        return true;
      }

      this.openSnackBar("This page is not accessable for you.", "");
      return false;
    }
      //  return true;
  }

  canLoad(loginState): boolean {
    if (loginState)
      return true;

    return false;
  }

  canDeactivate(loginState): boolean {
    if (loginState)
      return true;

    return false;
  }

  canActivateChild() {

  }

  DeactivatePermissioncode( loginState,userDetails,url) {
    if (loginState) {
       this.role = userDetails.roleDetails;
      if (userDetails.userType == "FFI") {
        if (url.match(/(visa\/VisaMaster)/)) {
          if (this.role.Permissions.includes('DYDEL1')) {
            return true;
          }
        }
        if (url.match(/(host-location\/HostLocationMaster)/)) {
          if (this.role.Permissions.includes('DYDEL2')) {
            return true;
          }
        }
        if (url.match(/(document\/DocumentMaster)/)) {
          if (this.role.Permissions.includes('DYDEL3')) {
            return true;
          }
        }
        if (url.match(/(rate-card\/AddOnServiceMaster)/)) {
          if (this.role.Permissions.includes('DYDEL4')) {
            return true;
          }
        }
        if (url.match(/(term\/TermMaster)/)) {
          if (this.role.Permissions.includes('DYDEL9')) {
            return true;
          }
        }
        if (url.match(/(insurance-list\/InsuranceMaster)/)) {
          if (this.role.Permissions.includes('DYDEL19')) {
            return true;
          }
        }
        if (url.match(/(currency-list\/CurrencyMaster)/)) {
          if (this.role.Permissions.includes('DYDEL20')) {
            return true;
          }
        }
        if (url.match(/(visapartner-list\/VisaPartnerMaster)/)) {
          if (this.role.Permissions.includes('DYDEL10')) {
            return true;
          }
        }
        if (url.match(/(users\/permission)/)) {
          if (this.role.Permissions.includes('CEUSER')) {
            return true;
          }
        }
        if (url.match(/(users\/permission)/)) {
          if (this.role.Permissions.includes('DROLE')) {
            return true;
          }
        }

        return false;

      }

      return false;

    }

    return true;
  }

  createRole(loginState, userDetails, url) {
    if (loginState) {
       this.role = userDetails.roleDetails;
      if (url.match(/(users\/permission)/)) {
        if (this.role.Permissions.includes('CEROLE')) {
          return true;
        }
      }

      return false;
    }

    return true;
  }

  PermissionDeactivate(loginState,userDetails,url) {
           if (loginState) {
            this.role = userDetails.roleDetails;
            if (url.match(/(users\/permission)/)) {
                if (this.role.Permissions.includes('ARPER')) {
                    return true;
                }
            }

            return false;
        }

        return true;
  }



  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
      extraClasses: ['error']
    });
  }
}