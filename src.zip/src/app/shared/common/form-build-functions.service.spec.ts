import { TestBed, inject } from '@angular/core/testing';

import { FormBuildFunctionsService } from './form-build-functions.service';

describe('FormBuildFunctionsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FormBuildFunctionsService]
    });
  });

  it('should be created', inject([FormBuildFunctionsService], (service: FormBuildFunctionsService) => {
    expect(service).toBeTruthy();
  }));
});
