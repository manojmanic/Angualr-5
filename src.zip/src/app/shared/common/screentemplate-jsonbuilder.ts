import { ScreenTemplateBuilder } from '../common/screentemplate-builder';

export class ScreenTemplateJsonBuilder extends ScreenTemplateBuilder {
  options: Object;
  siteMenus: any;
  formView(formId) {
    switch (formId) {
      case 'VisaMaster': {
        this.options = {
          title: 'View',
          formId: 1,
          filterString: {},
          eventHandler: {
            'preBuild': "visaViewBefore",
            'postBuild': "visaViewAfter",
            'preSubmit': "",
          },
          showFields: [
            'country',
            'countrySimpleMulti',
            'visaName',
            'visaDescription',
            'entryValidity',
            'stayValidity',
            'multipleEntries',
            'extendable',
            'photoBgColor',
            'photoBgColorMulti',
            'documentChecklist',
            'quoteComponents',
            'visaCost',
            'addons',
            'extendableDuration',
            'visitType'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'HostLocationMaster': {
        this.options = {
          title: 'View',
          formId: 2,
          filterString: {},
          eventHandler: {
            'preBuild': "hostLocViewBefore",
            'postBuild': "hostLocViewAfter",
            'preSubmit': "",
          },
          showFields: [
            'countryCode',
            'currency',
            'flagImage',
            'countryName',
            //'servicedStatus',
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'WorkLocationMaster': {
        this.options = {
          title: 'View',
          formId: 30,
          filterString: {},
          eventHandler: {
            'preBuild': "workLocViewBefore",
            'postBuild': "workLocViewAfter",
            'preSubmit': "",
          },
          showFields: [
            //'country',
            'locationName'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'DocumentMaster': {
        this.options = {
          title: 'View',
          formId: 3,
          filterString: {},
          eventHandler: {
            'preBuild': "docMasterViewBefore",
            'postBuild': "docMasterViewAfter",
            'preSubmit': "",
          },
          showFields: [
            'documentName',
            'description',
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'AddOnServiceMaster': {
        this.options = {
          title: 'View',
          formId: 4,
          filterString: {},
          eventHandler: {
            'preBuild': "rateCardViewBefore",
            'postBuild': "rateCardViewAfter",
            'preSubmit': "",
          },
          showFields: [
            'rateCardType',
            'country',
            'visaTypeIfAny',
            'termsCondition',
            'vendorName',
            'planNameIfAny',
            'rate',
            'name',
            'notes'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'TermMaster': {
        this.options = {
          title: 'View',
          formId: 9,
          filterString: {},
          eventHandler: {
            'preBuild': "termViewBefore",
            'postBuild': "termViewAfter",
            'preSubmit': "termViewSubmit",
          },
          showFields: [
            'termSetId',
            'term',

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'InsuranceMaster': {
        this.options = {
          title: 'View',
          formId: 19,
          filterString: {},
          eventHandler: {
            'preBuild': "insuranceViewBefore",
            'postBuild': "insuranceViewAfter",
            'preSubmit': "insuranceViewSubmit",
          },
          showFields: [
            'planName',
            'validityInDays'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'CurrencyMaster': {
        this.options = {
          title: 'View',
          formId: 20,
          filterString: {},
          eventHandler: {
            'preBuild': "currencyViewBefore",
            'postBuild': "currencyViewAfter",
            'preSubmit': "currencyViewSubmit",
          },
          showFields: [
            'currencyCode',
            'currencySymbol'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'VisaPartnerMaster': {
        this.options = {
          title: 'View',
          formId: 10,
          filterString: {},
          eventHandler: {
            'preBuild': "visaPartnerViewBefore",
            'postBuild': "visaPartnerViewAfter",
            'preSubmit': "visaPartnerViewSubmit",
          },
          showFields: [
            'country',
            'name',
            //'contactPerson',
            //'phoneNumber',
            //'address',
            //'emailId'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'PartnerVisaRateMaster': {
        this.options = {
          title: 'View',
          formId: 26,
          filterString: {},
          eventHandler: {
            'preBuild': "partnerVisaRateViewBefore",
            'postBuild': "partnerVisaRateViewAfter",
            'preSubmit': "partnerVisaRateViewSubmit",
          },
          showFields: [
            'visaType',
            'rate'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'Resource': {
        this.options = {
          title: 'Resource',
          formId: 5,
          filterString: {},
          eventHandler: {
            'preBuild': "resourceViewBefore",
            'postBuild': "resourceViewAfter",
            'preSubmit': "resourceViewSubmit",
          },
          showFields: [
            'visaType',
            'durationOfAssignment',
            'resNationality',
            'extensionLikely',
            'onboardingBy',
            // 'addonServices',
            // 'noOfDependents',
            'visitType',
            // 'salary',
            'remarks'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'submit-requirement': {
        this.options = {
          title: 'Requirement - Secondment',
          formId: '',
          filterString: {},
          eventHandler: {
            'preBuild': "submitRequirementBefore",
            'postBuild': "submitRequirementAfter",
            'preSubmit': "",
          },
          showFields: [
           
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'requirementDetails': {
        this.options = {
          title: 'Requirement Details',
          formId: 7,
          filterString: {},
          eventHandler: {
            'preBuild': "requirementDetailsViewBefore",
            'postBuild': "requirementDetailsViewAfter",
            'preSubmit': "",
          },
          showFields: [
           'country',
          //  'countryName',
           'endClient',
           'noOfResource',
           'projectDomain',
           'projectStartDate',
           'projectStatus',
           'projectType',
           'workLocation'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'viewQuotation': {
        this.options = {
          title: 'Quotation',
          formId: '',
          filterString: {},
          eventHandler: {
            'preBuild': "viewQuotationViewBefore",
            'postBuild': "viewQuotationViewAfter",
            'preSubmit': "",
          },
          showFields: [
            'quoteNo',
            'contactPerson',
            'country',
            'noOfResource',
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
        };
        break;
      };
      case 'viewQuotationResource': {
        this.options = {
          title: 'Quotation',
          formId: '',
          filterString: {},
          eventHandler: {
            'preBuild': "viewQuotationResourceViewBefore",
            'postBuild': "viewQuotationResourceViewAfter",
            'preSubmit': "",
          },
          showFields: [
            'addonServices',
            'visaAmount',
            'totalAmount',
            'taxAmount',
            'subTotal',
            'leaveSalary',
            'endOfServiceBenefit',
            'passportStampingCost',
            'bonus',
            'singleExit'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
        };
        break;
      };
      case 'viewQuotationResourceVisa': {
        this.options = {
          title: 'Quotation',
          formId: '',
          filterString: {},
          eventHandler: {
            'preBuild': "viewQuotationResourceVisaViewBefore",
            'postBuild': "viewQuotationResourceVisaViewAfter",
            'preSubmit': "",
          },
          showFields: [
            'visaName',
            'entryValidity',
            'stayValidity',
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
        };
        break;
      };
      case 'viewContract': {
        this.options = {
          title: 'Contract',
          formId: 11,
          filterString: {},
          eventHandler: {
            'preBuild': "viewContractBefore",
            'postBuild': "viewContractAfter",
            'preSubmit': "",
          },
          showFields: [
            'country',
            'noOfResource',
            'workLocation'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'document': {
        this.options = {
          title: 'Documents',
          formId: 1,
          filterString: {},
          eventHandler: {
            'preBuild': "viewDocumentsBefore",
            'postBuild': "viewDocumentsAfter",
            'preSubmit': "",
          },
          showFields: [
            '1',
            '2',
            '3',
            '4',
            '5',
            '6',
            '7',
            '8',
            '9',
            '10',
            '11',
            '12',
            '13',
            '14',
            '15',
            '16'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'payment': {
        this.options = {
          title: 'Payment',
          formId: 1,
          filterString: {},
          eventHandler: {
            'preBuild': "paymentViewBefore",
            'postBuild': "paymentViewAfter",
            'preSubmit': "",
          },
          showFields: [

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'secondmentList': {
        this.options = {
          title: 'Secondment List',
          formId: 1,
          filterString: {},
          eventHandler: {
            'preBuild': "secondmentViewBefore",
            'postBuild': "secondmentViewAfter",
            'preSubmit': "",
          },
          showFields: [

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'contractResource': {
        this.options = {
          title: 'Resource',
          formId: 12,
          filterString: {},
          eventHandler: {
            'preBuild': "",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'visaType',
            'resNationality',
            'onboardingBy',
            'emailId',
            'mobileNo',
            'noOfDependents'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'personalDetails': {
        this.options = {
          title: 'Resource',
          formId: 18,
          filterString: {},
          eventHandler: {
            'preBuild': "personalDetailsViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'bloodGroup',
            'emailId',
            'emergencyContact',
            'firstName',
            'gender',
            'lastName',
            'mobileNo',
            'permanentAddress',
            'proflePic',
            'residentialAddress',
            'localId'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'singleResource': {
        this.options = {
          title: 'Resource',
          formId: 11,
          filterString: {},
          eventHandler: {
            'preBuild': "singleResourceViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
           'visaType',
           'resNationality',
           'emailId',
           'durationOfAssignment'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'contractDependent': {
        this.options = {
          title: 'Dependent',
          formId: 13,
          filterString: {},
          eventHandler: {
            'preBuild': "",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
           'depNationality',
           'relationship',
           'dGender',
           'dVisaNumber',
           'passportNo',
           'validTill',
           'issuedOn',
           'issuedLocation'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'PassportDetails': {
        this.options = {
          title: 'Passport',
          formId: 14,
          filterString: {},
          eventHandler: {
            'preBuild': "PassportDetailsViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'passportNo'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };

      case 'PreviousPassport': {
        this.options = {
          title: 'PreviousPassport',
          formId: 27,
          filterString: {},
          eventHandler: {
            'preBuild': "previousPassportViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'passportNo',
            'validTill'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      
      case 'TravelDetails': {
        this.options = {
          title: 'Travel Details',
          formId: 15,
          filterString: {},
          eventHandler: {
            'preBuild': "TravelDetailsViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            //'travelDate',
            'fromLocation',
            'toLocation',
            'travelDateTime',
            'arrivalDateTime',
            'airline',
            'ticketNumber',
            'okayToBoardRecipt'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'ProfessionalDetails': {
        this.options = {
          title: 'Professional Details',
          formId: 22,
          filterString: {},
          eventHandler: {
            'preBuild': "ProfessionalDetailsViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'resume',
            'clientName',
            'endClientName',
            'experience',
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };

      case 'PreviousCompanyDetails': {
        this.options = {
          title: 'PreviousCompany Details',
          formId: 28,
          filterString: {},
          eventHandler: {
            'preBuild': "previousCompanyDetailsViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'companyName',
            'role',
            'experience',
            'fromDate',
            'toDate'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };

      case 'VisaDetails': {
        this.options = {
          title: 'Visa Details',
          formId: 23,
          filterString: {},
          eventHandler: {
            'preBuild': "VisaDetailsViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'entryValidity',
            'stayValidity',
            'visaNumber',
            'visaValidUpto',
            'visaPartner'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'OnBoardingDetails': {
        this.options = {
          title: 'OnBoarding Details',
          formId: 24,
          filterString: {},
          eventHandler: {
            'preBuild': "OnBoardingDetailsViewBefore",
            'postBuild': "",
            'preSubmit': "",
          },
          showFields: [
            'medicalTestLocation',
            'medicalInsuranceValidity',
            'medicalTestDateTime',
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
        };
        break;
      };
      case 'tnc': {
        this.options = {
          title: 'Terms & Conditions',
          formId: '',
          filterString: {},
          eventHandler: {
            'preBuild': "tncViewBefore",
            'postBuild': "tncViewAfter",
            'preSubmit': "",
          },
          showFields: [
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
        };
        break;
      };
    }
    return super.formView(this.options);
  }

  formAdd(formId) {
    switch (formId) {
      case 'VisaMaster': {
        this.options = {
          title: 'Add',
          formId: 1,
          filterString: {},
          eventHandler: {
            'preBuild': "visaAddBefore",
            'postBuild': "visaAddAfter",
            'preSubmit': "visaAddSubmit",
          },
          showFields: [
            'country',
            'countrySimpleMulti',
            'visaName',
            'visaDescription',
            'entryValidity',
            'stayValidity',
            'multipleEntries',
            'extendable',
            'photoBgColor',
            'photoBgColorMulti',
            'documentChecklist',
            'visaCost',
            'addons',
            'quoteComponents',
            //'extendableDuration',
            'visaValidity',
            'dependentsAllowed',
            'visitType',
            'preferredVisaPartner',
            'passportStampingCost'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'HostLocationMaster': {
        this.options = {
          title: 'Add',
          formId: 2,
          filterString: {},
          eventHandler: {
            'preBuild': "hostLocAddBefore",
            'postBuild': "hostLocAddAfter",
            'preSubmit': "hostLocAddSubmit",
          },
          showFields: [
            'countryCode',
            'currency',
            'flagImage',
            'countryName',
            //'servicedStatus',

          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'WorkLocationMaster': {
        this.options = {
          title: 'Add',
          formId: 30,
          filterString: {},
          eventHandler: {
            'preBuild': "workLocAddBefore",
            'postBuild': "workLocAddAfter",
            'preSubmit': "workLocAddSubmit",
          },
          showFields: [
            //'country',
            'locationName'

          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'DocumentMaster': {
        this.options = {
          title: 'Add',
          formId: 3,
          filterString: {},
          eventHandler: {
            'preBuild': "docMasterAddBefore",
            'postBuild': "docMasterAddAfter",
            'preSubmit': "docMasterAddSubmit",
          },
          showFields: [
            'documentName',
            'description',
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'AddOnServiceMaster': {
        this.options = {
          title: 'Add',
          formId: 4,
          filterString: {},
          eventHandler: {
            'preBuild': "rateCardAddBefore",
            'postBuild': "rateCardAddAfter",
            'preSubmit': "rateCardAddSubmit",
          },
          showFields: [
            'rateCardType',
            'country',
            'visaTypeIfAny',
            'termsCondition',
            'vendorName',
            'planNameIfAny',
            'rate',
            'name',
            'notes'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'VisaPartnerMaster': {
        this.options = {
          title: 'Add',
          formId: 10,
          filterString: {},
          eventHandler: {
            'preBuild': "visaPartnerAddBefore",
            'postBuild': "visaPartnerAddAfter",
            'preSubmit': "visaPartnerAddSubmit",
          },
          showFields: [
            'country',
            'name',
            'contactPerson',
            'phoneNumber',
            'address',
            'emailId'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'PartnerVisaRateMaster': {
        this.options = {
          title: 'Add',
          formId: 26,
          filterString: {},
          eventHandler: {
            'preBuild': "partnerVisaRateAddBefore",
            'postBuild': "partnerVisaRateAfter",
            'preSubmit': "partnerVisaRateSubmit",
          },
          showFields: [
            'visaType',
            'rate'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Requirement': {
        this.options = {
          title: 'Requirement - Secondment',
          formId: 7,
          filterString: {},
          eventHandler: {
            'preBuild': "hostCountryAddBefore",
            'postBuild': "hostCountryAddAfter",
            'preSubmit': "hostCountryAddSubmit",
          },
          showFields: [
            'country'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Enquiry': {
        this.options = {
          title: 'Enquiry',
          formId: 6,
          filterString: {},
          eventHandler: {
            'preBuild': "enquiryAddBefore",
            'postBuild': "enquiryAddAfter",
            'preSubmit': "enquiryAddSubmit",
          },
          showFields: [
            'hostCountry',
            'contactPerson',
            'phoneNumber',
            'workLocation',
            'companyName',
            'noOfResource',
            'projectType',
            'stayValidity',
            'contactEmailId',
            'projectStatus',
            'projectDomain',
            'preferredTimetoCall',
            'contactPersonLocation',
            'notes',
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'SignUp': {
        this.options = {
          title: 'Sign Up',
          formId: 8,
          filterString: {},
          eventHandler: {
            'preBuild': "registrationAddBefore",
            'postBuild': "registrationAddAfter",
            'preSubmit': "registrationAddSubmit",
          },
          showFields: [
            'companyName',
            'emailId',
            'operationLocation',
            'companySize',
            'websiteURL',
            'contactPerson',
            'yrsOfExistence',
            'typeOfBusiness',
            'linkedInHandle',
            'contactEmail',
            'contactPhone',
            'alternatePhone',
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Resource': {
        this.options = {
          title: 'Resource',
          formId: 5,
          filterString: {},
          eventHandler: {
            'preBuild': "resourceAddBefore",
            'postBuild': "resourceAddAfter",
            'preSubmit': "resourceAddSubmit",
          },
          showFields: [
            'visaType',
            'durationOfAssignment',
            'resNationality',
            'extensionLikely',
            'onboardingBy',
            'addonServices',
            // 'noOfDependents',
            'currentLocation',
            'visitType',
            // 'salary',
            'remarks'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Dependent': {
        this.options = {
          title: 'Dependent - Add',
          formId: 13,
          filterString: {},
          eventHandler: {
            'preBuild': "dependentAddBefore",
            'postBuild': "dependentAddAfter",
            'preSubmit': "dependentAddSubmit",
          },
          showFields: [
            'dBloodGroup',
            'depNationality',
            'relationship',
            'dFirstName',
            'dLastName',
            'dGender',
            'dVisaNumber',
            'dVisaValidUpto',
            'gender',
            'passportTillValid',
            'dateOfBirth',
            'dProflePic',
            'passportNo',
            'validTill',
            'issuedOn',
            'issuedLocation'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Passport': {
        this.options = {
          title: 'Passport - Add',
          formId: 14,
          filterString: {},
          eventHandler: {
            'preBuild': "passportAddBefore",
            'postBuild': "passportAddAfter",
            'preSubmit': "passportAddSubmit",
          },
          showFields: [
           'passportNo',
           'issuedOn',
           'previousPassports',
           'issuedLocation',
           'validTill'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'PreviousPassport': {
        this.options = {
          title: 'Previous Passport - Add',
          formId: 27,
          filterString: {},
          eventHandler: {
            'preBuild': "previousPassportAddBefore",
            'postBuild': "previousPassportAddAfter",
            'preSubmit': "previousPassportAddSubmit",
          },
          showFields: [
            'passportNo',
            'validTill'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'TravelDetails': {
        this.options = {
          title: 'Travel Details - Add',
          formId: 15,
          filterString: {},
          eventHandler: {
            'preBuild': "travelDetailsAddBefore",
            'postBuild': "travelDetailsAddAfter",
            'preSubmit': "travelDetailsAddSubmit",
          },
          showFields: [
           'fromLocation',
           'toLocation',
           'travelDate',
           'travelDateTime',
           'arrivalDateTime',
           'airline',
           'ticketNumber',
           'okayToBoardRecipt'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'ProfessionalDetails': {
        this.options = {
          title: 'Professional Details - Add',
          formId: 14,
          filterString: {},
          eventHandler: {
            'preBuild': "professionalDetailsAddBefore",
            'postBuild': "professionalDetailsAddAfter",
            'preSubmit': "professionalDetailsAddSubmit",
          },
          showFields: [
           'passportNo',
           'issuedOn',
           'previousPassports',
           'issuedLocation',
           'validTill'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'PreviousCompanyDetails': {
        this.options = {
          title: 'PreviousCompany Details - Add',
          formId: 28,
          filterString: {},
          eventHandler: {
            'preBuild': "previousCompanyDetailsAddBefore",
            'postBuild': "previousCompanyDetailsAddAfter",
            'preSubmit': "previousCompanyDetailsAddSubmit",
          },
          showFields: [
            'companyName',
            'role',
            'experience',
            'fromDate',
            'toDate'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'VisaDetails': {
        this.options = {
          title: 'Visa Details - Add',
          formId: 14,
          filterString: {},
          eventHandler: {
            'preBuild': "VisaDetailsAddBefore",
            'postBuild': "VisaDetailsAddAfter",
            'preSubmit': "VisaDetailsAddSubmit",
          },
          showFields: [
            'entryValidity',
            'stayValidity',
            'visaNumber',
            'visaValidUpto',
            'visaPartner'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'OnBoardingDetails': {
        this.options = {
          title: 'OnBoarding Details - Add',
          formId: 24,
          filterString: {},
          eventHandler: {
            'preBuild': "onBoardingDetailsAddBefore",
            'postBuild': "onBoardingDetailsAddAfter",
            'preSubmit': "onBoardingDetailsAddSubmit",
          },
          showFields: [
            'medicalTestLocation',
            'medicalInsuranceValidity',
            'medicalTestDateTime',
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'TermMaster': {
        this.options = {
          title: 'Add',
          formId: 9,
          filterString: {},
          eventHandler: {
            'preBuild': "termAddBefore",
            'postBuild': "termAddAfter",
            'preSubmit': "termAddSubmit",
          },
          showFields: [
            'termSetId',
            'term',

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'InsuranceMaster': {
        this.options = {
          title: 'Add',
          formId: 19,
          filterString: {},
          eventHandler: {
            'preBuild': "insuranceAddBefore",
            'postBuild': "insuranceAddAfter",
            'preSubmit': "insuranceAddSubmit",
          },
          showFields: [
            'planName',
            'validityInDays'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'CurrencyMaster': {
        this.options = {
          title: 'Add',
          formId: 20,
          filterString: {},
          eventHandler: {
            'preBuild': "currencyAddBefore",
            'postBuild': "currencyAddAfter",
            'preSubmit': "currencyAddSubmit",
          },
          showFields: [
            'currencyCode',
            'currencySymbol'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'document': {
        this.options = {
          title: 'UploadDocuments',
          formId: 25,
          filterString: {},
          eventHandler: {
            'preBuild': "documentAddBefore",
            'postBuild': "documentAddAfter",
            'preSubmit': "documentAddSubmit",
          },
          showFields: [
            '1',
            '2',
            '3',
            '4',
            '5',
            '6',
            '7',
            '8',
            '9',
            '10',
            '11',
            '12'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };

      case 'password': {
        this.options = {
          title: 'Password Creation',
          formId: '',
          filterString: {},
          eventHandler: {
            'preBuild': "passwordAddBefore",
            'postBuild': "passwordAddAfter",
            'preSubmit': "passwordAddSubmit",
          },
          showFields: [
           
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };

    }
    return super.formAdd(this.options);
  }

  formEdit(formId) {
    switch (formId) {
      case 'VisaMaster': {
        this.options = {
          title: 'Edit',
          formId: 1,
          filterString: {},
          eventHandler: {
            'preBuild': "visaEditBefore",
            'postBuild': "visaEditAfter",
            'preSubmit': "visaEditSubmit",
          },
          showFields: [
            'country',
            'countrySimpleMulti',
            'visaName',
            'visaDescription',
            'entryValidity',
            'stayValidity',
            'multipleEntries',
            'extendable',
            'photoBgColor',
            'photoBgColorMulti',
            'documentChecklist', ,
            'visaCost',
            'addons',
            'quoteComponents',
            'extendableDuration',
            'dependentsAllowed',
            'visaValidity',
            'visitType',
            'preferredVisaPartner',
            'passportStampingCost'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'HostLocationMaster': {
        this.options = {
          title: 'Edit',
          formId: 2,
          filterString: {},
          eventHandler: {
            'preBuild': "hostLocEditBefore",
            'postBuild': "hostLocEditAfter",
            'preSubmit': "hostLocEditSubmit",
          },
          showFields: [
            'countryCode',
            'currency',
            'flagImage',
            'countryName',
            //'servicedStatus',

          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'WorkLocationMaster': {
        this.options = {
          title: 'Edit',
          formId: 30,
          filterString: {},
          eventHandler: {
            'preBuild': "workLocEditBefore",
            'postBuild': "workLocEditAfter",
            'preSubmit': "workLocEditSubmit",
          },
          showFields: [
            //'country',
            'locationName'

          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'DocumentMaster': {
        this.options = {
          title: 'Edit',
          formId: 3,
          filterString: {},
          eventHandler: {
            'preBuild': "docMasterEditBefore",
            'postBuild': "docMasterEditAfter",
            'preSubmit': "docMasterEditSubmit",
          },
          showFields: [
            'documentName',
            'description',
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'AddOnServiceMaster': {
        this.options = {
          title: 'Edit',
          formId: 4,
          filterString: {},
          eventHandler: {
            'preBuild': "rateCardEditBefore",
            'postBuild': "rateCardEditAfter",
            'preSubmit': "rateCardEditSubmit",
          },
          showFields: [
            'rateCardType',
            'country',
            'visaTypeIfAny',
            'termsCondition',
            'vendorName',
            'planNameIfAny',
            'rate',
            'name',
            'notes'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'VisaPartnerMaster': {
        this.options = {
          title: 'Edit',
          formId: 10,
          filterString: {},
          eventHandler: {
            'preBuild': "visaPartnerEditBefore",
            'postBuild': "visaPartnerEditAfter",
            'preSubmit': "visaPartnerEditSubmit",
          },
          showFields: [
            'country',
            'name',
            'contactPerson',
            'phoneNumber',
            'address',
            'emailId'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'PartnerVisaRateMaster': { 
        this.options = {
          title: 'Edit',
          formId: 26,
          filterString: {},
          eventHandler: {
            'preBuild': "partnerVisaRateEditBefore",
            'postBuild': "partnerVisaRateEditAfter",
            'preSubmit': "partnerVisaRateLEditSubmit",
          },
          showFields: [
            'visaType',
            'rate'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Resource': {
        this.options = {
          title: 'Resource',
          formId: 5,
          filterString: {},
          eventHandler: {
            'preBuild': "resourceEditAddBefore",
            'postBuild': "resourceEditAddAfter",
            'preSubmit': "resourceEditAddSubmit",
          },
          showFields: [
            'visaType',
            'durationOfAssignment',
            'resNationality',
            'extensionLikely',
            'onboardingBy',
            'addonServices',
            'currentLocation',
            'visitType',
            // 'salary',
            'remarks',
            // 'noOfDependents'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Dependent': {
        this.options = {
          title: 'Dependent - Edit',
          formId: 13,
          filterString: {},
          eventHandler: {
            'preBuild': "dependentEditAddBefore",
            'postBuild': "dependentEditAddAfter",
            'preSubmit': "dependentEditAddSubmit",
          },
          showFields: [
            'dBloodGroup',
            'depNationality',
            'relationship',
            'dFirstName',
            'dLastName',
            'dGender',
            'dVisaNumber',
            'dVisaValidUpto',
            'gender',
            'passportTillValid',
            'dateOfBirth',
            'dProflePic',
            'passportNo',
            'validTill',
            'issuedOn',
            'issuedLocation'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Passport': {
        this.options = {
          title: 'Passport - Edit',
          formId: 14,
          filterString: {},
          eventHandler: {
            'preBuild': "passportEditAddBefore",
            'postBuild': "passportEditAddAfter",
            'preSubmit': "passportEditAddSubmit",
          },
          showFields: [
            'passportNo',
            'issuedOn',
            'previousPassports',
            'issuedLocation',
            'validTill'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };

      case 'PreviousPassport': {
        this.options = {
          title: 'PreviousPassport - Edit',
          formId: 27,
          filterString: {},
          eventHandler: {
            'preBuild': "previousPassportEditAddBefore",
            'postBuild': "previousPassportEditAddAfter",
            'preSubmit': "previousPassportEditAddSubmit",
          },
          showFields: [
            'passportNo',
            'validTill'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };

      case 'TravelDetails': {
        this.options = {
          title: 'Travel Details - Edit',
          formId: 15,
          filterString: {},
          eventHandler: {
            'preBuild': "TravelDetailsEditAddBefore",
            'postBuild': "TravelDetailsEditAddAfter",
            'preSubmit': "TravelDetailsEditAddSubmit",
          },
          showFields: [
            'fromLocation',
            'toLocation',
            'travelDate',
            'travelDateTime',
            'arrivalDateTime',
            'airline',
            'ticketNumber',
            'okayToBoardRecipt'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'ProfessionalDetails': { 
        this.options = {
          title: 'Professional Details - Edit',
          formId: 22,
          filterString: {},
          eventHandler: {
            'preBuild': "ProfessionalDetailsEditAddBefore",
            'postBuild': "ProfessionalDetailsEditAddAfter",
            'preSubmit': "ProfessionalDetailsEditAddSubmit",
          },
          showFields: [
            'resume',
            'clientName',
            'endClientName',
            'experience',
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'PreviousCompanyDetails': { 
        this.options = {
          title: 'Professional Details - Edit',
          formId: 28,
          filterString: {},
          eventHandler: {
            'preBuild': "previousCompanyDetailsEditAddBefore",
            'postBuild': "previousCompanyDetailsEditAddAfter",
            'preSubmit': "previousCompanyDetailsEditAddSubmit",
          },
          showFields: [
            'companyName',
            'role',
            'experience',
            'fromDate',
            'toDate'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'VisaDetails': {
        this.options = {
          title: 'Visa Details - Edit',
          formId: 23,
          filterString: {},
          eventHandler: {
            'preBuild': "VisaDetailsEditAddBefore",
            'postBuild': "VisaDetailsEditAddAfter",
            'preSubmit': "VisaDetailsEditAddSubmit",
          },
          showFields: [
            'entryValidity',
            'stayValidity',
            'visaNumber',
            'visaValidUpto',
            'visaPartner'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'OnBoardingDetails': {
        this.options = {
          title: 'OnBoarding Details - Edit',
          formId: 24,
          filterString: {},
          eventHandler: {
            'preBuild': "onBoardingDetailsEditBefore",
            'postBuild': "onBoardingDetailsEditAfter",
            'preSubmit': "onBoardingDetailsEditSubmit",
          },
          showFields: [
            'medicalTestLocation',
            'medicalInsuranceValidity',
            'medicalTestDateTime',
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'ContractResource': {
        this.options = {
          title: 'Resource - Edit',
          formId: 18,
          filterString: {},
          eventHandler: {
            'preBuild': "contractResourceEditAddBefore",
            'postBuild': "contractResourceEditAddAfter",
            'preSubmit': "contractResourceEditAddSubmit",
          },
          showFields: [
            'mobileNo',
            'bloodGroup',
            // 'visaType',
            'firstName',
            //  'durationOfAssignment',
            'lastName',
            // 'resNationality',
            // 'localId',
            // 'visaNumber',
            // 'extensionLikely',
            'permanentAddress',
            // 'visaValidUpto',
            // 'onboardingBy',
            'gender',
            // 'remarks',            
            'residentialAddress',
            'emailId',
            // 'noOfDependents',
            'proflePic',
            //'additionalServicesRequired',
            'emergencyContact'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'ContractDependent': {
        this.options = {
          title: 'Dependent - Edit',
          formId: 13,
          filterString: {},
          eventHantermAddAfterdler: {
            'preBuild': "contractDependentEditAddBefore",
            'postBuild': "contractDependentEditAddAfter",
            'preSubmit': "contractDependentEditAddSubmit",
          },
          showFields: [
            'bloodGroup',
            'firstName',
            'lastName',
            'depNationality',
            'visaNumber',
            'visaValidUpto',
            'passportDetails',
            'relationship',
            'gender',
            'passportTillValid',
            'dateOfBirth'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'Quotation': {
        this.options = {
          title: 'Resource',
          formId: 16,
          filterString: {},
          eventHandler: {
            'preBuild': "quotationEditBefore",
            'postBuild': "quotationEditAfter",
            'preSubmit': "quotationEditSubmit",
          },
          showFields: [
            'passportStampingCost',
            'visaAmount',
            'rate',
            'leaveSalary',
            'endOfServiceBenefit',
            'bonus',
            'singleExit',
            'taxAmount',
            'totalAmount',
            'subTotal'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'QuotationResource': {
        this.options = {
          title: 'Resource',
          formId: 17,
          filterString: {},
          eventHandler: {
            'preBuild': "quotationResourceEditBefore",
            'postBuild': "quotationResourceEditAfter",
            'preSubmit': "quotationResourceEditSubmit",
          },
          showFields: [
            'visaAmount',
            "travelInsurance",
            "medicalInsurance"
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'QuotationResourceVisaInfo': {
        this.options = {
          title: 'Resource Visa Info',
          formId: 29,
          filterString: {},
          eventHandler: {
            'preBuild': "quotationResourceVisaInfoEditBefore",
            'postBuild': "quotationResourceVisaInfoEditAfter",
            'preSubmit': "quotationResourceVisaInfoEditSubmit",
          },
          showFields: [
            'visaType'
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'QuotationDependent': {
        this.options = {
          title: 'Dependent',
          formId: 18,
          filterString: {},
          eventHandler: {
            'preBuild': "quotationDependentEditBefore",
            'postBuild': "quotationDependentEditAfter",
            'preSubmit': "quotationDependentEditSubmit",
          },
          showFields: [
            'visaAmount',
            "medicalInsurance"
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'ProjectDetails': {
        this.options = {
          title: 'Project Details',
          formId: 7,
          filterString: {},
          eventHandler: {
            'preBuild': "projectDetailsEditBefore",
            'postBuild': "projectDetailsEditAfter",
            'preSubmit': "projectDetailsEditSubmit",
          },
          showFields: [
            'country',
            "noOfResource",
            "projectStatus",
            "projectDomain",
            "workLocation",
            "projectType",
            "endClient",
            "projectStartDate"
          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;

      };
      case 'TermMaster': {
        this.options = {
          title: 'Edit',
          formId: 9,
          filterString: {},
          eventHandler: {
            'preBuild': "termEditBefore",
            'postBuild': "termEditAfter",
            'preSubmit': "termEditSubmit",
          },
          showFields: [
            'termSetId',
            'term',

          ],
          operations: {
            'edit': false,
            'delete': false,
          },
          languageCode: "en",
        };
        break;

      };
      case 'InsuranceMaster': {
        this.options = {
          title: 'Edit',
          formId: 19,
          filterString: {},
          eventHandler: {
            'preBuild': "insuranceEditBefore",
            'postBuild': "insuranceEditAfter",
            'preSubmit': "insuranceEditSubmit",
          },
          showFields: [
            'planName',
            'validityInDays'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'CurrencyMaster': {
        this.options = {
          title: 'Edit',
          formId: 20,
          filterString: {},
          eventHandler: {
            'preBuild': "currencyEditBefore",
            'postBuild': "currencyEditAfter",
            'preSubmit': "currencyEditSubmit",
          },
          showFields: [
            'currencyCode',
            'currencySymbol'

          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
      case 'document': {
        this.options = {
          title: 'UploadDocuments',
          formId: 25,
          filterString: {},
          eventHandler: {
            'preBuild': "documentEditBefore",
            'postBuild': "documentEditAfter",
            'preSubmit': "documentEditSubmit",
          },
          showFields: [
            '1',
            '2',
            '3',
            '4',
            '5',
            '6',
            '7',
            '8',
            '9',
            '10',
            '11',
            '12',
            '13',
            '14',
            '15',
            '16'
          ],
          operations: {
            'edit': true,
            'delete': false,
          },
          languageCode: "en",
        };
        break;
      };
    }
    return super.formEdit(this.options);
  }

  formList(formId) {
    switch (formId) {
      case 'VisaMaster': {
        this.options = {
          title: 'Visa types',
          forms: [
            {
              title: "Visa",
              subtitle:"",
              formId: 1,
              filterString: {},
              eventHandler: {
                'preBuild': "visaListBefore",
                'postBuild': "visaListAfter",
                'preSubmit': "",
              },
              showFields: [
                'country',
                // 'countrySimpleMulti',
                'visaName',
                //'visaDescription',
                'entryValidity',
                // 'stayValidity',
                // 'multipleEntries',
                // 'extendable',
                // 'photoBgColor',
                // 'photoBgColorMulti',
                //'documentChecklist',
                //'addons',
                'visitType',
                // 'visaCost',
                // 'extendableDuration'
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'VisaMaster',
            },
            // {
            //   title: "Host",
            //   subtitle:"",
            //   formId: 2,
            //   filterString: {},
            //   eventHandler: {
            //     'preBuild': "hostLocListBefore",
            //     'postBuild': "hostLocListAfter",
            //     'preSubmit': "",
            //   },
            //   showFields: [
            //     //'countryCode',
            //     'countryName',
            //     'currency',
            //     //'flagImage',
            //     //'servicedStatus',
            //   ],
            //   operations: {
            //     'edit': true,
            //     'delete': true,
            //     'add': true
            //   },
            //   languageCode: "en",
            //   screenId: 'HostLocationMaster',
            // },
            // {
            //   title: "Doc",
            //   subtitle:"",
            //   formId: 3,
            //   filterString: {},
            //   eventHandler: {
            //     'preBuild': "docMasterListBefore",
            //     'postBuild': "docMasterListAfter",
            //     'preSubmit': "",
            //   },
            //   showFields: [
            //     'documentName',
            //     'description'
            //   ],
            //   operations: {
            //     'edit': true,
            //     'delete': true,
            //     'add': true
            //   },
            //   languageCode: "en",
            //   screenId: 'DocumentMaster',
            // },
          ]
        };
        break;
      };
      case 'HostLocationMaster': {
        this.options = {
          title: 'Host/Deployment locations',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 2,
              filterString: {},
              eventHandler: {
                'preBuild': "hostLocListBefore",
                'postBuild': "hostLocListAfter",
                'preSubmit': "",
              },
              showFields: [
                //'countryCode',
                'countryName',
                'currency',
                //'flagImage',
                //'servicedStatus',
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'HostLocationMaster',
            },
          ]
        };
        break;
      };
      case 'DocumentMaster': {
        this.options = {
          title: 'Documents',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 3,
              filterString: {},
              eventHandler: {
                'preBuild': "docMasterListBefore",
                'postBuild': "docMasterListAfter",
                'preSubmit': "",
              },
              showFields: [
                'documentName',
                'description'
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'DocumentMaster',
            },
          ]
        };
        break;
      };
      case 'AddOnServiceMaster': {
        this.options = {
          title: 'AddOn Services',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 4,
              filterString: {},
              eventHandler: {
                'preBuild': "rateCardListBefore",
                'postBuild': "rateCardListAfter",
                'preSubmit': "",
              },
              showFields: [
                'rateCardType',
                'country',
                'visaTypeIfAny',
                //'termsCondition',
                //'vendorName',
                'planNameIfAny',
                'rate',
                'name',
                'notes'
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'AddOnServiceMaster',
            },

          ]
        };
        break;
      };
      case 'VisaPartnerMaster': {
        this.options = {
          title: 'Visa Partners',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 10,
              filterString: {},
              eventHandler: {
                'preBuild': "visaPartnerListBefore",
                'postBuild': "visaPartnerListAfter",
                'preSubmit': "",
              },
              showFields: [
                'country',
                'name',
                //'contactPerson',
                //'phoneNumber',
                //'address',
                //'emailId'
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'VisaPartnerMaster',
            },

          ]
        };
        break;
      };
      case 'PartnerVisaRateMaster': {
        this.options = {
          title: 'Visa Partners',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 26,
              filterString: {},
              eventHandler: {
                'preBuild': "partnerVisaRateListBefore",
                'postBuild': "partnerVisaRateListAfter",
                'preSubmit': "",
              },
              showFields: [
                'visaType',
                'rate'
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'VisaPartnerMaster',
            },

          ]
        };
        break;
      };
      case 'Requirement': {
        this.options = {
          title: 'Requirement',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 7,
              filterString: {},
              eventHandler: {
                'preBuild': "RequirementListBefore",
                'postBuild': "RequirementListAfter",
                'preSubmit': "RequirementListSubmit",
              },
              showFields: [
                'country',
                'noOfResource',
                'createdDTStamp',
                // 'projectStatus',
                // 'projectDomain',
                // 'workLocation',
                'projectType',
                // 'endClient',

              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: '',
            },

          ]
        };
        break;
      };
      case 'Enquiry': {
        this.options = {
          title: 'Enquiry',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 6,
              filterString: {},
              eventHandler: {
                'preBuild': "EnquiryListBefore",
                'postBuild': "EnquiryListAfter",
                'preSubmit': "",
              },
              showFields: [
                // 'hostCountry',
                // 'contactPerson',
                //  'companyName',
                // 'contactEmailId',
                // 'phoneNumber',
                'noOfResource',
                'projectStatus',
                // 'projectDomain',
                // 'workLocation',
                // 'projectType',
                // 'notes',
                'createdDTStamp'

              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: '',
            },

          ]
        };
        break;
      };
      case 'Contract': {
        this.options = {
          title: 'Contract',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 11,
              filterString: {},
              eventHandler: {
                'preBuild': "ContractListBefore",
                'postBuild': "ContractListAfter",
                'preSubmit': "ContractListSubmit",
              },
              showFields: [
                // 'userId',
                // 'contractStatus',
                //  'country',
                // 'noOfResource',
                // 'projectStatus',
                'projectDomain',
                'workLocation',
                // 'projectType',
                // 'endClient',
                'createdDTStamp'

              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: '',
            },

          ]
        };
        break;
      };
      case 'Quotation': {
        this.options = {
          title: 'Quotation',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 16,
              filterString: {},
              eventHandler: {
                'preBuild': "QuotationListBefore",
                'postBuild': "QuotationListAfter",
                'preSubmit': "QuotationListSubmit",
              },
              showFields: [
                // 'userId',
                // 'contractStatus',
                //  'country',
                // 'noOfResource',
                // 'projectStatus',
                // 'projectDomain',
                // 'workLocation',
                // 'projectType',
                // 'endClient',
                'quoteNo',
                'createdDTStamp'

              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: '',
            },

          ]
        };
        break;
      };
      case 'TermMaster': {
        this.options = {
          title: 'Terms',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 9,
              filterString: {},
              eventHandler: {
                'preBuild': "termListBefore",
                'postBuild': "termListAfter",
                'preSubmit': "",
              },
              showFields: [
                'termSetId',
                'term',
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'TermMaster',
            },

          ]
        };
        break;
      };
      case 'InsuranceMaster': {
        this.options = {
          title: 'Insurance',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 19,
              filterString: {},
              eventHandler: {
                'preBuild': "insuranceListBefore",
                'postBuild': "insuranceListAfter",
                'preSubmit': "",
              },
              showFields: [
                'planName',
                'validityInDays'
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'InsuranceMaster',
            },

          ]
        };
        break;
      };
      case 'CurrencyMaster': {
        this.options = {
          title: 'Currency',
          forms: [
            {
              title: "",
              subtitle:"",
              formId: 20,
              filterString: {},
              eventHandler: {
                'preBuild': "currencyListBefore",
                'postBuild': "currencyListAfter",
                'preSubmit': "",
              },
              showFields: [
                'currencyCode',
                'currencySymbol'
              ],
              operations: {
                'edit': true,
                'delete': true,
                'add': true
              },
              languageCode: "en",
              screenId: 'CurrencyMaster',
            },

          ]
        };
        break;
      };
    }
    return super.formList(this.options);
  }

  siteMenu() {
    this.siteMenus = [
      {
        mTitle: 'Requirement',
        mType: 'add', // -- list/add/edit
        caseId: 'Requirement',
        mPath: 'country-selection',
        mLevel: 1,
        mOrder: 1,
        childMenu: []
      },
      {
        mTitle: 'Master',
        mType: '', // -- list/add/edit
        caseId: '',
        mPath: '',
        mLevel: 1,
        mOrder: 2,
        childMenu: [
          {
            mTitle: 'Visa',
            mType: 'list', // -- list/add/edit
            caseId: 'VisaMaster',
            mPath: 'visa',
            mLevel: 2,
            mOrder: 3,
            childMenu: []
          },
          {
            mTitle: 'Host location',
            mType: 'list', // -- list/add/edit
            caseId: 'HostLocationMaster',
            mPath: 'host-location',
            mLevel: 2,
            mOrder: 4,
            childMenu: []
          },
          {
            mTitle: 'Document',
            mType: 'list', // -- list/add/edit
            caseId: 'DocumentMaster',
            mPath: 'document',
            mLevel: 2,
            mOrder: 5,
            childMenu: []
          },
          {
            mTitle: 'Add-On Service',
            mType: 'list', // -- list/add/edit
            caseId: 'AddOnServiceMaster',
            mPath: 'rate-card',
            mLevel: 2,
            mOrder: 6,
            childMenu: []
          },
          {
            mTitle: 'Term',
            mType: 'list', // -- list/add/edit
            caseId: 'TermMaster',
            mPath: 'term',
            mLevel: 2,
            mOrder: 7,
            childMenu: []
          },
          {
            mTitle: 'Currency',
            mType: 'list', // -- list/add/edit
            caseId: 'CurrencyMaster',
            mPath: 'currency-list',
            mLevel: 2,
            mOrder: 9,
            childMenu: [
              // {
              //   mTitle: 'Currency Master',
              //   mType: '', // -- list/add/edit
              //   caseId: '',
              //   mPath: '',
              //   mLevel: 3,
              //   mOrder: 9,
              //   childMenu: [
              //     {
              //       mTitle: 'Currency Master',
              //       mType: '', // -- list/add/edit
              //       caseId: '',
              //       mPath: '',
              //       mLevel: 4,
              //       mOrder: 9,
              //       childMenu: [
              //         {
              //           mTitle: 'Currency Master',
              //           mType: 'list', // -- list/add/edit
              //           caseId: 'CurrencyMaster',
              //           mPath: 'currency-list',
              //           mLevel: 5,
              //           mOrder: 9,
              //           childMenu: []
              //         },]
              //     },
              //     {
              //       mTitle: 'Currency Master',
              //       mType: '', // -- list/add/edit
              //       caseId: '',
              //       mPath: '',
              //       mLevel: 4,
              //       mOrder: 9,
              //       childMenu: [
              //         {
              //           mTitle: 'Currency Master',
              //           mType: 'list', // -- list/add/edit
              //           caseId: 'CurrencyMaster',
              //           mPath: 'currency-list',
              //           mLevel: 5,
              //           mOrder: 9,
              //           childMenu: []
              //         },]
              //     },]
              // },
            ]
          },
          {
            mTitle: 'Insurance',
            mType: 'list', // -- list/add/edit
            caseId: 'InsuranceMaster',
            mPath: 'insurance-list',
            mLevel: 2,
            mOrder: 8,
            childMenu: []
          },
          {
            mTitle: 'Visa Partner',
            mType: 'list', // -- list/add/edit
            caseId: 'VisaPartnerMaster',
            mPath: 'visapartner-list',
            mLevel: 2,
            mOrder: 10,
            childMenu: []
          }
        ]
      },
      {
        mTitle: 'Submit Requirements',
        mType: 'submitRequirement', // -- list/add/edit
        caseId: 'submit-requirement',
        mPath: 'submit-requirement',
        mLevel: 1,
        mOrder: 10,
        childMenu: []
      },
      // {
      //   mTitle: 'Payment',
      //   mType: 'payment', // -- list/add/edit
      //   caseId: 'payment',
      //   mPath: 'payment',
      //   mId: 11,
      //   mParentId: 2,
      //   mOrder: 11
      // },
      {
        mTitle: 'User ManageMent',
        mType: 'user-manageMent', // -- list/add/edit
        caseId: 'permission',
        mPath: 'users',
        mLevel: 1,
        mOrder: 12,
        childMenu: []
      },
      {
        mTitle: 'Secondment List',
        mType: 'totalList', // -- list/add/edit
        caseId: 'TotalList',
        mPath: 'total-list',
        mLevel: 1,
        mOrder: 13,
        childMenu: []
      },
    ]
    return this.siteMenus;
  }

}