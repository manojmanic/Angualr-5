export class ScreenTemplateBuilder {

  constructor() {
  }

  formList(options) {
    let optionsMeta = {
      title: options.title,
      formId: options.formId,
      filterString: options.filterString,
      eventHandler: {
      },
      showFields: [],
      operations: {
      },
      forms: [],
    }
    for (let num of options.forms) {
      let obj = {
        title: num.title,
        formId: num.formId,
        screenId: num.screenId,
        filterString: num.filterString,
        languageCode: num.languageCode,
        eventHandler: {
          preBuild: num.eventHandler.preBuild,
          postBuild: num.eventHandler.postBuild,
          preSubmit: num.eventHandler.preSubmit,
        },
        showFields: [],
        operations: {
          'edit': num.operations.edit,
          'delete': num.operations.delete,
          'add': num.operations.add,
        },
      };
      for (let ob of num.showFields) {
        // obj.showFields[ob] = ob; 
        obj.showFields.push(ob);
      }
      optionsMeta.forms.push(obj);
    }
    return optionsMeta;
  }

  formView(options) {
    let optionsMeta = {
      title: options.title,
      formId: options.formId,
      filterString: options.filterString,
      languageCode: options.languageCode,
      eventHandler: {
        preBuild: options.eventHandler.preBuild,
        postBuild: options.eventHandler.postBuild,
        preSubmit: options.eventHandler.preSubmit,
      },
      showFields: [],
      operations: {
        'edit': options.operations.edit,
        'delete': options.operations.delete
      },
    }

    let numbers = [1, 2, 3];
    for (let num of options.showFields) {
      optionsMeta.showFields[num] = num;
    }

    return optionsMeta;
  }

  formAdd(options) {
    let optionsMeta = {
      title: options.title,
      formId: options.formId,
      filterString: options.filterString,
      languageCode: options.languageCode,
      eventHandler: {
        preBuild: options.eventHandler.preBuild,
        postBuild: options.eventHandler.postBuild,
        preSubmit: options.eventHandler.preSubmit,
      },
      showFields: [],
      dependantFields: options.dependantFields,
      operations: {
        'edit': options.operations.edit,
        'delete': options.operations.delete
      },
    }

    let numbers = [1, 2, 3];
    for (let num of options.showFields) {
      optionsMeta.showFields[num] = num;
    }

    return optionsMeta;
  }

  formEdit(options) {
    let optionsMeta = {
      title: options.title,
      formId: options.formId,
      filterString: options.filterString,
      languageCode: options.languageCode,
      eventHandler: {
        preBuild: options.eventHandler.preBuild,
        postBuild: options.eventHandler.postBuild,
        preSubmit: options.eventHandler.preSubmit,
      },
      showFields: [],
      operations: {
        'edit': options.operations.edit,
        'delete': options.operations.delete
      },
    }

    let numbers = [1, 2, 3];
    for (let num of options.showFields) {
      optionsMeta.showFields[num] = num;
    }

    return optionsMeta;
  }

}
