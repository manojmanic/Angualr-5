export class QuestionBase<T>{
  value: any;
  key: string;
  // label: string;
  // required: boolean;
  // order: number;
  // controlType: string;
  // placeholder: string;
  // fieldtype:number;
  isRequired: string;
  isHidden:string;
  fieldOrder: number;
  formTitle:string;
  formId:number;
  controlType: string;
  fieldType: string;
  fieldCaption: string;
  fieldGroupId:number;
  fieldId:number;
  validationRegex:string;
  fieldHelpText:string;
fieldHelpTextLong:string;
additionalMetaData:string;
fieldColumn:string;
validationMessage:string;
visible:boolean;
  constructor(options: {
    value?: any,
    key?: string,
    // label?: string,
    // required?: boolean,
    // order?: number,
    // controlType?: string,
    // placeholder?: string,
    // fieldtype?:number,
    validationMessage?:string,
     isRequired?: string,
     isHidden?:string,
    fieldOrder?: number,
    formTitle?: string,
    formId?:number,
    controlType?: string,
    fieldType?: string,
    fieldCaption?: string,
    fieldGroupId?:number,
    validationRegex?:string,
    fieldHelpText?:string,
    fieldHelpTextLong?:string,
    additionalMetaData?:string,
    fieldId?:number,
    fieldColumn?:string,
    visible?:boolean
  } = {}) {
    // this.fieldtype=options.fieldtype;
    // this.placeholder = options.placeholder;
    this.value = options.value;
    this.key = options.key;
    // this.label = options.label;
    // this.required = !!options.required;
    // this.order = options.order === undefined ? 1 : options.order;
    // this.controlType = options.controlType;
     this.fieldGroupId=options.fieldGroupId;
    this.fieldId=options.fieldId;
    this.fieldCaption = options.fieldCaption;
    this.fieldColumn = options.fieldColumn;
    this.isRequired = options.isRequired;
    this.isHidden = options.isHidden;
    this.formTitle = options.formTitle;
    this.formId = options.formId;
    this.fieldOrder = options.fieldOrder === undefined ? 1 : options.fieldOrder;
    this.controlType = options.controlType;
    this.fieldType = options.fieldType;
    this.validationRegex = options.validationRegex;
    this.fieldHelpText=options.fieldHelpText;
    this.fieldHelpTextLong=options.fieldHelpTextLong;
    this.additionalMetaData=options.additionalMetaData;
    this.validationMessage=options.validationMessage;
    this.visible=options.visible;
  }
}
