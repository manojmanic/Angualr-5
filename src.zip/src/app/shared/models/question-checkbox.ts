import { QuestionBase } from './question-base';

export class CheckboxQuestion extends QuestionBase<string> {
 // controlType = 'textbox';
  type: boolean;

  constructor(options: {} = {}) {
    super(options);
    this.type = options['type'] ;
  }
}