import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VarDirective } from './ng-var.directive';

@NgModule({
  imports: [
    CommonModule,
  ],
  declarations: [
      VarDirective
  ],
  exports:[
    VarDirective
  ]
})
export class DirectiveModule { }
