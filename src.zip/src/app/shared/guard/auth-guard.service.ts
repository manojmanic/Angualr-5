import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Promise } from 'q';
import { Constants } from '../../constants';
import { Http, Headers } from '@angular/http';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { MatSnackBar } from '@angular/material';


@Injectable()
export class AuthGuardService {

  setLogin: Subject<boolean> = new Subject<boolean>();
  getLogin: Subject<any> = new Subject<any>();

  constructor(private config: Constants,
    private http: Http,
    private router: Router,
    private snackBar: MatSnackBar) { }

  login(data): Observable<any> | Promise<any> | any {
    let head = new Headers({
      'Content-Type': 'application/json'
    });

    var api = this.config.API_URL + "/api/login";
    return this.http.post(api, data, { headers: head }).map(resp =>
      resp.json()
    );

  }

  logout(data) {
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token':this.getLoginUser().tokenId
    });

    var api = this.config.API_URL + "/api/logout";
    return this.http.post(api, data, { headers: head }).map(resp => resp.json());

  }

  set changeState(data) {
    this.setLogin.next(data);
  }

  set setLoginUser(data) {
    this.getLogin.next(data);
  }

  getLoginUser() {
    return JSON.parse(localStorage.getItem('currentUser'));
  }

  get isLogin() {
    let logData = this.getLoginUser();
    if (logData != null) {
      const timer = logData.activeTime;
    if (timer && (timer+this.config.LOGIN_EXPIRY < Date.now())) {
      this.logout({ClientID: logData.tokenId}).subscribe(resp => {
        if (resp.status == 'success') {
            localStorage.removeItem('currentUser');
            this.changeState = { isLogin: false, currentUser: '' };
            this.openSnackBar("Login Session Expired", "");
            this.router.navigate(['/signin'])
        }
    })
    }
    else{
      if(logData.hasOwnProperty('activeTime')){
        logData.activeTime = Date.now();
        localStorage.setItem('currentUser', JSON.stringify(logData));
      }   
    }
      if (logData.hasOwnProperty('id')) {

        return true;
      }
      return false;
    } else {
      return false;
    }
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
      extraClasses: ['error']
    });
  }
}
