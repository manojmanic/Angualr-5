import { Injectable } from '@angular/core';
import { CanActivate, CanLoad, CanDeactivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthGuardService } from './auth-guard.service';
import { AuthComponent } from '../../auth/auth.component';
import { Router, ActivatedRoute } from '@angular/router';
import { AccessControlFunctions } from '../../shared/common/accessControl'
// import { PermissionService } from '../../user-management/service/permission.service';
import { MatSnackBar } from '@angular/material';
export interface CanComponentDeactivate {
  canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {


  constructor(
    private authGuardService: AuthGuardService,
    private snackBar: MatSnackBar,
    private router: Router,
    private accessService: AccessControlFunctions
  ) {

  }


  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.accessService.canActivate) {
      return this.accessService.canActivate(
        this.authGuardService.isLogin,
        this.authGuardService.getLoginUser(),
        state.url);
    } else {
      this.openSnackBar("something went wrong","");
      return false;
    }
  }
  canLoad(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    if (this.accessService.canLoad && this.authGuardService.getLoginUser() != null) {
      this.accessService.canLoad(this.authGuardService.isLogin)
    }
    else {

      return true;
    }

  }

  canDeactivate(
    component: AuthComponent,
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    if (this.accessService.canDeactivate && this.authGuardService.getLoginUser() != null) {
      this.accessService.canDeactivate(this.authGuardService.isLogin)
    }
    else {
      return true;
    }
  }

  canActivateChild(next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    // var role = this.authGuardService.getLoginUser().roleDetails;

    //   role.Permissions.map(resp=>{
    //   if (resp == "CEUSER") {
    //     if (state.url.match(/(profile-add)/)) {
    //       // this.openSnackBar(" page is not accessable for you.", "");
    //       return true;
    //     }else if (state.url.match(/(users)/)) {
    
    //     return true;
    //   }
    // }

    //     this.openSnackBar("This  is not Accessable for You","")
    //     return false;

    // })
    return true;


  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
      extraClasses: ['error']
    });
  }
}
