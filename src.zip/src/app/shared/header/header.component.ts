import { Component, ViewChild, OnInit, Input, Output, ElementRef, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuardService } from '../guard/auth-guard.service';
import {
    ObservableMedia
} from '@angular/flex-layout';
import { MatMenuTrigger, MatSnackBar } from '@angular/material';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {



    languageList: any = [
        {'lang':'en', 'title':'English', 'img':'./assets/image/lang/en.png'},
        {'lang':'ta', 'title':'Tamil', 'img':'./assets/image/lang/ind.png'}
    ];
    crtLang: any;
    isLogin;
    currentUser;

    constructor(
        //  private sharedService: SharedService,
        private authGuardService: AuthGuardService,
        private elementRef: ElementRef,
        public snackBar: MatSnackBar,
        private router: Router,
    ) {

        if(localStorage.getItem('selected_language'))
        this.crtLang = this.languageList.filter(items => items.lang == localStorage.getItem('selected_language'));
        else
        this.crtLang = this.languageList.filter(items => items.lang == 'en');

        this.isLogin = this.authGuardService.isLogin;
        this.currentUser = this.authGuardService.getLoginUser();
        this.authGuardService.setLogin.subscribe(resp => {
            this.isLogin = resp['isLogin'];
            this.currentUser = resp['currentUser'];
        });

    }

    @Output() sideMenuToggle = new EventEmitter<boolean>();
    sideBarOpen() {
        this.sideMenuToggle.emit(true);
    }

    ngOnInit() {
       // var element = this.elementRef.nativeElement.getElementsByClassName('cdk-overlay-pane');
  
    }

    searchbar = false;

   
    logout() {
        let logData = JSON.parse(localStorage.getItem('currentUser'));

        if (logData != null) {

            this.authGuardService
                .logout({ ClientID: logData.tokenId })
                .subscribe(resp => {
                    if (resp.status == 'success') {
                        localStorage.removeItem('currentUser');
                        
                        this.authGuardService.changeState = { isLogin: false, currentUser: '' };
                        this.router.navigate(['/signin'])
                    }
                    this.openSnackBar({ message: resp.message, status: resp.status });
                })

        }
    }



    langSelect(obj): void {
        localStorage.setItem('selected_language', (obj.lang));
        let el = this.elementRef.nativeElement.getElementsByClassName('lang-list');
        let childEl = el[0].firstElementChild.children;
        childEl = Array.from(childEl);
        childEl.forEach(element => {
            if (element.classList.contains('lang-img')) {
                element.children[0].src = obj.img;
            } else if (element.classList.contains('lang-title')) {
                element.innerText = obj.title;
            }
        });
        window.location.reload();
    }

    openSnackBar(snackData) {
        let message = snackData.message;
        let action = '';
        let classess;

        if (snackData.status == 'success') {
            classess = 'success';
        } else if (snackData.status == 'error') {
            classess = 'error';
        } else {
            classess = 'warn';
        }

        this.snackBar.open(message, action, {
            duration: 2000,
            extraClasses: [classess]
        });
    }

}
