import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from '../../app.component';
import { HeaderComponent } from '../../shared/header/header.component';
import { FooterComponent } from '../../shared/footer/footer.component';
import { SidemenuComponent } from '../../shared/sidemenu/sidemenu.component';
import { FormaddComponent } from '../../forms/simpleform/formadd/formadd.component';
import { RouterModule, Routes, Router } from '@angular/router';
import { FormlistComponent } from '../../forms/simpleform/formlist/formlist.component';
import { FormeditComponent } from '../../forms/simpleform/formedit/formedit.component';
import { FormdetailComponent } from '../../forms/simpleform/formdetail/formdetail.component';
import { SubmitRequirementsComponent } from '../../forms/hierarchyform/submit-requirements/submit-requirements.component';
import { Route } from '@angular/router/src/config';
import { PasswordcreationComponent } from '../../forms/passwordcreation/passwordcreation.component';
import { AuthComponent } from '../../auth/auth.component';
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { SuccessScreenComponent } from '../../success-screen/success-screen.component';
import { AuthGuard } from '../../shared/guard/auth.guard';
import { ViewContractComponent } from '../../contract/view-contract/view-contract.component';
import { AlertComponent } from '../../alert/alert.component';
import { HomeComponent } from '../../home/home.component';
import { PaymentComponent } from '../../payment/payment.component';
import { TotallistComponent } from '../../totallist/totallist.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {
    path: 'FormList/:id',
    component: FormlistComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'FormEdit/:id/:dataId',
    component: FormeditComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'FormDetails/:id/:dataId',
    component: FormdetailComponent
  },
  {
    path: 'formAdd/:id',
    component: FormaddComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'successScreen',
    component: SuccessScreenComponent
  },
  {
    path: 'signin',
    component: AuthComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'users',
    loadChildren: '../../user-management/user-management.module#UserManagementModule'
  },
  {
    path: 'home',
    component: HomeComponent,
  },
  {
    path: 'contract',
    loadChildren: '../../contract/contract.module#ContractModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'quotation',
    loadChildren: '../../quotation/quotation.module#QuotationModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'registration/:id',
    component: FormaddComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'enquiry/:id',
    component: FormaddComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'password-settings',
    component: PasswordcreationComponent
  },
  {
    path: 'payment/:id',
    component: PaymentComponent,
    canActivate: [AuthGuard]
  },

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {
  menuItems: any;
  routeList: any = [];
  constructor(private router: Router, private screenTB: ScreenTemplateJsonBuilder) {
    this.menuItems = this.screenTB.siteMenu();
    let r: Route;
    // for (let menuItem of this.menuItems) {
    //   if (menuItem.mType == 'list') {
    //     r = {
    //       path: menuItem.mPath + '/:id',
    //       component: FormlistComponent,
    //       canActivate: [AuthGuard]
    //     };
    //   }
    //   else if (menuItem.mType == 'add') {
    //     r = {
    //       path: menuItem.mPath + '/:id',
    //       component: FormaddComponent,
    //       canActivate: [AuthGuard]
    //     };
    //   }
    //   else if (menuItem.mType == 'edit') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: FormeditComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }
    //   else if (menuItem.mType == 'submitRequirement') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: SubmitRequirementsComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }
    //   else if (menuItem.mType == 'password-settings') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: PasswordcreationComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }
    //   else if (menuItem.mType == 'country-selection') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: FormaddComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }
    //   else if (menuItem.mType == 'enquiry') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: FormaddComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }
    //   else if (menuItem.mType == 'registration') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: FormaddComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }
    //   else if (menuItem.mType == 'payment') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: PaymentComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }
    //   else if (menuItem.mType == 'totalList') {
    //     r = {
    //       path: menuItem.mPath + '/' + menuItem.caseId,
    //       component: TotallistComponent,
    //       canActivate: [AuthGuard]
    //     };

    //   }


    //   this.router.resetConfig([r, ...this.router.config]);
    // }
    let routeList = this.menuBuilder(this.menuItems, r);
    if(routeList.length)
      this.router.resetConfig(routeList);
  }


  protected menuBuilder(menuItems, r) {
    menuItems.forEach((menuItem, index) => {
      if (menuItem.mType == 'list') {
        r = {
          path: menuItem.mPath + '/:id',
          component: FormlistComponent,
          canActivate: [AuthGuard]
        };
      }
      else if (menuItem.mType == 'add') {
        r = {
          path: menuItem.mPath + '/:id',
          component: FormaddComponent,
          canActivate: [AuthGuard]
        };
      }
      else if (menuItem.mType == 'edit') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: FormeditComponent,
          canActivate: [AuthGuard]
        };
      }
      else if (menuItem.mType == 'submitRequirement') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: SubmitRequirementsComponent,
          canActivate: [AuthGuard]
        };

      }
      else if (menuItem.mType == 'password-settings') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: PasswordcreationComponent,
          canActivate: [AuthGuard]
        };
      }
      else if (menuItem.mType == 'country-selection') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: FormaddComponent,
          canActivate: [AuthGuard]
        };

      }
      else if (menuItem.mType == 'enquiry') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: FormaddComponent,
          canActivate: [AuthGuard]
        };
      }
      else if (menuItem.mType == 'registration') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: FormaddComponent,
          canActivate: [AuthGuard]
        };

      }
      else if (menuItem.mType == 'payment') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: PaymentComponent,
          canActivate: [AuthGuard]
        };
      }
      else if (menuItem.mType == 'totalList') {
        r = {
          path: menuItem.mPath + '/' + menuItem.caseId,
          component: TotallistComponent,
          canActivate: [AuthGuard]
        };
      }

      if(menuItem.childMenu.length){
        this.menuBuilder(menuItem.childMenu, r);
      }

      this.routeList.push(r);

    });

    return this.routeList.concat(this.router.config);
    

  }
}
