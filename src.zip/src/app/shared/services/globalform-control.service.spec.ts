import { TestBed, inject } from '@angular/core/testing';

import { GlobalformControlService } from './globalform-control.service';

describe('GlobalformControlService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GlobalformControlService]
    });
  });

  it('should be created', inject([GlobalformControlService], (service: GlobalformControlService) => {
    expect(service).toBeTruthy();
  }));
});
