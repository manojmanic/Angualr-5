import { Injectable, OnChanges } from '@angular/core';
import { DropdownQuestion } from '../models/question-dropdown';
import { QuestionBase } from '../models/question-base';
import { TextboxQuestion } from '../models/question-textbox';
import { Http, Headers, Response } from "@angular/http";
import { Subject } from 'rxjs/Subject';
import { Observable, Observer } from 'rxjs/Rx';
import { AuthGuardService } from '../guard/auth-guard.service';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { Constants } from '../../constants';
@Injectable()
export class GlobalformService {


  constructor(
    private http: Http,
    private authGuardService: AuthGuardService,
    private config: Constants,
  ) {
    const eventCalls = this.authGuardService;
  }

  disabledValue: any = [];
  data: any;
  form_title: any;
  visaListId: any;
  internationalPhoneData:any = {};
  // internationalPhoneNumberBoolean:boolean;
  id: number;
  fieldType: any;
  termRefsingleData: any;
  files: any;
  screenId: any;
  formId: any;
  formid: any;
  depDataIdEdit: any; // For resource and dependent Edit

   
  /////////////////// Get Form /////////////////
  getForms(id) {
    let data;
    let currentUser = this.authGuardService.getLoginUser();

    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });

    if (localStorage.getItem('selected_language') === null) {
      data = { "formId": id, "languageCode": "en" };

    }
    else {
      data = { "formId": id, "languageCode": localStorage.getItem('selected_language') }
    }

    let api = this.config.API_URL + "/api/get_form";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))

  }

  //////////////////To get Term Reference List fields//////////////

  getTerms(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let api = this.config.API_URL + "/api/get_terms";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))

  }


  ////////////////// Save Form //////////////////
  putForms(data: any, formId: any) {
    let form_data = { formData: data };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    form_data["formId"] = formId;
    form_data["transactionId"] = data.transactionId;

    if (currentUser != null) {
      // form_data["userId"] = this.currentUser.id;
    }
    let api = this.config.API_URL + "/api/add_form_data";
    return this.http.post(api, form_data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))

  }


  ////////////////Delete form data ////////////////
  deleteForm(data: any, formId: any, transactionId: any, status: any) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    var form_data = {};
    form_data["formId"] = formId;
    // form_data["userId"] = this.currentUser.id;
    form_data["transactionId"] = transactionId;
    form_data["status"] = status;
    if (transactionId === "" || transactionId === null || transactionId === undefined) {
      form_data["filterString"] = { "dataId": data };
    }
    else {
      form_data["filterString"] = { "rowId": data };
    }
    let api = this.config.API_URL + "/api/delete_form_data";
    return this.http.post(api, form_data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  ////////////////// Get Form Data //////////////////////
  getFormData(data: any) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    if (localStorage.getItem('selected_language') != null) {
      data.languageCode = localStorage.getItem('selected_language');
    } else {
      data.languageCode = "en";
    }
    // if(data.formId != 6 && this.currentUser.userType != 'FFI')
    // data["filterString"] = { "userId": this.currentUser.id };

    let api = this.config.API_URL + "/api/get_form_data";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  /////////////////// Update Form /////////////////////////
  updateFormData(data: any, formId: any, updatedId: any) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    var form_data = { formData: data };
    var dataid = { dataId: this.id };
    form_data["formId"] = formId;
    // form_data["userId"] = this.currentUser.id;
    form_data["transactionId"] = data.transactionId;
    if (form_data["transactionId"] === "" || form_data["transactionId"] === null || form_data["transactionId"] === undefined) {
      // if(form_data['formId'] !=25)
      form_data["filterString"] = { "dataId": updatedId };
      // else 
      //   form_data["filterString"] = { "resourceId": updatedId };
    }
    else {
      form_data["filterString"] = { "rowId": updatedId };
    }
    console.log(form_data)
    let api = this.config.API_URL + "/api/update_form_data";
    return this.http.post(api, form_data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))

  }



  ////////////////// Get Form Data //////////////////////
  getQuotationList(data: any) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    if (localStorage.getItem('selected_language') != null) {
      data.languageCode = localStorage.getItem('selected_language');
    } else {
      data.languageCode = 'en'
    }
    //  data["filterString"] = { "userId": this.currentUser.id };
    //  data["userId"] = this.currentUser.id;
    //  data["userType"] = currentUser.userType;
    let api = this.config.API_URL + "/api/get_quotation_list";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  /////////////// Image Upload ///////////////
  uploadFile(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Token': tokenId
    });

    let formData: FormData = new FormData();
    formData.append('file', data);
    let api = this.config.API_URL + "/api/upload_file";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))

  }

  //////////// Document Upload //////////////
  uploadFileDocs(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Token': tokenId
    });
    let formData: FormData = new FormData();
    formData.append('file', data);
    let api = this.config.API_URL + "/api/upload_file_docs";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))

  }

  ///////////// Get Custom List ////////////
  getCustomList(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let api = this.config.API_URL + "/api/get_custom_list";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  ////////////// Get Requirement Data /////////
  getRequirementdata(id) {
    let data;
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    if (localStorage.getItem('selected_language') === null) {
      data = { "transactionId": id, "languageCode": "en" };
    }
    else {
      data = { "transactionId": id, "languageCode": localStorage.getItem('selected_language') }
    }
    let api = this.config.API_URL + "/api/temp_requirement_data";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  ///////// Final Submit Transaction //////////////////
  submitTransaction() {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let data = {
      transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId,
      // userId: this.currentUser.id,
    }

    let api = this.config.API_URL + "/api/submit_transaction";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  ////////// Password Settings ////////////////////////
  passwordSettings(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let api = this.config.API_URL + "/api/password_setting";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  ///////// Generate Contract //////////////////////
  generateContract(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let formData = {
      // userId: this.currentUser.id,
      reqId: data
    }

    let api = this.config.API_URL + "/api/generate_contract";
    return this.http.post(api, formData, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }


  //////////////////To get Term Reference List fields//////////////

  getAddons(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let api = this.config.API_URL + "/api/get_addon_list";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  //////////////////To get Term Reference List fields//////////////
  getWorkFlowRecordDetail(apiData) {
    let data = { ...apiData };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    //  if (localStorage.getItem('selected_language') != null) {
    //    data['languageCode'] = localStorage.getItem('selected_language');
    //  }
    // data['roleId'] = this.currentUser.roleDetails.roleId;

    let api = this.config.API_URL + "/api/get_workflow_record_detail";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  //////////////////To get Term Reference List fields//////////////
  getChildWorkflowStagedetails(apiData) {

    let data = { ...apiData };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });

    //  if (localStorage.getItem('selected_language') != null) {
    //    data['languageCode'] = localStorage.getItem('selected_language');
    //  }
    // data['roleId'] = this.currentUser.roleDetails.roleId;

    let api = this.config.API_URL + "/api/get_child_workflow_stagedetails";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

  processWorkflowAction(apiData): Observable<any> {
    let data = { ...apiData };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let postUrl = this.config.API_URL + '/api/process_workflow_action';
    return this.http.post(postUrl, data, { headers: head }).map((res: Response) => (
      res.json()
    ));
  }

  createWorkflowTransaction(apiData): Observable<any> {
    let data = { ...apiData };
    // if (localStorage.getItem('selected_language') != null) {
    //   data['languageCode'] = localStorage.getItem('selected_language');
    // }
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let postUrl = this.config.API_URL + '/api/create_workflow_transaction';
    return this.http.post(postUrl, data, { headers: head }).map((res: Response) => (
      res.json()
    ));
  }

  generateResourceWorkflow(apiData): Observable<any> {
    let data = { ...apiData };
    // if (localStorage.getItem('selected_language') != null) {
    //   data['languageCode'] = localStorage.getItem('selected_language');
    // }
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let postUrl = this.config.API_URL + '/api/generate_resource_workflow';
    return this.http.post(postUrl, data, { headers: head }).map((res: Response) => (
      res.json()
    ));
  }

  workFlowMail(apiData) {
    let data = { ...apiData };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    // this.currentUser = this.authGuardService.getLoginUser();
    //  if (localStorage.getItem('selected_language') != null) {
    //    data['languageCode'] = localStorage.getItem('selected_language');
    //  }
    // data['roleId'] = this.currentUser.roleDetails.roleId;
    let api = this.config.API_URL + "/api/send_quotation_mail";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }

}
