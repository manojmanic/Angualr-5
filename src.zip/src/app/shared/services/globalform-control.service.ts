import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators, FormArray } from '@angular/forms';
import { QuestionBase } from '../models/question-base';
import { TextboxQuestion } from '../models/question-textbox';
import { DropdownQuestion } from '../models/question-dropdown';
import { CheckboxQuestion } from '../models/question-checkbox';
import { CustomQuestion } from '../models/question-custom';
@Injectable()
export class GlobalformControlService {

  constructor() { }

  toFormGroup(formControls: any[]) {
    let group: any = {};

    
    ///////////// Assign FormControl Name ///////////////////
    for (let formControl of formControls) {

      /////////// To Hide Fields ///////////////////
      if (formControl.isHidden === "1") {
        formControl.isHidden = true;
      }
      else {
        formControl.isHidden = false;
      }

      // if(formControl.fieldType == 'fileImage'|| formControl.fieldType == 'fileDoc'){
      //   if (formControl.isRequired === "1") {

      //     group[formControl.fieldColumn] = new FormControl('', Validators.required, )
      //   }
      //   if (formControl.isRequired === "0") {
      //     group[formControl.fieldColumn] = new FormControl();
      //   }
      // } else {
      //   if (formControl.isRequired === "1") {
      //     group[formControl.fieldColumn] = new FormControl(formControl.value || '', Validators.required, )
      //     formControl.fieldCaption = formControl.fieldCaption + '*'
      //   }
      //   if (formControl.isRequired === "0") {
      //     group[formControl.fieldColumn] = new FormControl(formControl.value || '');
      //   }
      // }

      if (formControl.fieldType == 'fileImage' || formControl.fieldType == 'fileDoc') {
        if ((formControl.hasOwnProperty('readonly') && formControl.readonly) || formControl.isHidden || !formControl.visible) {
          group[formControl.fieldColumn] = new FormControl({ value: '', disabled: formControl.readonly })
        } else {
          group[formControl.fieldColumn] = new FormControl({ value: '', disabled: false }, (formControl.isRequired === "1") ? Validators.required : null);
        }
      } else if (formControl.fieldType == 'currencyText') {
        if ((formControl.hasOwnProperty('readonly') && formControl.readonly) || formControl.isHidden || !formControl.visible) {
          group[formControl.fieldColumn] = new FormControl({ value: formControl.value || '0', disabled: formControl.readonly })
        } else {
          group[formControl.fieldColumn] = new FormControl({ value: formControl.value || '0', disabled: false }, (formControl.isRequired === "1") ? Validators.required : null);
        }
      } else {
        if ((formControl.hasOwnProperty('readonly') && formControl.readonly) || formControl.isHidden || !formControl.visible) {
          group[formControl.fieldColumn] = new FormControl({ value: formControl.value || '', disabled: formControl.readonly })
        } else {
          console.log(formControl.fieldColumn);
          group[formControl.fieldColumn] = new FormControl({ value: formControl.value || '', disabled: false }, (formControl.isRequired === "1") ? Validators.required : null);
        }
      }
      /////////// Assign FormControl for each checkbox values ///////////
      if (formControl.fieldType === "customMultiSelectOptions") {
        var formControlJson: any = {};
        //setTimeout(() => {
        for (var data of formControl.additionalMetaData) {
          formControlJson[data.value] = new FormControl('' || false);
        }
        group[formControl.fieldColumn] = new FormGroup(formControlJson);
        //}, 3000);
      }
    }
    return new FormGroup(group);
  }

  buildForm(formData, showFields = null) {

    let fieldData = this.buildFields(formData, showFields);
    let returnData = {};
    returnData['fields'] = fieldData;
    returnData['controls'] = this.buildControls(fieldData);

    return returnData;

  }

  buildFields(formData, showFields = null) {

    let buildData = formData;
    let fieldData: any = [];

    /////// To Get FieldList From Json /////////////////////
    buildData.fieldGroup.map((fieldGroupResp, i) => {
      fieldGroupResp.FieldList.map((FieldListResp, k) => {

        // console.log(FieldListResp);
        // if (FieldListResp.length) {
        //   FieldListResp.map((FieldListArrResp, index) => {
        //     console.log(FieldListArrResp);
        //     let fieldGroup = {
        //       'fieldGroup': [
        //         {
        //           'FieldList': FieldListArrResp,
        //           'FieldGroupName': FieldListArrResp
        //         }
        //       ]
        //     };
        //     console.log(fieldData[k], k, fieldData);
        //     let fields = (this.buildFields(fieldGroup));
        //     console.log(Array(
        //       k => Array(
        //         index => fields
        //       )
        //     ));
        //     fieldData.concat(fieldData, Array(
        //       k => Array(
        //         index => fields
        //       )
        //     ));
        //   });
        // }

        if (showFields != null && showFields.hasOwnProperty(FieldListResp.fieldColumn)) {
          FieldListResp.visible = true;
        }

        if (FieldListResp.fieldType === 'shortText') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'currencyText') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'calcText') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'text') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'customList') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'customListAdditionalDetail') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'simpleListMultiSelect') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'singleSelectOption') {
          let options = [
            { key: 'yes', value: 'Yes' },
            { key: 'no', value: 'No' },
          ]
          FieldListResp.additionalMetaData = options;
          fieldData.push(new CheckboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'radio') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'termsReferenceList') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'termsReferenceListMulti') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'fileImage') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'fileDoc') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'customMultiSelectOptions') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'customListMultiSelect') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'date') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'dateTime') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'rangeDateTime') {
          fieldData.push(new TextboxQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'tableAddon') {
          fieldData.push(new CustomQuestion(FieldListResp));
        } else if (FieldListResp.fieldType === 'internationalPhoneNumber') {
          fieldData.push(new DropdownQuestion(FieldListResp));
        }
      });
    });

    fieldData.sort((a, b) => a.fieldOrder - b.fieldOrder);
    
    return fieldData;
  }

  buildControls(fieldData) {
    let formControls;
    formControls = this.toFormGroup(fieldData);

    return formControls;
  }

}
