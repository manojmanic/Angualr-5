
import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { AuthGuardService } from '../guard/auth-guard.service';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { AccessControlFunctions } from '../../shared/common/accessControl'
import { Constants } from '../../constants';
import { GlobalformService } from './globalform.service';

@Injectable()
export class GlobalFunctionService {

    constructor(
        private location: Location,
        private snackBar: MatSnackBar,
        private authGuardService: AuthGuardService,
        private state: ActivatedRoute,
        private accessService: AccessControlFunctions,
        private service: GlobalformService,
        private config: Constants
    ) { }

    typeOf(val) {
        return typeof val;
    }

    back() {
        this.location.back();
    }

    randomHash(nChar) {
        // convert number of characters to number of bytes
        var nBytes = Math.ceil(nChar = (+nChar || 8) / 2);

        // create a typed array of that many bytes
        var u = new Uint8Array(nBytes);

        // populate it wit crypto-random values
        window.crypto.getRandomValues(u);

        // convert it to an Array of Strings (e.g. "01", "AF", ..)
        var zpad = function (str) {
            return '00'.slice(str.length) + str
        };
        var a = Array.prototype.map.call(u, function (x) {
            return zpad(x.toString(16))
        });

        // Array of String to String
        var str = a.join('').toUpperCase();
        // and snip off the excess digit if we want an odd number
        if (nChar % 2) str = str.slice(1);

        // return what we made
        return str;
    }

    DeactivatePermissioncode() {
        let crtUrl = this.state['_routerState']['snapshot']['url'];
        if (this.accessService.DeactivatePermissioncode) {
            return this.accessService.DeactivatePermissioncode(
                this.authGuardService.isLogin,
                this.authGuardService.getLoginUser(),
                crtUrl);
        } else {
            this.openSnackBar("something went wrong", "");

        }
    }

    createRole() {
        let crtUrl = this.state['_routerState']['snapshot']['url'];

        if (this.accessService.DeactivatePermissioncode) {
            return this.accessService.createRole(
                this.authGuardService.isLogin,
                this.authGuardService.getLoginUser(),
                crtUrl);
        } else {
            this.openSnackBar("something went wrong", "");

        }

    }

    PermissionDeactivate() {
        let crtUrl = this.state['_routerState']['snapshot']['url'];

        if (this.accessService.DeactivatePermissioncode) {
            return this.accessService.PermissionDeactivate(
                this.authGuardService.isLogin,
                this.authGuardService.getLoginUser(),
                crtUrl);
        } else {
            this.openSnackBar("something went wrong", "");

        }
    }



    JSONMerge(dest, src) {
        for (var key in src) {
            dest[key] = src[key];
        }
        return dest;
    }

    encryptDecryptFun(encryType, encryData) {
        if (encryData != '') {
            if (encryType == 'btoa') {
                console.log(encryType,encryData)
                try {
                    return btoa(encryData);
                } catch (e) {
                    // something failed

                    // if you want to be specific and only catch the error which means
                    // the base 64 was invalid, then check for 'e.code === 5'.
                    // (because 'DOMException.INVALID_CHARACTER_ERR === 5')
                    return '';
                }
            } else if (encryType == 'atob') {
                console.log(encryType,encryData)
                // console.log(encryType, encryData,atob(encryData));
                try {
                    return atob(encryData);
                } catch (e) {
                    // something failed

                    // if you want to be specific and only catch the error which means
                    // the base 64 was invalid, then check for 'e.code === 5'.
                    // (because 'DOMException.INVALID_CHARACTER_ERR === 5')
                    return '';
                }
            }
        }
        return '';
    }

    openSnackBar(message: string, action: string) {
        this.snackBar.open(message, action, {
            duration: 2000,
            extraClasses: ['error']
        });
    }


    removeDuplicateArr(arr) {
        let obj = {};
        for (let i = 0; i < arr.length; i++) {
            obj[arr[i]] = true;
        }
        arr = [];
        for (let key in obj) {
            arr.push(key);
        }
        return arr;
    }



    fullDate(getDate) {
        var today = new Date(); // Or Date.today()
        let dateInt = today.setDate(today.getDate() + getDate);
        return new Date(dateInt);
    }

    fieldManage(formFields, fieldData) {
        console.log(formFields);
        formFields.map(formFieldsResp => {
            if (formFieldsResp.hasOwnProperty('fieldList')) {
                formFieldsResp.fieldList.map(fieldResp => {
                    // console.log(fieldResp)
                    fieldData.map(resp => {

                        if (fieldResp.fieldId == resp.fieldId) {
                            if (fieldResp.hidden == false) {
                                resp['readonly'] = false;
                                resp.visible = true;

                            } else if (fieldResp.hidden == true) {
                                resp['readonly'] = false;
                                resp.visible = false;
                            }
                        }
                    })
                })
            }
        });
    }

    valueConversion(srcData) {
        let finalData: any = [];

        srcData.map(resp => {
            let innerArr = [];
            let innerJson: any = {};
            Object.keys(resp).map(key => {
                let fieldKey;
                let values;
                let addonArr = [];
                if (key == "addons") {

                    resp[key].map(addonData => {
                        let innerAddonArr: any[] = [];
                        Object.keys(addonData).map(addonSplit => {
                            if (typeof addonData[addonSplit] == "object" && addonData[addonSplit].fieldColumn == 'rate') {
                                addonData[addonSplit].fieldColumn = addonSplit;
                                addonData[addonSplit].addonName = addonData.addonName;
                                addonData[addonSplit].dataId = addonData.dataId;
                                let obj = {
                                    fieldKey: addonData[addonSplit].fieldColumn,
                                    values: addonData[addonSplit]
                                }
                                innerAddonArr.push(obj);
                            }
                        });
                        addonArr.push(innerAddonArr)

                    })
                    let jsonData = {
                        "fieldCaption": "Addon Services",
                        "fieldColumn": "addonServices",
                        // "isRequired": "0",
                        // "isHidden": 0,
                        "fieldOrder": 0,
                        "fieldType": "tableAddon",
                        // "validationRegex": "",
                        // "fieldHelpText": "",
                        // "fieldHelpTextLong": "",
                        // "additionalMetaData": null,
                        // "validationMessage": "",
                        "visible": true,
                        'addonServices': addonArr
                    };
                    fieldKey = jsonData.fieldColumn;
                    values = jsonData;
                } else if (key == "proflePic") {
                    console.log(key);
                    let innerJson = {};
                    let userToken;

                    if (resp[key] == null) {
                        innerJson['logo'] = 'assets/user.jpg';
                    } else {
                        if (this.authGuardService.getLoginUser()) {
                            userToken = this.authGuardService.getLoginUser().tokenId;
                        }
                        innerJson['logo'] = this.config.M_RESIZE_IMAGE_PATH + resp[key] + '?Token=' + userToken;
                    }

                    innerArr.push({
                        fieldKey: 'profileDetails',
                        values: innerJson
                    })

                    fieldKey = key;
                    values = resp[key];
                } else if (key == 'dProflePic') {
                    console.log(resp[key]);
                    let innerJson = {};
                    let userToken;

                    if (resp[key] == null) {
                        innerJson['logo'] = 'assets/user.jpg';
                    } else {
                        if (this.authGuardService.getLoginUser()) {
                            userToken = this.authGuardService.getLoginUser().tokenId;
                        }
                        innerJson['logo'] = this.config.M_RESIZE_IMAGE_PATH + resp[key].value + '?Token=' + userToken;
                    }

                    innerArr.push({
                        fieldKey: 'depProfileDetails',
                        values: innerJson
                    })

                    fieldKey = key;
                    values = resp[key];
                }

                // }
                else if (key == "noOfResource") {
                    resp[key].value = resp[key].value + "  Resources";
                    resp[key].refValue = resp[key].value;

                    fieldKey = key;
                    values = resp[key];
                } else if (key == 'workflowDetails') {
                  Object.keys(resp[key]).map(workflowDetailsResp => {
                    if (workflowDetailsResp == 'stageName') {
                        resp[key]['value'] = resp[key][workflowDetailsResp];
                    }
                  });
                  
                  fieldKey = key;
                  values = resp[key];
                } else {
                    // if (key == 'dataId') {
                    //     resp.dataId = {
                    //         value: resp.dataId
                    //     }
                    // }
                    // if (resp[key] != null && resp[key].fieldType === "termsReferenceList") {

                    //     let splitValue = resp[key].value;
                    //     let subData = resp[key];
                    //     let term_data = { "termSetId": resp[key].additionalMetaData.termsReferenceListId };
                    //     this.service.getTerms(term_data).subscribe(resp => {
                    //         if (resp.status == 'success') {
                    //             for (var keys in resp.data) {
                    //                 if (splitValue === keys) {
                    //                     splitValue = resp.data[keys];
                    //                 }
                    //             }
                    //             subData.value = splitValue;
                    //         }
                    //     })
                    // } else if (resp[key] != null && resp[key].fieldType === "customList") {

                    //     let splitValue = Number(resp[key].value);
                    //     let subData = resp[key];
                    //     let custom_data;
                    //     if (key == "country") {
                    //         custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": subData.value }
                    //     } else if (key == "planNameIfAny") {
                    //         custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": subData.value }
                    //     } else if (key == "visaTypeIfAny") {
                    //         custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": subData.value }
                    //     } else if (key == "documentChecklist") {
                    //         custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": subData.value };
                    //     }
                    //     this.service.getCustomList(custom_data).subscribe(resp => {
                    //         if (resp.status == 'success') {
                    //             for (var keys in resp.data) {
                    //                 if (splitValue === Number(keys)) {
                    //                     splitValue = resp.data[keys];
                    //                 }
                    //             }
                    //             subData.value = splitValue;
                    //         }
                    //     })
                    // }

                    fieldKey = key;
                    values = resp[key];
                }

                if (values != null && values != '') {
                    let obj = {
                        fieldKey: fieldKey,
                        values: values
                    }

                    innerArr.push(obj);
                }
                // if (Object.keys(innerJson).length > 0) {
                //     innerArr.push({
                //         fieldKey: 'dependentName',
                //         values: innerJson
                //     })
                // }
            })
            innerArr.sort((a, b) => a.values.fieldOrder - b.values.fieldOrder);
            finalData.push(innerArr);
        });

        console.log(finalData);
        return finalData;
    }

    buildView(srcData, arrAlterData = null) {
        console.log(JSON.parse(JSON.stringify(srcData)));

        let finalData = this.valueConversion(srcData);

        let innerFinalData;
        if (arrAlterData != '' && arrAlterData != null) {
            if (arrAlterData.operation == 'edit') {
                console.log(arrAlterData.oldData, finalData)
                innerFinalData = arrAlterData.oldData;
                finalData.map((finalData) => {
                    finalData.map(finalDataResp => {

                        innerFinalData.map((alterResp, index) => {
                            alterResp.map((innerResp) => {
                                if (finalDataResp.fieldKey == 'dataId' && innerResp.fieldKey == 'dataId') {
                                    if (finalDataResp.values == innerResp.values) {
                                        let filterAlterResp = finalData.filter(items => {
                                            if (typeof items.values == 'object' && items.values != null) {
                                                return items;
                                            }
                                        })
                                        filterAlterResp.map(resp => {

                                            alterResp.map(innerResp => {
                                                if (typeof innerResp.values == 'object') {
                                                    if (resp.values.fieldId == innerResp.values.fieldId) {
                                                        innerResp.values = resp.values;
                                                        innerResp.values['refValue'] = resp.values['value'];
                                                    }
                                                }
                                            })
                                        })
                                        innerFinalData[index] = alterResp;
                                    }
                                }
                            })
                        })
                    })
                })
                finalData = innerFinalData;
            } else if (arrAlterData.operation == 'add') {
                arrAlterData.oldData.push(finalData[0]);
                finalData = arrAlterData.oldData;
            }
        } else {
            finalData = finalData;
        }

        return finalData;
    }

}