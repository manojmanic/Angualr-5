import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Constants } from '../../constants';
import 'rxjs/Rx'; 


@Injectable()
export class DownloadService {

  constructor(private http: Http,
    private config: Constants) { }

  public getFile(path: any):Observable<Blob>{
    let options = new RequestOptions({
      responseType: ResponseContentType.Blob
    });

    return this.http.get(path,options)
    .map((res: Response) => <Blob>res.blob())
  }

}
