import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ObjectKeysPipe } from './object-keys/object-keys.pipe';
import { LimitToPipe } from './limit-to/limit-to.pipe';
import { ObjectFilterPipe } from './object-filter/object-filter.pipe';
import { SafehtmlPipe } from './safehtml/safehtml.pipe';
import { Nl2brPipe } from './nl2br/nl2br.pipe';
import { StringFormatPipe } from './string-format/string-format.pipe';

@NgModule({
  imports: [
    CommonModule,
    
  ],
  declarations: [
    ObjectKeysPipe,
    LimitToPipe,
    ObjectFilterPipe,
    SafehtmlPipe,
    Nl2brPipe,
    StringFormatPipe
  ],
  exports:[
    ObjectKeysPipe,
    LimitToPipe,
    ObjectFilterPipe,
    SafehtmlPipe,
    Nl2brPipe,
    StringFormatPipe
  ]
})
export class PipeModule { }
