import {Pipe, PipeTransform} from "@angular/core";


@Pipe({name: "stringFormat"})
export class StringFormatPipe implements PipeTransform {
    transform(value: string, args?: any[]): string {
      
        // For each argument
        for(var key in args) {
          let re = new RegExp("{{" + key + "}}", 'g');
          value = value.replace(re, args[key])
        }
      
        return value;
    }
}