import { StringFormatPipe } from './string-format.pipe';

describe('StringFormatPipe', () => {
  it('create an instance', () => {
    const pipe = new StringFormatPipe();
    expect(pipe).toBeTruthy();
  });
});
