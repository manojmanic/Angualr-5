import { ObjectKeysPipe } from './object-keys.pipe';

describe('ObjectKeysPipe', () => {
  it('create an instance', () => {
    const pipe = new ObjectKeysPipe();
    expect(pipe).toBeTruthy();
  });
});
