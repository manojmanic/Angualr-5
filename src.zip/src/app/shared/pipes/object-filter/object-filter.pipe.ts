// import { Pipe, PipeTransform } from '@angular/core';
// import { Filters } from './object-filter.model';

// @Pipe({
//   name: 'objectFilter'
// })
// export class ObjectFilterPipe implements PipeTransform {

//   // transform(value: any, typeChecker?: any, filterKey?: any, filterString?: any, filterCondition?: any, nullEmptyCheckData?: any): any {
//   transform(value: any, typeChecker?: any, filters?: Filters): any {    
//     let loopArr;

//     if (value.length)
//       loopArr = this.arrayFilter(value, filters);
//     else
//       loopArr = this.objectFilter(value, filters);

//     let returnData = loopArr;


//     if (typeChecker) {
//       returnData = this.typeFilter(returnData, typeChecker);
//     }
//     return returnData;
//   }
  
//   protected nullEmptyCheckFilter(filterData, nullEmptyCheckData) {
//    let returnArr = [];
//    if(nullEmptyCheckData.key != '' && nullEmptyCheckData.key) {

//       if (nullEmptyCheckData.condition == 'equal') 
//         return filterData.filter(items => items[nullEmptyCheckData.key].value == null); 
//       if (nullEmptyCheckData.condition == 'not') 
//         return filterData.filter(items => items[nullEmptyCheckData.key].value != null); 
  
//    }
    
//   }
  
//   protected typeFilter(filterData, typeChecker) {
//     if (typeChecker.key && typeChecker.key != '') {
//       return filterData.filter(items => (items[typeChecker.key] != null && typeof items[typeChecker.key] === typeChecker.type));
//     } else {
//       return filterData.filter(items => typeof items === typeChecker.type);
//     }
//   }

//   protected arrayFilter(filterData, filters: Filters) {
//     filterData = Array.from(filterData);
//     if (filters.key && filters.string) {
//       let filterStringArr;
//       if (typeof filters.string == 'string' || typeof filters.string == 'number')
//         filterStringArr = filters.string.toString().split(',');
//       else
//         filterStringArr = filters.string;

      
//       if (filters.condition === 'not')
//         return filterData.filter(items => !filterStringArr.includes(items[filters.key]));
//       else if (filters.condition === 'equal')
//         return filterData.filter(items => filterStringArr.includes(items[filters.key]));
//       else
//         return filterData.filter(items => filterStringArr.includes(items[filters.key]));
//     } else {
//       return [];
//     }
//   }

//   protected objectFilter(filterData, filters) {
//     // filterData = Object.values(filterData);
//     let returnArr = [];
//     Object.keys(filterData).map(resp => {
//       if (filters.key && filters.string) {
//         let filterStringArr;
//         if (typeof filters.string == 'string' || typeof filters.string == 'number')
//         filterStringArr = filters.string.toString().split(',');
//       else
//         filterStringArr = filters.string;

//         if (filters.condition == 'not') {
//           if (!filterStringArr.includes(resp)) {
//             returnArr.push(filterData[resp]);
//           }
//         } else if (filters.condition == 'equal') {
//           if (filterStringArr.includes(resp)) {
//             returnArr.push(filterData[resp]);
//           }
//         } else {
//           if (filterStringArr.includes(resp)) {
//             returnArr.push(filterData[resp]);
//           }
//         }
//       } else {
//         returnArr.push(filterData[resp]);
//       }
//     });
//     return returnArr;
//   }

// }







//////////////////////// Old Code ///////////////////////////


import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'objectFilter'
})
export class ObjectFilterPipe implements PipeTransform {

  transform(value: any, args?: any, filterKey?: any, filterString?: any, filterCondition?: any, nullEmptyCheckData?: any): any {
    let loopArr, test = null;

    if (value.length)
      loopArr = this.arrayFilter(value, filterKey, filterString, filterCondition);
    else
      loopArr = this.objectFilter(value, filterKey, filterString, filterCondition);

    let returnData = loopArr;


    if (args) {
      returnData = this.typeFilter(returnData, args);
    }
    if (nullEmptyCheckData) {
      returnData = this.nullEmptyCheckFilter(returnData, nullEmptyCheckData);
    }
    return returnData;
  }
  // demoJson = [{
  //   fieldKey:'demo',
  //   values:{
  //     value:{
  //       hie:'hai'
  //     }
  //   }
  // }]
  
  protected nullEmptyCheckFilter(filterData, nullEmptyCheckData) {
   let returnArr = [];
   if(nullEmptyCheckData.key != '' && nullEmptyCheckData.key) {
    // return filterData.filter(items => items[nullEmptyCheckData.key].value != '' && items[nullEmptyCheckData.key].value != null); 
      if (nullEmptyCheckData.condition == 'equal') 
      return filterData.filter(items => items[nullEmptyCheckData.key].value == null  && items[nullEmptyCheckData.key].value == '' ); 
      if (nullEmptyCheckData.condition == 'not') 
      return filterData.filter(items => items[nullEmptyCheckData.key].value != null && items[nullEmptyCheckData.key].value != '' ); 
  
   }


    
  }
  protected typeFilter(filterData, args) {
    if (args.key && args.key != '') {
      return filterData.filter(items => (items[args.key] != null && typeof items[args.key] === args.type));
    } else {
      return filterData.filter(items => typeof items === args.type);
    }
  }

  protected arrayFilter(filterData, filterKey, filterString, filterCondition) {
    filterData = Array.from(filterData);
    if (filterKey && filterString != undefined) {
      let filterStringArr;
      if (typeof filterString == 'string')
        filterStringArr = filterString.split(',');
      else
        filterStringArr = filterString;
      if (filterCondition == 'not')
        return filterData.filter(items => !filterStringArr.includes(items[filterKey]));
      else if (filterCondition == 'equal')
        return filterData.filter(items => filterStringArr.includes(items[filterKey]));
      else
        return filterData.filter(items => filterStringArr.includes(items[filterKey]));
    } else {
      return filterData;
    }
  }

  protected objectFilter(filterData, filterKey, filterString, filterCondition) {
    // filterData = Object.values(filterData);
    let returnArr = [];
    Object.keys(filterData).map(resp => {
      if (filterKey && filterString != undefined) {
        let filterStringArr;
        if (typeof filterString == 'string')
          filterStringArr = filterString.split(',');
        else
          filterStringArr = filterString;

        if (filterCondition == 'not') {
          if (!filterStringArr.includes(resp)) {
            returnArr.push(filterData[resp]);
          }
        } else if (filterCondition == 'equal') {
          if (filterStringArr.includes(resp)) {
            returnArr.push(filterData[resp]);
          }
        } else {
          if (filterStringArr.includes(resp)) {
            returnArr.push(filterData[resp]);
          }
        }
      } else {
        returnArr.push(filterData[resp]);
      }
    });
    return returnArr;
  }

}
