import { ObjectFilterPipe } from './object-filter.pipe';

describe('ObjectFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ObjectFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
