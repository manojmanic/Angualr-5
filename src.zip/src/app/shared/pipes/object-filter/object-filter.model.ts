export class Filters{
    key: string;
    string: any;
    condition: string;
}