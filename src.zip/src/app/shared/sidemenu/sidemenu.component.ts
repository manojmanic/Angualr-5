import { Component, ViewChild, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { AuthGuardService } from '../guard/auth-guard.service';
import {
    ObservableMedia
} from '@angular/flex-layout';
@Component({
    selector: 'app-sidemenu',
    templateUrl: './sidemenu.component.html',
    styleUrls: ['./sidemenu.component.scss']
})
export class SidemenuComponent implements OnInit {
    @ViewChild('sidemenu') sidemenu; // get your template reference in the component
    menuItems: any;
    isLogin;
    currentUser;
    menuFunc = {};
    
    constructor(
        // private sharedService: SharedService,
        private authGuardService: AuthGuardService,
        private screenTB: ScreenTemplateJsonBuilder,
    ) {
        this.menuItems = this.screenTB.siteMenu();
        this.isLogin = this.authGuardService.isLogin;
        this.currentUser = this.authGuardService.getLoginUser();
        this.authGuardService.setLogin.subscribe(resp => {
            this.isLogin = resp['isLogin'];
            this.currentUser = resp['currentUser'];
        });
    }

    private sideNavSub;
    ngOnInit() {
        //this.sideNavSub = this.sideNavService.openNav$.subscribe(() => this.sidemenu.open());
        // document.getElementById("navList").innerHTML = this.menuBuilder("0");
        
    }
    OnDestroy() {
        //this.sideNavSub.unsubscribe(); // clean your subscriptions
    }


    @Output() sideMenuClose = new EventEmitter<boolean>();
    sideBarClose() {
        this.sideMenuClose.emit(true);
    }

}
