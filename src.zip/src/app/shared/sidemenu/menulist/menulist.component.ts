import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel, RoutesRecognized } from '@angular/router';

@Component({
  selector: 'app-menulist',
  templateUrl: './menulist.component.html',
  styleUrls: ['./menulist.component.scss']
})
export class MenulistComponent implements OnInit {

  @Input() menuItems;
  currentUrl;

  constructor(private router: Router) {
  }

  ngOnInit() {
    
    this.currentUrl = this.router.url;
    this.router.events.forEach((event) => {
        if(event instanceof NavigationStart) {
        }

        if(event instanceof NavigationEnd) {
          this.currentUrl = event.url;
          
        }

        if(event instanceof NavigationCancel) {
        }

        if(event instanceof NavigationError) {
        }
    });
  }

  routeBuild(menu): string {
    
    return menu.mPath + '/' + menu.caseId;
  }

  activeUrl(menu) {
    return (this.currentUrl=== '/'+this.routeBuild(menu));
  }



  @Output() sideMenuClose = new EventEmitter<boolean>();
  sideBarClose() {
    this.sideMenuClose.emit(true);
  }

  menuStyle(menu){
    if(menu.mLevel == 1){
      return "0px";
    }

    return menu.mLevel*15+"px";
  }

  ///////// Expansion Menu Configuration ////////////////
  expansionPanel(event) {
    let el = event.target;
    let icon, level = "0", expand = "0";
    // let colorArr = ['#cacaca', '#aad7da', '#dedede'];
    // let randomColor = colorArr[Math.floor(Math.random() * colorArr.length)];
    let elcl = el.closest('.mat-nav-list');
    let iconCl = el.closest('.menuLink');
    let activeCl = el.closest('.menuItem');
    let closestExpansion = elcl.closest('.mainMenu');
    let panel = elcl.querySelector('.mainMenu');
    if (iconCl) {
      icon = (iconCl).querySelector('.mat-icon');
      level = (<HTMLDivElement>iconCl).getAttribute('data-level');
      expand = (<HTMLDivElement>iconCl).getAttribute('data-expand');
    }

    if((<HTMLElement>elcl).classList.contains('open')){
      (<HTMLElement>elcl).classList.remove('open');
      return false;
    }

    let activeLinkArr = document.querySelectorAll('.mat-nav-list');
    if (activeLinkArr.length) {
      Array.from(activeLinkArr).map(element => {
        (<HTMLElement>element).classList.remove('open');
      });
    }

    this.expansionClass(elcl);

    if (panel && expand == "1") {
      // panel.style.removeProperty('background');
      if (panel.style.maxHeight) {
        // if (icon)
        //   icon.style = "transform: rotate(0deg); transition: all 0.5s ease-out;";
        // panel.style = "max-height:null;";
      } else {
        // if (icon)
        //   icon.style = "transform: rotate(180deg); transition: all 0.5s ease-out;";
        // panel.style = "max-height:" + panel.scrollHeight + "px";
        // panel.style = "max-height:initial;";
      }
    }
  }

  expansionClass(element){
    let expandEl = element.closest('.expansion');
    if(element.querySelector('.mainMenu'))
      element.classList.add('open');
    if(expandEl){
      expandEl.parentElement.classList.add('open');
      this.expansionClass(expandEl.parentElement);
    }
  }
}
