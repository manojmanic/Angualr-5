import { Component, OnInit, ElementRef } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../shared/models/question-checkbox';
import { CustomQuestion } from '../../../shared/models/question-custom';
import { QuestionBase } from '../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import {AlertService} from '../../../shared/services/alert-service.service';
import { AbstractControl } from '@angular/forms';
import { Constants } from '../../../constants';
@Component({
  selector: 'app-resourcedialog',
  templateUrl: './resourcedialog.component.html',
  styleUrls: ['./resourcedialog.component.scss']
})
export class ResourcedialogComponent implements OnInit {

  questions: QuestionBase<any>[] = [];
  selectedAddonsArr: any = {};
  requirementDetails: any;
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  formBuildBaseObj: any;
  formObject: any;
  menuItems: any;
  resourceId: any;
  buildData: any;
  cancelButton: any;
  buttonData:any;
  _touched:boolean
  caseid;
  reqId: any;
  noOfResource: any;
  ngOnInit() {
    // this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formAdd(this.caseid);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu() 
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
     
      this.buildData = data.data;
      
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
          let changed = eventCalls[preBuildEvFn](param);
          this.buttonData = changed.buttonData;
          this.buildData = changed.formItems;
          this.cancelButton = changed.cancelButton;

        }
      }
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      //   });
      // this.buildForm(this.buildData);
      setTimeout(() => {
        let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
        this.questions = buildData['fields'];
        this.form = buildData['controls'];
        console.log(buildData, this.buildData, this.formBuildBaseObj.showFields);
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions, requirementData: this.requirementDetails[0] };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
      }, this.config.FORM_LOADING_SEC);
    })
  }
  constructor(public dialogRef: MatDialogRef<ResourcedialogComponent>,
    private el: ElementRef,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private alert: AlertService,
    private config: Constants,
    private route: ActivatedRoute) {
  }

  addonsArr(data){
    console.log(data)
    this.selectedAddonsArr = data;
  }
  // buildForm(formData) {

  //   questions => [] = [];
  //   this.questions.length = 0;
  //   this.buildData = formData;
  //   let fieldData = [];
  //   let fieldGroupData = [];
  //   let fieldGroupIdData = [];

  //   /////// To Get fieldGroupId ///////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
  //     this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
  //   }

  //   /////// To Get FieldList /////////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     for (var j = 0; j < this.fieldGroupId.length; j++) {
  //       if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
  //         for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
  //           let pushData;
  //           pushData = this.buildData.fieldGroup[i].FieldList[k];
  //           pushData.visible = false;
  //           if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
  //             pushData.visible = true;
  //           }
  //           if (pushData.fieldType === 'shortText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'currencyText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'calcText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'text') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customListAdditionalDetail') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'simpleListMultiSelect') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'singleSelectOption') {
  //             let options = [
  //               { key: 'yes', value: 'Yes' },
  //               { key: 'no', value: 'No' },
  //             ]
  //             pushData.additionalMetaData = options;
  //             fieldData.push(new CheckboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'radio') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceListMulti') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileImage') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'date') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'tableAddon') {
  //             fieldData.push(new CustomQuestion(pushData));
  //           }
  //         }
  //       }
  //     }
  //   }
  //   this.questions = fieldData;
  //   this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
  //   this.form = this.qcs.toFormGroup(this.questions);
  //   let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
  //   if (postBuildEvFn != '') {
  //     const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
  //     if (eventCalls[postBuildEvFn]) {
  //       let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions, requirementData: this.requirementDetails[0] };
  //       let changed = eventCalls[postBuildEvFn](param);
  //     }
  //   }

  //   //  if( localStorage.getItem("post_reqId")==null) {
  //   //  this.reqId =  this.reqId; 
  //   //  }else {
  //   //    this.reqId =  localStorage.getItem("post_reqId");
  //   //  }
  // }

  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {

    console.log(this.form)
    // let addonsData = <HTMLDivElement>this.el.nativeElement.querySelector('.addonsTable');
    // let formValues = this.form.value;
    // if(addonsData != null){

    //   let addons = JSON.parse(addonsData.getAttribute('data-crtAddon'));
    //   let addonsArr = [];
    //   Object.values(addons).map(resp => {
    //     if(resp != 'none')
    //       addonsArr.push(resp);
    //   })
    // }
    let addonsValid = true;
    console.log(this.selectedAddonsArr)
    this.questions.map(resp => {
      if (resp.fieldType == 'tableAddons' && resp.fieldColumn == 'addonServices') {
        let mandatoryCount: number = 0;
        let selectedCount: number = 0;
        resp['addonServices'].map(addonsResp => {
          if (addonsResp.mandatory == true) {
            mandatoryCount++;
            if (Object.keys(this.selectedAddonsArr).length) {
              Object.keys(this.selectedAddonsArr).map(addonsArrKey => {
                console.log(addonsResp.fieldColumn, addonsArrKey)
                if (addonsResp.fieldColumn == addonsArrKey) {
                  selectedCount++;
                }
              });
            }
          }
        });
        console.log(mandatoryCount, selectedCount)
        if (mandatoryCount != selectedCount)
          addonsValid = false;
      }
    });
    // this.form.value['addons'] = this.selectedAddonsArr;
    

    this.form.patchValue({ resourceId: this.resourceId }); /// dependent
    this.form.patchValue({ reqId:this.reqId}); /// resource
     
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
      }
    }

    if (this.form.valid && addonsValid) {
      Object.keys(this.form.controls).map(fieldArrData => {
        let fieldKey = fieldArrData;
        let fieldData = this.form.controls[fieldKey]
        for (var question of this.questions) {
          if (question.fieldType === 'date') {
            var currentDate = new DatePipe('en-us');
            let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
            if (final != null)
            this.form.value[ question.fieldColumn ] = final;
          }
        }
        //  if (fieldData['nativeElement'].classList.contains('datePick')) {
        
        //   var currentDate = new DatePipe('en-us');
        //   let final = currentDate.transform(fieldData.value, 'yyyy-MM-dd')
        //   if (final != null)
        //     this.form.patchValue({ [fieldKey]: final });
        //  }
      });
      let finalselectedAddonArr:any = [];
      Object.keys(this.selectedAddonsArr).map(resp => {
       
        if (this.selectedAddonsArr[resp] != "none") {
          finalselectedAddonArr.push(this.selectedAddonsArr[resp]);
        }
      })
      this.form.value['addons'] = finalselectedAddonArr;
      
      console.log(this.form.value)
      this.service.putForms(this.form.value, this.formBuildBaseObj.formId).subscribe(data => {
         console.log(data)
        ///////////// To Populate Resource and Dependent details After Submitting ///////////////////
        if (data.status == 'success') {
          let formBuildBaseObjProDet = this.screenTB.formEdit('ProjectDetails');
          let proDetApiData = { "formId": formBuildBaseObjProDet.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: formBuildBaseObjProDet.formId } };
          this.service.getFormData(proDetApiData).subscribe(resp => {
            console.log(JSON.parse(JSON.stringify(resp)),proDetApiData);
            let proDetJson: any = {};
            if(resp.status == 'success') {
            Object.keys(resp.data[0]).map(key => {
              if (key == 'noOfResource') {
                resp.data[0][key].value = this.noOfResource+1;
              }
              if (typeof resp.data[0][key] == 'object' && resp.data[0][key] != null) {
                // proDetJson = {
                //   [resp.data[0][key].fieldColumn]:resp.data[0][key].value
                // }
                proDetJson[resp.data[0][key].fieldColumn] = resp.data[0][key].value
                console.log(proDetJson)
              }


            })
            console.log(proDetJson,JSON.parse(JSON.stringify(resp)))
            proDetJson['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId;
            this.service.updateFormData(proDetJson, formBuildBaseObjProDet.formId, this.reqId).subscribe(resp => {
              console.log(resp)
            })
          }              
          })
          let apiData = { "formId": this.formBuildBaseObj.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: this.formBuildBaseObj.formId, rowId: data.data } };
          this.service.getFormData(apiData).subscribe(resp => {
            if (resp.status == 'success') {
              this.dialogRef.close(resp.data);
            }
            console.log(resp.data);
          })
        }
        this.alertMsg(data);
     })

    } else if(!addonsValid){
      this.alert.error("Please choose mandatory addons.");
    } else if(this.form.status == "DISABLED"){
      this.dialogRef.close();
    } else {
      this.alert.error("Please fill required fields.");
      // this.questions.map(resp=>{
      //   if(this.form.controls[resp.fieldColumn].touched==false && this.form.controls[resp.fieldColumn].status=="INVALID"){
          
      //     this.form.controls[resp.fieldColumn].markAsTouched();
          
      //   }
      // })
    }

  }

  alertMsg(resp) {
      var message = resp.message;
      var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }
}