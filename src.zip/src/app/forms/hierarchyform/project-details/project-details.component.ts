import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ProjectdetailseditComponent } from './projectdetailsedit/projectdetailsedit.component';


@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.scss']
})
export class ProjectDetailsComponent implements OnInit {
   @Input()projectDetails:any;
   @Input()projectDetailsShowFields:any;
   @Input()noOfResources:any;
   @Output() outputData = new EventEmitter()
   reqDataId:any;
   dialogProDetailsEdit: MatDialogRef<ProjectdetailseditComponent>
  constructor(
    public gfService: GlobalFunctionService,
    private dialog: MatDialog,
  ) { }

  ngOnInit() {
    
    // this.reqDataId = this.projectDet_Value.find(items=>items.fieldKey == "reqDataId");
    // this.projectDet_Value = this.projectDet_Value.filter(items=>items.fieldKey !="reqDataId")
  }
  projectDetailsEdit() {
    // console.log(this.projectDetails.find(items=> items.fieldKey == 'rowId').values)
    this.dialogProDetailsEdit = this.dialog.open(ProjectdetailseditComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.dialogProDetailsEdit.componentInstance.caseId = "ProjectDetails";
      this.dialogProDetailsEdit.componentInstance.projectDetails = this.projectDetails;
      this.dialogProDetailsEdit.componentInstance.noOfResources = this.noOfResources;
      this.dialogProDetailsEdit.afterClosed().subscribe(resp => {
        if (resp) {
          
           this.outputData.next(resp);
        }
      });
  }

}
