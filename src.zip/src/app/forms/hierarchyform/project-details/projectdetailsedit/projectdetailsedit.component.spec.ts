import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectdetailseditComponent } from './projectdetailsedit.component';

describe('ProjectdetailseditComponent', () => {
  let component: ProjectdetailseditComponent;
  let fixture: ComponentFixture<ProjectdetailseditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectdetailseditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectdetailseditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
