import { Component, OnInit } from '@angular/core';
import { ScreenTemplateJsonBuilder } from '../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalformService } from '../../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../../shared/services/globalform-control.service';
import { FormBuildFunctionsService } from '../../../../shared/common/form-build-functions.service';
import { FormBuildBaseService } from '../../../formbuilds/form-build-base.service';
import { AlertService } from '../../../../shared/services/alert-service.service';
import { QuestionBase } from '../../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { TextboxQuestion } from '../../../../shared/models/question-textbox';
import { DropdownQuestion } from '../../../../shared/models/question-dropdown';
import { CheckboxQuestion } from '../../../../shared/models/question-checkbox';
import { MatDialogRef } from '@angular/material';
import { DatePipe } from '@angular/common';
import { AbstractControl } from '@angular/forms';
import { Constants } from '../../../../constants';
@Component({
  selector: 'app-projectdetailsedit',
  templateUrl: './projectdetailsedit.component.html',
  styleUrls: ['./projectdetailsedit.component.scss']
})
export class ProjectdetailseditComponent implements OnInit {

  caseId: any;
  projectDetails: any = [];
  formBuildBaseObj: any;
  form_title: any;
  menuItems: any;
  questions: QuestionBase<any>[] = [];
  buildData: any;
  buttonData: any;
  cancelButton: any;
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  reqDataId: any;
  _touched: boolean;
  noOfResources: any;
  constructor(
    public dialogRef: MatDialogRef<ProjectdetailseditComponent>,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private alert: AlertService,
    private config: Constants
  ) {

  }

  ngOnInit() {
    // this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formEdit(this.caseId);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      this.buildData = data.data;
     
      let apiData = { "formId": this.formBuildBaseObj.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: this.formBuildBaseObj.formId } };
      this.service.getFormData(apiData).subscribe(data => {
        console.log(data)
        // resp.data.map(innerResp =>{
        //   Object.keys(innerResp).map(key =>{
        //     fieldData.map(fieldResp =>{
        //     if(innerResp[key] != null && typeof innerResp[key] == 'object') {
        //       if(innerResp[key].fieldType == fieldResp.fieldType) {
        //         if(innerResp[key].fieldColumn == fieldResp.fieldColumn) {
        //          fieldResp.value = innerResp[key].value;
        //          //  if(innerResp[key].fieldColumn == 'noOfResource' && this.noOfResources != 0) {
        //          //   fieldResp.value = this.noOfResources;
        //          //  }else {
        //          //   fieldResp.value = innerResp[key].value;
        //          //  }
        //       }
        //       }
        //     }
        //    })
        //   })
        // })

        if (data.status == 'success') {
          console.log(data)
          let formGroups = this.buildData.fieldGroup;
          formGroups.filter(formGroupsData => {
            let formFields = formGroupsData.FieldList;
            formFields.filter(resp => {
              data.data.map(innerResp => {
                Object.keys(innerResp).map(key => {
                  if (typeof innerResp[key] == 'object' && innerResp[key] != null) {
                    if (innerResp[key].fieldId == resp.fieldId) {
                      resp.value = innerResp[key].value;
                    }
                  }
                })
              })

            })
          })
        }
        let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
            let changed = eventCalls[preBuildEvFn](param);
            this.buttonData = changed.buttonData;
            this.buildData = changed.formItems;
            this.cancelButton = changed.cancelButton;
          }
        }
        setTimeout(() => {
          let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
          this.questions = buildData['fields'];
          this.form = buildData['controls'];
          let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
          if (postBuildEvFn != '') {
            const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[postBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
              let changed = eventCalls[postBuildEvFn](param);
              this.questions = changed.rawData;
            }
          }
        }, this.config.FORM_LOADING_SEC);
      })
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
    })
  }
  // buildForm(formData) {

  //   questions => [] = [];
  //   this.questions.length = 0;
  //   this.buildData = formData;
  //   let fieldData = [];
  //   let fieldGroupData = [];
  //   let fieldGroupIdData = [];

  //   /////// To Get fieldGroupId ///////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
  //     this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
  //   }

  //   /////// To Get FieldList /////////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     for (var j = 0; j < this.fieldGroupId.length; j++) {
  //       if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
  //         for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
  //           let pushData;
  //           pushData = this.buildData.fieldGroup[i].FieldList[k];
  //           pushData.visible = false;
  //           if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
  //             pushData.visible = true;
  //           }
  //           if (pushData.fieldType === 'shortText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'currencyText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'calcText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'text') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'simpleListMultiSelect') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'singleSelectOption') {
  //             let options = [
  //               { key: 'yes', value: 'Yes' },
  //               { key: 'no', value: 'No' },
  //             ]
  //             pushData.additionalMetaData = options;
  //             fieldData.push(new CheckboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'radio') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceListMulti') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileImage') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'date') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //         }
  //       }
  //     }
  //   }


  //   /////////////// Final Update ////////////////
  //   //  console.log(this.projectDetails,fieldData);
  //   let apiData = { "formId": this.formBuildBaseObj.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: this.formBuildBaseObj.formId } };
  //   this.service.getFormData(apiData).subscribe(resp => {
  //     resp.data.map(innerResp => {
  //       Object.keys(innerResp).map(key => {
  //         fieldData.map(fieldResp => {
  //           if (innerResp[key] != null && typeof innerResp[key] == 'object') {
  //             if (innerResp[key].fieldType == fieldResp.fieldType) {
  //               if (innerResp[key].fieldColumn == fieldResp.fieldColumn) {
  //                 fieldResp.value = innerResp[key].value;
  //                 //  if(innerResp[key].fieldColumn == 'noOfResource' && this.noOfResources != 0) {
  //                 //   fieldResp.value = this.noOfResources;
  //                 //  }else {
  //                 //   fieldResp.value = innerResp[key].value;
  //                 //  }
  //               }
  //             }
  //           }
  //         })
  //       })
  //     })


  //     //  console.log(fieldData)
  //     this.questions = fieldData;
  //     this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
  //     this.form = this.qcs.toFormGroup(this.questions);
  //     let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
  //     if (postBuildEvFn != '') {
  //       const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
  //       if (eventCalls[postBuildEvFn]) {
  //         let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
  //         let changed = eventCalls[postBuildEvFn](param);

  //         this.questions = changed.rawData;
  //       }
  //     }
  //   })
  // }


  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    let status;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, menuItems: this.menuItems, rawData: this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        status = changed.status;
      }
    }
    if (this.form.valid) {
      if (status != "DeActivated") {

        Object.keys(this.form.controls).map(fieldArrData => {
          let fieldKey = fieldArrData;
          let fieldData = this.form.controls[fieldKey]
          for (var question of this.questions) {
            if (question.fieldType === 'date') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            }
          }
          //  if (fieldData['nativeElement'].classList.contains('datePick')) {

          //   var currentDate = new DatePipe('en-us');
          //   let final = currentDate.transform(fieldData.value, 'yyyy-MM-dd')
          //   if (final != null)
          //     this.form.patchValue({ [fieldKey]: final });
          //  }
        });
        this.service.updateFormData(this.form.value, this.formBuildBaseObj.formId, this.projectDetails.find(items => items.fieldKey == 'rowId').values).subscribe(resp => {

          this.alertMsg(resp);
          let apiData = { "formId": this.formBuildBaseObj.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: this.formBuildBaseObj.formId } };
          this.service.getFormData(apiData).subscribe(resp => {
            this.dialogRef.close(resp.data);
          })
        });
      }
      else {
        this.alert.error("Please fill Active fields.");
      }
    } else if (this.form.status == "DISABLED") {
      this.dialogRef.close();
    } else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
      this.alert.error("Please fill required fields.");
    }
  }

  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

}
