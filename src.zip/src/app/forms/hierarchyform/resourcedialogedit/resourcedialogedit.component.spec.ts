import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResourcedialogeditComponent } from './resourcedialogedit.component';

describe('ResourcedialogeditComponent', () => {
  let component: ResourcedialogeditComponent;
  let fixture: ComponentFixture<ResourcedialogeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResourcedialogeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResourcedialogeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
