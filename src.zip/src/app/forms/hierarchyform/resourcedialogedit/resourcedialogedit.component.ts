import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import { AlertService } from '../../../shared/services/alert-service.service';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { AbstractControl } from '@angular/forms';
import { Constants } from '../../../constants';

@Component({
  selector: 'app-resourcedialogedit',
  templateUrl: './resourcedialogedit.component.html',
  styleUrls: ['./resourcedialogedit.component.scss']
})
export class ResourcedialogeditComponent implements OnInit {

  questions: QuestionBase<any>[] = [];
  requirementDetails: any;
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  formBuildBaseObj: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  resourceId;
  dependentId;
  buildData: any
  updatedId: any;
  buttonData: any;
  cancelButton: any;
  caseid: any;
  _touched:boolean
  selectedAddonsArr: any = {};
  rowId:any;
  loopdata:any;
  totalResource:any;
  ngOnInit() {
    // this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formEdit(this.caseid);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      if(data.status == 'success') {
      this.buildData = data.data;
   
      let apiData = { "formId": this.formBuildBaseObj.formId,transactionId:JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId:JSON.parse(localStorage.getItem("currentUser")).transactionId,formId: this.formBuildBaseObj.formId,rowId:this.rowId } };
      this.service.getFormData(apiData).subscribe(data =>{
        console.log(data);
        if(data.status == 'success') {
          let formGroups = this.buildData.fieldGroup;
          formGroups.filter(formGroupsData => {
            let formFields = formGroupsData.FieldList;
            formFields.filter(resp => {
          data.data.map(innerResp =>{
           Object.keys(innerResp).map(key =>{
             if(typeof innerResp[key] == 'object' && innerResp[key] != null) {
               if(innerResp[key].fieldId == resp.fieldId) {
                 resp.value = innerResp[key].value;
               }
             }
           })
          })
        
      })
    })
      }
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
          let changed = eventCalls[preBuildEvFn](param);
          this.buttonData = changed.buttonData;
          this.buildData = changed.formItems;
          this.cancelButton = changed.cancelButton;

        }
      }
      setTimeout(() => {
        let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
        this.questions = buildData['fields'];
        this.form = buildData['controls'];
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions, requirementData: this.requirementDetails[0],respData:this.loopdata };
            let changed = eventCalls[postBuildEvFn](param);
            this.questions = changed.rawData;
          }
        }
      }, this.config.FORM_LOADING_SEC);
      })
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
    }
    })
  }
  constructor(public dialogRef: MatDialogRef<ResourcedialogeditComponent>,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private config : Constants,
    private alert: AlertService,
    private route: ActivatedRoute) {

  }
  addonsArr(data) {
    this.selectedAddonsArr = data;
  }
//   buildForm(formData) {
//     questions => [] = [];
//     this.questions.length = 0;
//     this.buildData = formData;
//     let fieldData = [];
//     let fieldGroupData = [];
//     let fieldGroupIdData = [];

//     /////// To Get fieldGroupId ///////////////////
//     for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
//       this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
//       this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
//     }

//     /////// To Get FieldList /////////////////////
//     for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
//       for (var j = 0; j < this.fieldGroupId.length; j++) {
//         if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
//           for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
//             let pushData;
//             pushData = this.buildData.fieldGroup[i].FieldList[k];
//             pushData.visible = false;
//             if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
//               pushData.visible = true;
//             }
//             if (pushData.fieldType === 'shortText') {
//               fieldData.push(new TextboxQuestion(pushData));
//             }
//             if (pushData.fieldType === 'currencyText') {
//               fieldData.push(new TextboxQuestion(pushData));
//             }
//             if (pushData.fieldType === 'calcText') {
//               fieldData.push(new TextboxQuestion(pushData));
//             }
//             if (pushData.fieldType === 'text') {
//               fieldData.push(new TextboxQuestion(pushData));
//             }
//             if (pushData.fieldType === 'customList') {
//               fieldData.push(new DropdownQuestion(pushData));
//             }
//             if (pushData.fieldType === 'customListAdditionalDetail') {
//               fieldData.push(new DropdownQuestion(pushData));
//             }
//             if (pushData.fieldType === 'simpleListMultiSelect') {
//               fieldData.push(new DropdownQuestion(pushData));
//             }
//             if (pushData.fieldType === 'singleSelectOption') {
//               let options = [
//                 { key: 'yes', value: 'Yes' },
//                 { key: 'no', value: 'No' },
//               ]
//               pushData.additionalMetaData = options;
//               fieldData.push(new CheckboxQuestion(pushData));
//             }
//             if (pushData.fieldType === 'radio') {
//               fieldData.push(new DropdownQuestion(pushData));
//             }
//             if (pushData.fieldType === 'termsReferenceList') {
//               fieldData.push(new DropdownQuestion(pushData));
//             }
//             if (pushData.fieldType === 'termsReferenceListMulti') {
//               fieldData.push(new DropdownQuestion(pushData));
//             }
//             if (pushData.fieldType === 'fileImage') {
//               fieldData.push(new TextboxQuestion(pushData));
//             }
//             if (pushData.fieldType === 'date') {
//               fieldData.push(new TextboxQuestion(pushData));
//             }
//           }
//         }
//       }
//     }
//     let apiData = { "formId": this.formBuildBaseObj.formId,transactionId:JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId:JSON.parse(localStorage.getItem("currentUser")).transactionId,formId: this.formBuildBaseObj.formId,rowId:this.rowId } };
//     this.service.getFormData(apiData).subscribe(data =>{
//       console.log(data,fieldData);
//       fieldData.map(resp =>{
//         data.data.map(innerResp =>{
//          Object.keys(innerResp).map(key =>{
//            if(typeof innerResp[key] == 'object' && innerResp[key] != null) {
//              if(innerResp[key].fieldId == resp.fieldId) {
//                resp.value = innerResp[key].value;
//              }
//            }
//          })
//         })
//       })
//     // console.log(this.requirementDetails[0].rowId)
//       this.questions = fieldData;
//       this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
//       this.form = this.qcs.toFormGroup(this.questions);
//       let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
//       if (postBuildEvFn != '') {
//         const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
//         if (eventCalls[postBuildEvFn]) {
//           let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions, requirementData: this.requirementDetails[0],respData:this.loopdata };
//           let changed = eventCalls[postBuildEvFn](param);
//         }
//       }
//     })

// }
 
markAsTouched() {
  this._touched = true;
}


  onSubmit() {
    let getFormDataselectedArr: any = {};
    console.log(this.form)
    /////////// Store pre-selected addon //////////////
    this.questions.map(resp => {
      if (resp.fieldType == 'tableAddons' && resp.fieldColumn == 'addonServices') {
        resp['addonServices'].map(addonsResp => {
          addonsResp.values.map(addonsVal => {
            if (addonsVal.selected) {
              getFormDataselectedArr[addonsVal.addonId] = addonsVal;
            }
          })
        });
      }
    });
    ////////////// To remove selected key /////////////
    this.questions.map(resp => {
      if (resp.fieldType == 'tableAddons' && resp.fieldColumn == 'addonServices') {
        resp['addonServices'].map(addonsResp => {
          addonsResp.values.map(addonsVal => {
            if (addonsVal.selected) {
              delete addonsVal.selected;
            }
          })
        });
      }
    });
    /////////// To get data from selectedAddonArr ///////////////
    if (Object.keys(this.selectedAddonsArr).length) {
      Object.keys(this.selectedAddonsArr).map(selectVal => {
        Object.keys(getFormDataselectedArr).map(testVal => {
          if (selectVal == testVal) {
            delete getFormDataselectedArr[testVal];
          }
        })
      })
    }
    /////////// To merge selectedAddonArr and preSelected data ///////////
    this.selectedAddonsArr = this.gfService.JSONMerge(getFormDataselectedArr, this.selectedAddonsArr);
    let finalselectedAddonArr: any = [];
    Object.keys(this.selectedAddonsArr).map(resp => {
     // console.log(this.selectedAddonsArr[resp])
      if (this.selectedAddonsArr[resp] != "none") {
        finalselectedAddonArr.push(this.selectedAddonsArr[resp]);
      }
    })
    let status;
    this.form.patchValue({ resourceId: this.resourceId }); /// dependent
    this.form.patchValue({ reqId: this.requirementDetails[0].rowId }); /// resource
    // console.log(this.form)
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems,questions:this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        status = changed.status;
      }
    }
    let addonsValid = true;
    console.log(this.selectedAddonsArr)
    this.questions.map(resp => {
      if(resp.fieldType == 'tableAddons' && resp.fieldColumn == 'addonServices'){
        let mandatoryCount: number = 0;
        let selectedCount: number = 0;
        resp['addonServices'].map(addonsResp => {
          if(addonsResp.mandatory == true){
            mandatoryCount++;
            if(Object.keys(this.selectedAddonsArr).length){
              Object.keys(this.selectedAddonsArr).map(addonsArrKey => {
                console.log(addonsResp.fieldColumn,addonsArrKey)
                if(addonsResp.fieldColumn == addonsArrKey){
                  selectedCount++;
                }
              });
            }
          }
        });
        console.log(mandatoryCount,selectedCount)
        if(mandatoryCount != selectedCount)
          addonsValid = false;
      }
    });
    // console.log(this.form.value)
    if (this.form.valid && addonsValid) {
      if (status != "DeActivated") {
        Object.keys(this.form.controls).map(fieldArrData => {
          let fieldKey = fieldArrData;
          let fieldData = this.form.controls[fieldKey]
          for (var question of this.questions) {
            if (question.fieldType === 'date') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            }
          }
          //  if (fieldData['nativeElement'].classList.contains('datePick')) {
          //   console.log(fieldArrData);
          //   var currentDate = new DatePipe('en-us');
          //   let final = currentDate.transform(fieldData.value, 'yyyy-MM-dd')
          //   if (final != null)
          //     this.form.patchValue({ [fieldKey]: final });
          //  }
        });
        this.alert.success("success.");
        this.form.value['addons'] = finalselectedAddonArr;
        console.log(finalselectedAddonArr)
        // console.log(this.form);
        this.service.updateFormData(this.form.value, this.formBuildBaseObj.formId, this.rowId).subscribe(data => {
          //  console.log(data)ProjectDetails
           if(data.status == 'success') {
            let apiData = { "formId": this.formBuildBaseObj.formId,transactionId:JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId:JSON.parse(localStorage.getItem("currentUser")).transactionId,formId: this.formBuildBaseObj.formId,rowId:this.rowId } };
            this.service.getFormData(apiData).subscribe(resp =>{
              if(resp.status == 'success') {
                this.dialogRef.close(resp.data);
              }
              console.log(resp.data);
            })
           }

        })
      }
      else {
        this.alert.error("Please Select Active Visa Name");
      }
    } else if(this.form.status == "DISABLED"){
      this.dialogRef.close();
    } else if(!addonsValid){
      this.alert.error("Please choose mandatory addons.");
    } else {
      this.alert.error("Please fill required fields.");
      this.questions.map(resp=>{
        // if(this.form.controls[resp.fieldColumn].touched==false && this.form.controls[resp.fieldColumn].status=="INVALID"){
          
        //   // this.form.controls[resp.fieldColumn].markAsTouched();
          
        // }
      })
    }

  }

}
