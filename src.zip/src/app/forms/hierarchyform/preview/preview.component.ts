import { Component, OnInit, Input, ElementRef, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ResourcedialogComponent } from '../../../forms/hierarchyform/resourcedialog/resourcedialog.component';
import { ResourcedialogeditComponent } from '../../../forms/hierarchyform/resourcedialogedit/resourcedialogedit.component';
import { GlobalformService } from '../../../shared/services/globalform.service';
@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss']
})
export class PreviewComponent implements OnInit {
  @Input() prevfinalData: any;
  @Input() resourceShowFields: any;
  @Output() outputData = new EventEmitter()
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  dialogRefDetails: MatDialogRef<ResourcedialogComponent>;
  dialogRefDetailsEdit: MatDialogRef<ResourcedialogeditComponent>;
  finalData: any = [];

  constructor(private _formBuilder: FormBuilder,
    private dialog: MatDialog,
    private el: ElementRef,
    private service: GlobalformService) {

  }

  ngOnInit() {
  }
  ngOnChanges() {
    this.finalData = this.prevfinalData;
  }
  
  isNumber(val) { return typeof val === 'number'; } // To Remove empty chips
}
