import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { ScreenTemplateJsonBuilder } from '../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalformService } from '../../../../shared/services/globalform.service';

@Component({
  selector: 'app-deldialog',
  templateUrl: './deldialog.component.html',
  styleUrls: ['./deldialog.component.scss']
})
export class DeldialogComponent implements OnInit {

  resDataId: any;
  depDataId: any;
  count: any;
  caseId: any;
  formBuildBaseObj: any;
  rowId:any;
  totalResource:any;
  proDetRowId:any;
  constructor(
    public deldialog: MatDialogRef<DeldialogComponent>,
    private screenTB: ScreenTemplateJsonBuilder,
    private service:GlobalformService,
  ) {
  }

  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formAdd(this.caseId);
  }
  delete(dataId) {
    this.service.deleteForm(this.rowId,this.formBuildBaseObj.formId,JSON.parse(localStorage.getItem("currentUser")).transactionId,'').subscribe(resp=>{
      if(resp.status == "success") {
        console.log(resp);
        let formBuildBaseObjProDet = this.screenTB.formEdit('ProjectDetails');
        let proDetApiData = { "formId": formBuildBaseObjProDet.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: formBuildBaseObjProDet.formId } };
        this.service.getFormData(proDetApiData).subscribe(resp => {
          console.log(JSON.parse(JSON.stringify(resp)),proDetApiData);
          let proDetJson: any = {};
          if(resp.status == 'success') {
          Object.keys(resp.data[0]).map(key => {
            if (key == 'noOfResource') {
              resp.data[0][key].value = this.totalResource-1;
            }
            if (typeof resp.data[0][key] == 'object' && resp.data[0][key] != null) {
              // proDetJson = {
              //   [resp.data[0][key].fieldColumn]:resp.data[0][key].value
              // }
              proDetJson[resp.data[0][key].fieldColumn] = resp.data[0][key].value
              console.log(proDetJson)
            }


          })
          console.log(proDetJson,JSON.parse(JSON.stringify(resp)))
          proDetJson['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId;
          this.service.updateFormData(proDetJson, formBuildBaseObjProDet.formId, this.proDetRowId).subscribe(resp => {
            console.log(resp)
          })
        }              
        })
        this.deldialog.close(this.rowId);
      }
    })
  }

}
