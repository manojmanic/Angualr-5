import { Component, OnInit, Input, ElementRef, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ResourcedialogComponent } from '../../../forms/hierarchyform/resourcedialog/resourcedialog.component';
import { ResourcedialogeditComponent } from '../../../forms/hierarchyform/resourcedialogedit/resourcedialogedit.component';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { DeldialogComponent } from '../../hierarchyform/resource-details/deldialog/deldialog.component';
import { Subject } from 'rxjs/Subject';
import { EventEmitter } from '@angular/core';
@Component({
  selector: 'app-resource-details',
  templateUrl: './resource-details.component.html',
  styleUrls: ['./resource-details.component.scss']
})
export class ResourceDetailsComponent implements OnInit {
  @Input() resourceArr: any;
  @Input() resourceShowFields: any;
  @Input() requirementDetails: any;
  @Output() outputData = new EventEmitter()
  @Output() deleteResourceId = new EventEmitter(); 
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  dialogRefDetails: MatDialogRef<ResourcedialogComponent>;
  dialogRefDetailsEdit: MatDialogRef<ResourcedialogeditComponent>;
  deldialog: MatDialogRef<DeldialogComponent>;
  reqPreview: any = [];
  finalData: any = [];
  reqPreview_value: any = [];
  depDataId: any;
  hostLocation: any;
  visaTypeFieldValue: any;
  constructor(private _formBuilder: FormBuilder,
    private dialog: MatDialog,
    private el: ElementRef,
    private service: GlobalformService) {

  }

  ngOnInit() {
  }
  ngOnChanges() {
    this.finalData = this.resourceArr;
    // console.log(this.resourceArr)
    // Object.keys(this.requirementDetails).map(reqResp => {
    //   if(reqResp == 'country'){
    //     this.hostLocation =this.requirementDetails[reqResp].value;
    //   }
    // });
  }

  addDependent(loopdata) {
    var resDataId;
    for (let data of loopdata) {
      if (data.fieldKey === "resDataId") {
        resDataId = data.values;
      }
    }
    this.dialogRefDetails = this.dialog.open(ResourcedialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefDetails.componentInstance.caseid = 'Dependent'; // To get data form json-builder
    this.dialogRefDetails.componentInstance.resourceId = resDataId; // pass ResourceId to resourceDialog Component
    this.dialogRefDetails.componentInstance.requirementDetails = this.requirementDetails; // pass ResourceId to resourceDialog Component
    //////////// To Populate Dependent List After Adding Dependent ////////////////////
    this.dialogRefDetails.afterClosed().subscribe(resp => {
      if (resp) {
        this.outputData.next(resp);
      }
    });
  }

  ///////// Expansion Panel Configuration ////////////////
  expansionPanel(event) {
    let el = event.target;
    let elcl = event.target.closest('.boxedCard');
    let elClassList = ((elcl).querySelector('.slider')).classList;
    let panel = ((elcl).querySelector('.slider'));
    if (panel.style.maxHeight) {
      el.style = "transform: rotate(0deg); transition: all 0.5s ease-out;"
      panel.style = "max-height:null;"
    } else {
      el.style = "transform: rotate(180deg); transition: all 0.5s ease-out;"
      panel.style = "max-height:" + panel.scrollHeight + "px";
    }
  }


  goEditRes(loopdata,length) {
    console.log(this.requirementDetails[0].rowId)
    let rowId = loopdata.find(items => items.fieldKey == 'rowId');

    this.dialogRefDetailsEdit = this.dialog.open(ResourcedialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefDetailsEdit.componentInstance.caseid = 'Resource'; // To get data from json-builder
    this.dialogRefDetailsEdit.componentInstance.rowId = rowId.values; // Pass ResourceId to resourceEdit Component
    this.dialogRefDetailsEdit.componentInstance.requirementDetails = this.requirementDetails;
    this.dialogRefDetailsEdit.componentInstance.loopdata = loopdata
    this.dialogRefDetailsEdit.componentInstance.totalResource = length;
    /////////////////// To Populate Resource Details After Edit Resource ////////////////
    this.dialogRefDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        this.outputData.next(resp);
      }
    });
  }

  goEditDept(dependent, loopdata) {
    this.service.depDataIdEdit = dependent;
    let resDataId;
    let depDataId;
    for (let data of loopdata) {
      if (data.fieldKey === "resDataId") {
        resDataId = data.values;
      }
    }
    for (let data of dependent) {
      if (data.fieldKey === "depDataId") {
        depDataId = data.values;
      }
    }
    this.dialogRefDetailsEdit = this.dialog.open(ResourcedialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });

    this.dialogRefDetailsEdit.componentInstance.caseid = 'Dependent'; // To get data from json-builder
    this.dialogRefDetailsEdit.componentInstance.resourceId = resDataId; // Pass resourceId to resourceEditDialog Component
    this.dialogRefDetailsEdit.componentInstance.dependentId = depDataId; // Pass dependentId ''        ''            ''
    this.dialogRefDetailsEdit.componentInstance.updatedId = depDataId; // Over-Ride resourceId and dependentId
    //////////// To Populate Dependent List After Edit Dependent ////////////////////
    this.dialogRefDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {

        this.outputData.next(resp);

      }
    });
  }
  isNumber(val) { return typeof val === 'number'; } // To Remove empty chips
  delete(deldata, count,length) {
    let rowId;
    let depDataId;
    console.log(this.requirementDetails);
    this.deldialog = this.dialog.open(DeldialogComponent
      , {
        // height: '100px',
        // width: '100px'
      });
    for (let data of deldata) {
      if (data.fieldKey === "rowId") {
        rowId = data.values;

      }
    }
    this.deldialog.componentInstance.count = count;
    this.deldialog.componentInstance.rowId = rowId;
    this.deldialog.componentInstance.caseId = 'Resource'
    this.deldialog.componentInstance.totalResource = length;
    this.deldialog.componentInstance.proDetRowId = this.requirementDetails[0].rowId;
    
    //////////// To Populate Resource and Dependent List After Delete  ////////////////////
    this.deldialog.afterClosed().subscribe(resp => {
      if (resp) {
        this.deleteResourceId.next(resp);
      }
    })
  }
  selected(status) {
    if (status == "0" && status != undefined) {
      return true;
    }
    else {
      return false;
    }
  }
}
