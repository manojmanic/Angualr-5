import { Component, OnInit, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { ResourcedialogComponent } from '../../../forms/hierarchyform/resourcedialog/resourcedialog.component';
import { ResourcedialogeditComponent } from '../../../forms/hierarchyform/resourcedialogedit/resourcedialogedit.component';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuildBaseService } from '../../formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { Constants } from '../../../constants';
@Component({
  selector: 'app-submit-requirements',
  templateUrl: './submit-requirements.component.html',
  styleUrls: ['./submit-requirements.component.scss']
})
export class SubmitRequirementsComponent implements OnInit {

  isLinear = false;
  apiResp: any;
  reqResp: any;
  hostLocation:any;
  visaTypeFieldValue:any;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  dialogRefDetails: MatDialogRef<ResourcedialogComponent>;
  dialogRefDetailsEdit: MatDialogRef<ResourcedialogeditComponent>;
  reqPreview: any = [];
  //projectDet: any = [];
  projectDet_Value: any = [];
  finalData: any = [];
  reqPreview_value: any = [];
  depDataId: any;
  params;
  form_title;
  innerTemplate;
  formBuildBaseObj;
  breadcrumbs;
  subTitle;
  noOfResource: any;
  disabledButton: any;
  disableSubmitButton: any;
  reqDataId: any;
  projectDetails: any = [];
  projectDetailsShowFields: any;
  resourceArr: any = [];
  resourceShowFields: any;
  noOfResources: any;
  resValidationMsg:any;
  constructor(
    private _formBuilder: FormBuilder,
    private router: Router,
    private dialog: MatDialog,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private route: ActivatedRoute,
    private authGuardService: AuthGuardService,
    private gfService:GlobalFunctionService,
    private config: Constants,
    private el: ElementRef,
    private service: GlobalformService) {
    let apiData;
    this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formView('submit-requirement');
    // console.log(this.formBuildBaseObj)
    let formBuildBaseObjRequirement = this.screenTB.formView('requirementDetails');
    this.projectDetailsShowFields = Array.from(Object.keys(formBuildBaseObjRequirement.showFields));
    this.form_title = this.formBuildBaseObj.title;
    apiData = { "formId": formBuildBaseObjRequirement.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: formBuildBaseObjRequirement.formId } };
    this.service.getFormData(apiData).subscribe(resp => {
      console.log(resp)
      this.reqResp = (JSON.parse(JSON.stringify(resp)).data);
      if (resp.status == 'success') {

        let preBuildEvFn = formBuildBaseObjRequirement.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjRequirement.formId, resp: resp.data };
            let changed = eventCalls[preBuildEvFn](param);
            this.innerTemplate = changed.innerTemplate;
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
            this.hostLocation = changed.hostLocationValue;
            console.log(changed);
            this.noOfResource = changed.noOfResources;
            // console.log(this.newBuildFun(changed.resp,'')[0])
            this.projectDetails = this.newBuildFun(changed.resp, '')[0];
            console.log(this.projectDetails);
            // let noOfResource = this.projectDetails.find(items => items.fieldKey == 'noOfResource');
            // this.noOfResource = noOfResource.values.value;
            // console.log(this.projectDetails)
          }
        }
      }
    
    })
    let formBuildBaseObjResource = this.screenTB.formView('Resource');
    this.resourceShowFields = Array.from(Object.keys(formBuildBaseObjResource.showFields));
    apiData = { "formId": formBuildBaseObjResource.formId, transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, "filterString": { transactionId: JSON.parse(localStorage.getItem("currentUser")).transactionId, formId: formBuildBaseObjResource.formId } };
    this.service.getFormData(apiData).subscribe(resp => {
      console.log(resp)
      if (resp.status == 'error') {
        let preBuildEvFn = formBuildBaseObjResource.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjResource.formId };
            let changed = eventCalls[preBuildEvFn](param);
            this.innerTemplate = changed.innerTemplate;
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
            this.visaTypeFieldValue = changed.visaTypeValue;
            this.resValidationMsg = changed.resValidationMsg;
            console.log(changed);
            // console.log(this.newBuildFun(changed.resp,'')[0])
            // console.log(this.projectDetails)
          }
        }

      }
      if (resp.status == 'success') {

        let preBuildEvFn = formBuildBaseObjResource.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjResource.formId, resp: resp.data,additionalDetails:this.reqResp };
            let changed = eventCalls[preBuildEvFn](param);
            this.innerTemplate = changed.innerTemplate;
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
            this.visaTypeFieldValue = changed.visaTypeValue;
            this.resValidationMsg = changed.resValidationMsg;
            console.log(changed.resp);
           setTimeout(()=> this.resourceArr =  this.newBuildFun(changed.resp, ''),this.config.FORM_LOADING_SEC);
            // console.log(this.newBuildFun(changed.resp, ''))
            // console.log(this.newBuildFun(changed.resp,'')[0])
            // console.log(this.projectDetails)
          }
        }
      }
    })


  }
  resourceArrRebuild(data) {
    console.log(data);
    let formBuildBaseObjResource = this.screenTB.formView('Resource');
    let preBuildEvFn = formBuildBaseObjResource.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: formBuildBaseObjResource.formId, resp: data };
        let changed = eventCalls[preBuildEvFn](param);
        this.innerTemplate = changed.innerTemplate;
        this.breadcrumbs = changed.breadcrumbs;
        this.subTitle = changed.subTitle;
        console.log(changed)
        // this.resourceArr = (this.newBuildFun(changed.resp, { 'oldData': this.resourceArr, 'operation': 'edit' }));
        setTimeout(()=> this.resourceArr =  this.newBuildFun(changed.resp, { 'oldData': this.resourceArr, 'operation': 'edit' }),this.config.FORM_LOADING_SEC);
        // console.log(this.newBuildFun(changed.resp,'')[0])
        // console.log(this.projectDetails)
      }
    }
  }
  deleteDepFun(rowId) {
    this.resourceArr.map((resp, index) => {
      resp.map(innerResp => {
        if (innerResp.fieldKey == 'rowId') {
          if (innerResp.values == rowId) {
            this.resourceArr.splice(index, 1);
          }
        }
      })
    })
    let noOfResource = this.projectDetails.find(items => items.fieldKey == 'noOfResource');
    // this.noOfResource = noOfResource.values.value;
    if(this.resourceArr.length)
    noOfResource.values.value = this.resourceArr.length;
  }

  newBuildFun(data, arrAlterData) {
    let finalData: any = [];
    console.log(this.hostLocation, this.visaTypeFieldValue,data);
    data.map(resp => {
      let innerArr = [];
      let addonsServiceList = [];
      let reqPreview_value = [];
      Object.keys(resp).map(key => {
        //  if(key == 'country') {
        //    this.hostLocation = resp[key].value
        //  }
        //  if(key == 'visaType') {
        //   this.visaTypeFieldValue = resp[key].value  
        //  }
        ////////////////////////////////addOns//////////////////////////
        console.log(this.hostLocation != undefined, this.visaTypeFieldValue != undefined,key == 'addons');
        if (this.hostLocation != undefined && this.visaTypeFieldValue != undefined && key === "addons") {
          console.log(this.visaTypeFieldValue,this.hostLocation);
          let addonsList = resp[key];
            let addonsApiData = { "hostLocation": this.hostLocation, "visaType": this.visaTypeFieldValue };
            this.service.getAddons(addonsApiData).subscribe(resp => {
              console.log(resp)
              if (resp.data.length) {
                resp.data.map(respData => {
                  addonsList.map(addonsListMap => {
                    if (respData.fieldColumn == addonsListMap.addonId) {
                      addonsServiceList.push(respData);
                    }
                  });

                });
                // console.log(addonsServiceList,resp)
                addonsServiceList.map((respList, index) => {
                  let addonsJSONList;
                  respList.values.map(respListLDataValue => {
                    Object.keys(addonsList).map(respData => {
                      if (respListLDataValue.addonDataId == addonsList[respData].addonDataId && respListLDataValue.addonId == addonsList[respData].addonId) {
                        addonsJSONList = respListLDataValue;
                      }
                    })
                    addonsServiceList[index].values = [];
                    addonsServiceList[index].values.push(addonsJSONList);
                  })
                })
              }

            });

          
          console.log(addonsServiceList);
          innerArr.push({
            fieldKey: "addonServices",
            values: addonsServiceList,
          })

        }
        let obj = {
          fieldKey: key,
          values: resp[key]
        }
        innerArr.push(obj);
      })
      finalData.push(innerArr);
    })
    let innerFinalData;
    console.log(JSON.parse(JSON.stringify(data)),finalData)
    if (arrAlterData != '') {
      if (arrAlterData.operation == 'edit') {
        console.log(arrAlterData.oldData,finalData);
        innerFinalData = arrAlterData.oldData;
        finalData.map((finalData) => {
          finalData.map(finalDataResp => {

            innerFinalData.map((alterResp, index) => {
              alterResp.map((innerResp) => {
                if (finalDataResp.fieldKey == 'rowId' && innerResp.fieldKey == 'rowId') {
                  if (finalDataResp.values == innerResp.values) {
                    let filterAlterResp = finalData.filter(items => {
                      if (typeof items.values == 'object' && items.values != null) {
                        return items;
                      }
                    })
                    filterAlterResp.map(resp => {

                      alterResp.map(innerResp => {
                        if (typeof innerResp.values == 'object' && innerResp.values != null) {
                          if (resp.fieldKey == innerResp.fieldKey) {
                            innerResp.values = resp.values;
                          }
                        }
                      })
                    })
                    innerFinalData[index] = alterResp;
                  }
                }
              })
            })
          })
        })
        finalData = innerFinalData;
      } else
        if (arrAlterData.operation == 'add') {
          // finalData = arrAlterData.oldData.push(finalData[0]);
          // arrAlterData.oldData.push(finalData);
          // if(arrAlterData.oldData.length > 0)
          arrAlterData.oldData.push(finalData[0]);
          finalData = arrAlterData.oldData;
        }
    } else {
      finalData = finalData;
    }
    console.log(finalData)
    if (this.projectDetails.length) {
      let noOfResource = this.projectDetails.find(items => items.fieldKey == 'noOfResource');
      noOfResource.values.value = finalData.length;
    }
     return finalData;
  }
  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }
  projectDetailsBuild(data) {
    console.log(JSON.parse(JSON.stringify(data)))
    this.reqResp = JSON.parse(JSON.stringify(data));
    let formBuildBaseObjRequirement = this.screenTB.formView('requirementDetails');
    let preBuildEvFn = formBuildBaseObjRequirement.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: formBuildBaseObjRequirement.formId, resp: data };
        let changed = eventCalls[preBuildEvFn](param);
        this.innerTemplate = changed.innerTemplate;
        this.breadcrumbs = changed.breadcrumbs;
        this.subTitle = changed.subTitle;
        this.hostLocation = changed.hostLocationValue;
        this.noOfResource = changed.noOfResources;
        // console.log(this.hostLocation,this.reqResp);
        // Object.keys(this.reqResp[0]).map(key =>{
        //   if(key == 'country') {
        //     this.reqResp[0][key].value = this.hostLocation;
        //   }
        // })
        console.log(this.reqResp)
        // console.log(this.newBuildFun(changed.resp,'')[0])
        this.projectDetails = this.newBuildFun(changed.resp, '')[0];
        // let noOfResource = this.projectDetails.find(items => items.fieldKey == 'noOfResource');
        // this.noOfResource = noOfResource.values.value;
        // console.log(this.projectDetails)
      }
    }
  }

  isNumber(val) { return typeof val === 'number'; } // To Remove empty chips
  reqFinalSub() {
    this.service.submitTransaction().subscribe(data => {
      console.log(data);
      if (data.status == "success") {
        // this.router.navigate(['successScreen']);
        let redirectTo = 'successScreen';
        let redirectData = 'requirement';
        // let redirectTo = 'payment';
        let tranId: any = {};
        tranId = JSON.parse(localStorage.getItem('currentUser'))
        // console.log(tranId.transactionId);
        delete tranId.transactionId;
        // console.log(tranId);
        localStorage.setItem('currentUser', JSON.stringify(tranId));
        localStorage.setItem("reqId", data.data.reqId);
        this.router.navigate([redirectTo], { queryParams: { data: redirectData, reqRefNo: data.data.reqNo } });
      }
    });
    //this.authGuardService.getLoginUser().hasOwnProperty('transactionId').removeItem;
  }



  addResource() {
    console.log(this.projectDetails);
    let reqId = this.projectDetails.find(items => items.fieldKey == 'rowId');
    let noOfResource = this.projectDetails.find(items => items.fieldKey == 'noOfResource');
    this.dialogRefDetails = this.dialog.open(ResourcedialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefDetails.componentInstance.caseid = 'Resource'; // To get data from json-builder
    // console.log(this.finalData)
    /////////////////// To Populate Resource Details After Adding Resource ////////////////
    this.dialogRefDetails.componentInstance.requirementDetails = this.reqResp;
    this.dialogRefDetails.componentInstance.reqId = reqId.values;
    this.dialogRefDetails.componentInstance.noOfResource = noOfResource.values.value;
    this.dialogRefDetails.afterClosed().subscribe(resp => {
      if (resp) {
        console.log(resp, this.resourceArr);
        let formBuildBaseObjResource = this.screenTB.formView('Resource');
        let preBuildEvFn = formBuildBaseObjResource.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjResource.formId, resp: resp };
            let changed = eventCalls[preBuildEvFn](param);
            this.innerTemplate = changed.innerTemplate;
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
            this.visaTypeFieldValue = changed.visaTypeValue;
            console.log(changed.resp);
            setTimeout(()=> this.resourceArr =  this.newBuildFun(changed.resp, { 'oldData': this.resourceArr, 'operation': 'add' }),this.config.FORM_LOADING_SEC);
            // this.resourceArr = this.newBuildFun(changed.resp, { 'oldData': this.resourceArr, 'operation': 'add' });
            console.log(this.resourceArr)
            // console.log(this.newBuildFun(changed.resp,'')[0])
            // console.log(this.projectDetails)
          }
        }
        // console.log((this.newBuildFun(changed.resp,{'oldData':this.dependentDetails,'operation':'add'})))
        // this.finalData = this.requirementBuild(resp);
        // if (this.finalData.length == this.noOfResource) {
        //   this.disabledButton = true;
        // }
        // else {
        //   this.disabledButton = false;
        // }
      }
    });
  }
}
