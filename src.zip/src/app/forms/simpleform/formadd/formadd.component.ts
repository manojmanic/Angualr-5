import { Component, OnInit,ElementRef,Renderer2} from '@angular/core';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../shared/models/question-base';
import { FormGroup,FormControlName,FormControlDirective,FormControl} from '@angular/forms';
import { DropdownQuestion } from '../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import {AlertService} from '../../../shared/services/alert-service.service';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { DatePipe } from '@angular/common';
import { AbstractControl } from '@angular/forms';
import { Constants } from '../../../constants';
@Component({
  selector: 'app-formadd',
  templateUrl: './formadd.component.html',
  styleUrls: ['./formadd.component.css']
})

export class FormaddComponent implements OnInit {

  ngOnInit() {
    // this.renderer.setStyle(this.el.nativeElement, 'color', 'green');
  }

  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  subTitle: string;
  breadcrumbs: any;
  formBuildBaseObj: any;
  params: any;
  menuItems: any;
  buildData: any;
  buttonData:any;
  cancelButton:any;
  innerTemplate:any;
  _touched:boolean;
  constructor(
    private config: Constants,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    public gfService: GlobalFunctionService,
    private route: ActivatedRoute,
    private el: ElementRef,
    private renderer: Renderer2,
    private alert:AlertService) {

    this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formAdd(this.params.id);
    
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()

    service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
       
      this.buildData = data.data;
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
          let changed = eventCalls[preBuildEvFn](param);
          this.buttonData = changed.buttonData;
          this.buildData = changed.formItems;
          this.cancelButton = changed.cancelButton;
          this.innerTemplate = changed.innerTemplate;
          this.breadcrumbs = changed.breadcrumbs;
          this.subTitle = changed.subTitle;
        }
      }
      // const subEve = (fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
      setTimeout(() => {
        let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
        this.questions = buildData['fields'];
        this.form = buildData['controls'];
        console.log(buildData, this.buildData, this.formBuildBaseObj.showFields);
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
      }, this.config.FORM_LOADING_SEC);

    })
  }

   markAsTouched() {
    this._touched = true;
  }

  onSubmit() {
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    let redirectTo, redirectData, apiCall,selectedItems;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems,rawData:this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        redirectTo = changed.redirectTo;
        apiCall = changed.apiCall
        redirectData = changed.redirectData;
        selectedItems = changed.selectedItems;
      }
    }


    if (!apiCall) {
     if (this.form.valid) {
      Object.keys(this.form.controls).map(fieldArrData => {
        let fieldKey = fieldArrData;
        let fieldData = this.form.controls[fieldKey]
        for (var question of this.questions) {
          //////////////////////////Date Type/////////////////////////////////////
          if (question.fieldType === 'date') {
            var currentDate = new DatePipe('en-us');
            let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
            if (final != null)
            this.form.value[ question.fieldColumn ] = final;
          }
          /////////////////////////////International PhoneNumber/////////////////
          if(question.fieldType === 'internationalPhoneNumber'){
            let finalIntelNumber = {value:this.form.controls[question.fieldColumn].value,iso2:this.service.internationalPhoneData[question.fieldColumn]}
            // console.log(finalIntelNumber);
            this.form.value[question.fieldColumn] = JSON.stringify(finalIntelNumber);
          }
        }
      });
      

      let apiValues = this.form.value;
      Object.keys(apiValues).map(resp => {
        if (apiValues[resp] == "" || apiValues[resp] == null) {
          delete apiValues[resp];
        }
      });
       this.service.putForms(apiValues, this.formBuildBaseObj.formId).subscribe(resp => {
          
          if(this.route.snapshot.url[0].path === 'country-selection') {
             localStorage.setItem("post_reqId",resp.data);
          }
         if (resp.status == 'success') {
            if(redirectTo != null && redirectTo != undefined && redirectTo != '') {
              let enquiryData;
              if(redirectData === 'enquiry') {
                enquiryData = resp.data;
             }
              this.router.navigate([redirectTo], { queryParams: {data: redirectData,enquiryId:enquiryData}});
            }
          }

          this.alertMsg(resp);
         });
      } else {
        this.alert.error("Please fill required fields.");
        this.questions.map(resp=>{
          if(this.form.controls[resp.fieldColumn].touched==false && this.form.controls[resp.fieldColumn].status=="INVALID"){

            this.form.controls[resp.fieldColumn].markAsTouched();

          }
        })

      }
    }else  if(selectedItems) {
      this.alert.error("This field is already listed in country list...");
    }

  }

  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(JSON.stringify(message));
    }
  }

}
