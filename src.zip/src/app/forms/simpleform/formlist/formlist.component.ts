import { Component, OnInit } from '@angular/core';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { MatDialog, MatDialogRef, MatSnackBar } from '@angular/material';
import { DialogComponent } from './dialog/dialog.component';
import { FormaddComponent } from '../../../forms/simpleform/formadd/formadd.component';
import { Router } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { ActivatedRoute } from "@angular/router";
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';
import { FormBuildBaseService } from '../../formbuilds/form-build-base.service';
import { Constants } from '../../../constants';


@Component({
  selector: 'app-formlist',
  templateUrl: './formlist.component.html',
  styleUrls: ['./formlist.component.css']
})
export class FormlistComponent implements OnInit {
  //data = { "formId": "1", "filterString": {}, "languageCode": "en" }
  visaList: any = [];
  visaListParent: any = [];
  visaListId: any = [];
  dialogRefDetails: MatDialogRef<DialogComponent>;
  dialogRefAdd: MatDialogRef<FormaddComponent>;
  form_title: any;
  breadcrumbs: any;
  subTitle: string;
  formBuildBaseObj: any;
  params: any;
  recordArr: any;

  constructor(private service: GlobalformService,
    public dialog: MatDialog,
    private router: Router,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private authguardService: AuthGuardService,
    public gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private route: ActivatedRoute,
    private http: Http,
    private snackBar: MatSnackBar,
    private config: Constants
  ) {
    this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formList(this.params.id);
    this.form_title = this.formBuildBaseObj.title;
    this.recordArr = this.formBuildBaseObj.forms;
    // console.log(this.recordArr);
    this.recordArr.map((recordData, index) => {
      let apiData = { "formId": recordData.formId, "filterString": {}, "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT };
      service.getFormData(apiData).subscribe(respData => {
        console.log(JSON.parse(JSON.stringify(respData)));

        let preBuildEvFn = recordData.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: recordData.formId };
            let changed = eventCalls[preBuildEvFn](param);
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
          }
        }
        recordData['records'] = this.formListBulid(respData, recordData, index);
        //console.log(resp)
        ///////// To Get List of visa /////////////

      })
      // this.visaListParent.push(visa);
      // console.log(this.visaListParent)
    })
  }
  innervisaListParent = [];
  formListBulid(actualRecord, recordData, index) {
    let visa: any = [];
    let returnData: any = {};

    // this.visaListParent = [];
    for (let i = 0; i < actualRecord.data.length; i++) {
      if (actualRecord.data[i].status === "0") {
        actualRecord.data[i].disableButton = true;
        actualRecord.data[i].statusData = "Activate";
      }
      if (actualRecord.data[i].status === "1") {
        actualRecord.data[i].disableButton = false;
        actualRecord.data[i].statusData = "DeActivate";
      }
      
      // if(this.params.id == "VisaPartnerMaster"){
          
      //   actualRecord.data[i].partnerRate = true;
      // }
      actualRecord.data[i].showFields = recordData.showFields;
      actualRecord.data[i].operations = recordData.operations;
      actualRecord.data[i].title = recordData.title;
      actualRecord.data[i].screenId = recordData.screenId;
      actualRecord.data[i].formId = recordData.formId;
      visa.push(actualRecord.data[i]);
    }

    ///////////////////termsReference list Single & Multi ///////////////////////////////
    let postBuildEvFn = recordData.eventHandler.postBuild;
    if (postBuildEvFn != '') {
      const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[postBuildEvFn]) {
        let param = { formId: recordData.formId, rawData: visa };
        let changed = eventCalls[postBuildEvFn](param);
        // console.log(changed.rawData)
        this.innervisaListParent.push(changed.rawData);
        returnData = {
          recordCount: actualRecord.totalCount,
          formId: recordData.formId,
          recordList: changed.rawData
        }
      }
    }

    console.log(this.recordArr);
    return returnData;
  }


  details(record) {
    // console.log(record);
    ////// To Get VisaList with Id //////////////
    this.service.visaListId = this.visaListId;
    //console.log(visa)
    this.service.screenId = record.screenId;
    this.service.id = record.dataId;
    this.dialogRefDetails = this.dialog.open(DialogComponent);
    this.dialogRefDetails.componentInstance.visaName = 'test';
    this.dialogRefDetails.componentInstance.detailsDataId = record.dataId;
    this.dialogRefDetails.componentInstance.screenId = record.screenId;
  }



  edit(record) {
    // console.log(record)
    this.router.navigate(['/FormEdit', record.screenId, record.dataId]);
  }

  delete(record) {
    let statusdata;
    let updateStatus;
    let perCode = this.gfService.DeactivatePermissioncode()
    //console.log(perCode);
    if (perCode) {
      this.dialogRefDetails = this.dialog.open(DialogComponent);

      // for (let i = 0; i < this.visaListParent[formPlaceId].length; i++) {
      // if (this.visaListParent[formPlaceId][i].dataId === id) {
      statusdata = record.status;
      if (statusdata == "0") {
        record['statusData'] = "DeActivate";
        this.dialogRefDetails.componentInstance.activate = true;
        updateStatus = "1";
      }
      if (statusdata == "1") {
        record['statusData'] = "Activate";
        this.dialogRefDetails.componentInstance.deActivate = true;
        updateStatus = "0"
      }
      statusdata = updateStatus;
      this.dialogRefDetails.componentInstance.id = record.dataId;
      this.dialogRefDetails.componentInstance.formId = this.formBuildBaseObj.forms[0].formId;
      this.dialogRefDetails.componentInstance.dataId = statusdata;
      this.dialogRefDetails.afterClosed().subscribe(resp => {
        if (resp) {
          // console.log(resp);
          if (statusdata == "1") {
            record.disableButton = false;
          }
          if (statusdata == "0") {
            record.disableButton = true;
          }
          record.status = statusdata;
        }
      });
      // }
      // }
      // console.log(this.visaListParent);
    }
    else {
      this.openSnackBar("Deactivation is not accessable for your role.", "");
    }
  }

  addNew(screenId, data) {
    this.router.navigate(['/formAdd/' + screenId]);
  }

  // partnerRateAdd(data){
  //   // console.log(data);
  //   // this.router.navigate(['/formAdd/PartnerVisaRateMaster']);
  //   this.dialogRefvisaPartner = this.dialog.open(PartnerratedialogComponent
  //     , {
  //       height: '80%',
  //       width: '80%'
  //     });
  //     this.dialogRefvisaPartner.componentInstance.caseid = 'PartnerVisaRateMaster'; // To get data from json-builder
  //     this.dialogRefvisaPartner.afterClosed().subscribe(resp=>{
        
        
  //     })
  // }

  ngOnInit() {
    // this.route.params.subscribe(params => {
    // const term = params['term'];
    // });
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
      extraClasses: ['error']
    });
  }
  searchData: any = '';
  paginationFunction(pageEvent) {
    this.formBuildBaseObj = this.screenTB.formList(this.params.id);
    let apiData; 
    console.log(this.searchData) 
    this.recordArr.map((recordData, index) => {
      if(recordData.formId == pageEvent.formId) {
      if (this.searchData != '') {
        let queryBuild = '';
        recordData.showFields.map((showField, index) => {
          if (index == (recordData.showFields.length - 1)) {
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData  + '%"');
          }
          else
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData + '%"') + ' OR ';
        })
        apiData = {
          "formId": recordData.formId,
          "filterString": { "searchString": queryBuild },
          "pageNumber": pageEvent.pageData.pageIndex + 1, "limit": pageEvent.pageData.pageSize
        }
      } else {
        apiData = { "formId": recordData.formId, "filterString": {}, "pageNumber": pageEvent.pageData.pageIndex + 1, "limit": pageEvent.pageData.pageSize };
      }
      // console.log(apiData);
      this.service.getFormData(apiData).subscribe(resp => {
        console.log(JSON.parse(JSON.stringify(resp)),apiData);
        if (resp.status == 'success') {
          // this.visaListParent = [];
          let recordArr = this.formListBulid(resp, recordData, index);
          console.log(recordArr,this.recordArr);
          this.recordArr.map(resp =>{
            if(resp.formId == recordArr.formId) {
              console.log(resp.records,recordArr)
              resp.records = recordArr
              // resp.records =  recordArr;
            }
          })
          // console.log(this.recordArr);
          // console.log(pageEvent._pageIndex);

        }
      })
    }
    })
  }

  searchFunction(data) {
    this.searchData = data.searchData;
    this.formBuildBaseObj = this.screenTB.formList(this.params.id);
    let apiData;
    console.log(data);
    this.recordArr.map((recordData, index) => {
      if(recordData.formId == data.formId) {
        console.log(recordData)
      let queryBuild = '';
      if (data.searchData != '' && data.searchData != undefined) {
        recordData.showFields.map((showField, index) => {
          if (index == (recordData.showFields.length - 1)) {
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data.searchData + '%"');
          }
          else
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data.searchData + '%"') + ' OR ';
        })
        apiData = {
          "formId": recordData.formId,
          "filterString": { "searchString": queryBuild },
          "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
        }
      } else {
        apiData = { "formId": recordData.formId, "filterString": {}, "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT };
      }
      this.service.getFormData(apiData).subscribe(resp => {
       
        if (resp.status == 'success') {
          let recordArr = this.formListBulid(resp, recordData, index);
          console.log(recordArr,this.recordArr);
          this.recordArr.map(resp =>{
            if(resp.formId == recordArr.formId) {
              console.log(resp.records,recordArr)
              resp.records = recordArr
              // resp.records =  recordArr;
            }
          })
          console.log(this.recordArr)
          // this.searchData = data;
        } else {
          this.recordArr.records = [];
          this.recordArr.map(resp =>{
            if(resp.formId == data.formId) {
              console.log(resp.records,data)
              resp.records.recordList = [];
              resp.records.recordCount = 0;
              // resp.records =  recordArr;
            }
          })
          console.log(this.recordArr)
          // this.visaListParent[0] = [];
          // this.visaListParent.map(resp =>{
          // console.log(resp);
          // resp = [];
          // })
        }
      })
    }
    })
  }

}