import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { GlobalformService } from '../../../../shared/services/globalform.service';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<DialogComponent>,
    private router: Router,
    private service: GlobalformService,
    private snackBar: MatSnackBar,
  ) { }

  ngOnInit() {
    
  }
  visaName: string;
  activate: any;
  deActivate: any;
  id: any;
  formId: any;
  dataId: any;
  detailsDataId:any;
  screenId:any
  details() {
    this.dialogRef.close();
    this.router.navigate(['/FormDetails',this.screenId,this.detailsDataId]);

  }
  activateDeActivate() {
    this.service.deleteForm(this.id, this.formId, '', this.dataId).subscribe(data => {
      
      if (data.status == "success" || data.status == "Success") {
        this.dialogRef.close(data);
      }
      this.openSnackBar({ status: data.status, message: JSON.stringify(data.message) });
    });
  }

  openSnackBar(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'Success' || resp.status == 'success') {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['success']
      });
    }
    else {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['error']
      });
    }
  }
}
