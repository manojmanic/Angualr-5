import { Component, OnInit } from '@angular/core';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { AlertService } from '../../../shared/services/alert-service.service';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { ActivatedRoute } from '@angular/router';
import { Constants } from '../../../constants';

@Component({
  selector: 'app-formedit',
  templateUrl: './formedit.component.html',
  styleUrls: ['./formedit.component.css']
})
export class FormeditComponent implements OnInit {

  ngOnInit() {
  }

  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  formBuildBaseObj: any;
  breadcrumbs: any;
  formObject: any;
  subTitle: string;
  menuItems: any;
  buildData: any;
  formDataPair: any;
  buttonData: any;
  cancelButton: any;
  params: any
  constructor(
    private config: Constants,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    public gfService: GlobalFunctionService,
    private route: ActivatedRoute,
    private alert: AlertService,
  ) {
    this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formEdit(this.params.id);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()

    service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      this.buildData = data.data;
      var dataSingleId = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.params.dataId }, "languageCode": "en" }
      this.service.getFormData(dataSingleId).subscribe(resp => {
        if (resp.status == 'success') {
          let formGroups = this.buildData.fieldGroup;
          formGroups.filter(formGroupsData => {
            let formFields = formGroupsData.FieldList;
            formFields.filter(arrData => {
              Object.keys(resp.data[0]).map(key => {
                if(typeof resp.data[0][key] =='object' && resp.data[0][key] != null){
                if (resp.data[0][key].fieldType === "customListMultiSelect" || resp.data[0][key].fieldType == "termsReferenceListMulti") {
                  if (resp.data[0][key].value != null)
                    resp.data[0][key].value = resp.data[0][key].value.toString().split(",")
                }
                if (resp.data[0][key].fieldType === 'fileImage') {
                  this.service.files = resp.data[0][key].value;
                }
                if (arrData.fieldId == resp.data[0][key].fieldId) {
                  arrData.value = resp.data[0][key].value;
                }
              }
              })
            })
          })

          let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
              let changed = eventCalls[preBuildEvFn](param);
              this.buildData = changed.formItems;
              this.buttonData = changed.buttonData;
              this.cancelButton = changed.cancelButton;
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
            }
          }
          setTimeout(() => {
            let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
            this.questions = buildData['fields'];
            this.form = buildData['controls'];
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
                let changed = eventCalls[postBuildEvFn](param);
                this.questions = changed.rawData;
              }
            }
          }, this.config.FORM_LOADING_SEC);
        }
      });
    });
  }

  onSubmit() {
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    let redirectTo, redirectData, status;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, questions: this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        redirectTo = changed.redirectTo;
        redirectData = changed.redirectData;
        status = changed.status;
      }
    }

    if (this.form.valid) {

      let apiValues = this.form.value;
      Object.keys(apiValues).map(resp => {
        if (apiValues[resp] == "" || apiValues[resp] == null) {
          // apiValues[resp] = null;
          delete apiValues[resp];
        }
      });
      if (status != "DeActivated") {
        this.service.updateFormData(apiValues, this.formBuildBaseObj.formId, this.params.dataId).subscribe(resp => {
          // console.log(resp)
          if (resp.status == 'success') {
            if (redirectTo != null && redirectTo != undefined && redirectTo != '')
              this.router.navigate([redirectTo], { queryParams: { data: redirectData } });
          }

          this.alertMsg(resp);
        })
      }
      else {
        this.alert.error("Please Select Active Field Value");
      }
    }
    else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
    }
  }

  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

}
