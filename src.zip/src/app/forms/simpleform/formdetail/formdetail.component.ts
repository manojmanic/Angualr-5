import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../shared/services/globalform-control.service';
import { QuestionBase } from '../../../shared/models/question-base';
import { FormGroup, FormControl } from '@angular/forms';
import { MatDialog, MatDialogRef } from '@angular/material';
import { FormeditComponent } from '../../simpleform/formedit/formedit.component';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { ActivatedRoute } from '@angular/router';
import { FormBuildBaseService } from '../../formbuilds/form-build-base.service';
import { PartnerratedialogComponent } from './partnerratedialog/partnerratedialog.component';
import {PartnerratedialogeditComponent} from './partnerratedialogedit/partnerratedialogedit.component';

@Component({
  selector: 'app-formdetail',
  templateUrl: './formdetail.component.html',
  styleUrls: ['./formdetail.component.scss']
})
export class FormdetailComponent implements OnInit {

  dialogRef: MatDialogRef<FormeditComponent>;
  dialogRefvisaPartner:MatDialogRef<PartnerratedialogComponent>;
  dialogRefvisaPartnerEdit:MatDialogRef<PartnerratedialogeditComponent>;
  form_title: any;
  visaListId: any = [];
  visaListId_value: any = [];
  screenId: any;
  breadcrumbs: any;
  subTitle: string;
  visaRateDetails = [];
  showFieldsListvisaRate:any;
  workLocaionDetails = [];
  showFieldsListworkLocation:any;
  rateCountry:any;
  formBuildBaseObj: any;
  params: any;
  demoData: any = [];
  apiData:any;
  rateShow:boolean = false;
  workLocShow:boolean = false;
  constructor(private router: Router,
    public dialog: MatDialog,
    private qcs: GlobalformControlService,
    private service: GlobalformService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    public gfService: GlobalFunctionService,
    private http: Http,
    private activatedRouter: ActivatedRoute
  ) {
    this.activatedRouter.params.subscribe(params => this.params = params);
    

    this.visaListId.push(this.service.visaListId);
    this.screenId = this.service.screenId;

    this.formBuildBaseObj = this.screenTB.formView(this.params.id);
    if(this.params.id == "VisaPartnerMaster"){
      let formBuildBaseObjvisaRate = this.screenTB.formView('PartnerVisaRateMaster');
      let apiData
      apiData = { "formId": formBuildBaseObjvisaRate.formId, "filterString": { partnerId: this.params.dataId }, "languageCode": "en" };
      this.showFieldsListvisaRate = Array.from(Object.keys(formBuildBaseObjvisaRate.showFields));
      this.service.getFormData(apiData).subscribe(resp => {
        console.log(resp);
        if (resp.status == 'success') {
          let preBuildEvFn = formBuildBaseObjvisaRate.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: formBuildBaseObjvisaRate.formId,resp:resp.data  };
              let changed = eventCalls[preBuildEvFn](param);
              this.visaRateDetails = this.newBuildFun(changed.resp,'');
              // this.innerTemplate = changed.innerTemplate;
              // this.breadcrumbs = changed.breadcrumbs;
              // this.subTitle = changed.subTitle;
            }
          }
        }
         
      })
      this.rateShow =  true;
  }else{
    this.rateShow = false;
  }

  if(this.params.id == "HostLocationMaster"){
    let formBuildBaseObjworkLocaion = this.screenTB.formView('WorkLocationMaster');
    let apiData
    apiData = { "formId": formBuildBaseObjworkLocaion.formId, "filterString": { country:this.params.dataId }, "languageCode": "en" };
    this.showFieldsListworkLocation = Array.from(Object.keys(formBuildBaseObjworkLocaion.showFields));
    this.service.getFormData(apiData).subscribe(resp => {
      console.log(resp);
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjworkLocaion.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjworkLocaion.formId,resp:resp.data  };
            let changed = eventCalls[preBuildEvFn](param);
            this.workLocaionDetails = this.newBuildFun(changed.resp,'');
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
       
    })
    this.workLocShow =  true;
}else{
  this.workLocShow = false;
}
    let apiDataf = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.params.dataId }, "languageCode": "en" }
    this.service.getFormData(apiDataf).subscribe(resp => {
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId,rawData:resp.data[0] };
          let changed = eventCalls[preBuildEvFn](param);
          this.breadcrumbs = changed.breadcrumbs;
          this.subTitle = changed.subTitle;
          this.rateCountry = changed.country;
          //this.visaListId_value = changed.formItems;
        }
      }

      
      resp.data.map(respData => {
        this.visaListId_value.push(respData)
      })

      let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
      if (postBuildEvFn != '') {
        const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[postBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, rawData: this.visaListId_value };
          let changed = eventCalls[postBuildEvFn](param);
          
          this.visaListId_value = [];
          changed.rawData.map(resp => {
            Object.keys(resp).map(splitData => {
              // if (gfService.typeOf(resp[splitData]) == "object") {
              //   this.visaListId_value.push(resp[splitData])
              // }
              let obj = {
                fieldKey: splitData,
                values: resp[splitData],
              }
              this.visaListId_value.push(obj);
            })
          })
        }
      }

    });

  }
  edit() {
    this.router.navigate(['/FormEdit', this.params.id, this.params.dataId]);
  }

  partnerRateAdd(){
    // this.router.navigate(['/formAdd/PartnerVisaRateMaster']);
    this.dialogRefvisaPartner = this.dialog.open(PartnerratedialogComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.dialogRefvisaPartner.componentInstance.caseid = 'PartnerVisaRateMaster'; // To get data from json-builder
      this.dialogRefvisaPartner.componentInstance.rateCountry = this.rateCountry;
      this.dialogRefvisaPartner.componentInstance.partnerId =this.params.dataId
      this.dialogRefvisaPartner.afterClosed().subscribe(resp=>{
        if(resp){
        let formBuildBaseObjvisaRate = this.screenTB.formView('PartnerVisaRateMaster');
        let apiData = { "formId": formBuildBaseObjvisaRate.formId, "filterString": {  }, "languageCode": "en" };
             let preBuildEvFn = formBuildBaseObjvisaRate.eventHandler.preBuild;
             if (preBuildEvFn != '') {
               const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
               if (eventCalls[preBuildEvFn]) {
                 let param = { formId: formBuildBaseObjvisaRate.formId,resp:resp  };
                 let changed = eventCalls[preBuildEvFn](param);
                 console.log(changed.resp)
                 //this.visaRateDetails = this.newBuildFun(changed.resp,'');
                //  this.visaRateDetails = this.visaRateDetails.concat(this.newBuildFun(changed.resp,''));
                 this.visaRateDetails = (this.newBuildFun(changed.resp,{ 'oldData': this.visaRateDetails, 'operation': 'add' }));
                 
                 // this.innerTemplate = changed.innerTemplate;
                 // this.breadcrumbs = changed.breadcrumbs;
                 // this.subTitle = changed.subTitle;
               }
             }
            }
      })
  }

  workLocationAdd(){
    // this.router.navigate(['/formAdd/PartnerVisaRateMaster']);
    this.dialogRefvisaPartner = this.dialog.open(PartnerratedialogComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.dialogRefvisaPartner.componentInstance.caseid = 'WorkLocationMaster'; // To get data from json-builder
      // this.dialogRefvisaPartner.componentInstance.rateCountry = this.rateCountry;
      this.dialogRefvisaPartner.componentInstance.countryId =this.params.dataId
      this.dialogRefvisaPartner.afterClosed().subscribe(resp=>{
        if(resp){
        let formBuildBaseObjworkLocaion = this.screenTB.formView('WorkLocationMaster');
        let apiData = { "formId": formBuildBaseObjworkLocaion.formId, "filterString": {  }, "languageCode": "en" };
             let preBuildEvFn = formBuildBaseObjworkLocaion.eventHandler.preBuild;
             if (preBuildEvFn != '') {
               const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
               if (eventCalls[preBuildEvFn]) {
                 let param = { formId: formBuildBaseObjworkLocaion.formId,resp:resp  };
                 let changed = eventCalls[preBuildEvFn](param);
                 console.log(changed.resp)
                 //this.visaRateDetails = this.newBuildFun(changed.resp,'');
                //  this.visaRateDetails = this.visaRateDetails.concat(this.newBuildFun(changed.resp,''));
                 this.workLocaionDetails = (this.newBuildFun(changed.resp,{ 'oldData': this.workLocaionDetails, 'operation': 'add' }));
                 
                 // this.innerTemplate = changed.innerTemplate;
                 // this.breadcrumbs = changed.breadcrumbs;
                 // this.subTitle = changed.subTitle;
               }
             }
            }
      })
  }

  partnerRateEdit(rate){
    // this.router.navigate(['/formAdd/PartnerVisaRateMaster']);
    let dataId = rate.find(items => items.fieldKey == 'dataId');
    this.dialogRefvisaPartnerEdit = this.dialog.open(PartnerratedialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.dialogRefvisaPartnerEdit.componentInstance.caseid = 'PartnerVisaRateMaster'; // To get data from json-builder
      this.dialogRefvisaPartnerEdit.componentInstance.rateCountry = this.rateCountry;
      this.dialogRefvisaPartnerEdit.componentInstance.partnerId =this.params.dataId
      this.dialogRefvisaPartnerEdit.componentInstance.ratedataId = dataId.values;
      this.dialogRefvisaPartnerEdit.afterClosed().subscribe(resp=>{
        if(resp){
        let formBuildBaseObjvisaRate = this.screenTB.formView('PartnerVisaRateMaster');
        let apiData = { "formId": formBuildBaseObjvisaRate.formId, "filterString": {  }, "languageCode": "en" };
             let preBuildEvFn = formBuildBaseObjvisaRate.eventHandler.preBuild;
             if (preBuildEvFn != '') {
               const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
               if (eventCalls[preBuildEvFn]) {
                 let param = { formId: formBuildBaseObjvisaRate.formId,resp:resp  };
                 let changed = eventCalls[preBuildEvFn](param);
                 console.log(changed.resp)
                 //this.visaRateDetails = this.newBuildFun(changed.resp,'');
                //  this.visaRateDetails = this.visaRateDetails.concat(this.newBuildFun(changed.resp,''));
                 this.visaRateDetails = (this.newBuildFun(changed.resp,{ 'oldData': this.visaRateDetails, 'operation': 'edit' }));
                 
                 // this.innerTemplate = changed.innerTemplate;
                 // this.breadcrumbs = changed.breadcrumbs;
                 // this.subTitle = changed.subTitle;
               }
             }
            }
        
      })
  }

  workLocaionEdit(workLoc){
    // this.router.navigate(['/formAdd/PartnerVisaRateMaster']);
    let dataId = workLoc.find(items => items.fieldKey == 'dataId');
    this.dialogRefvisaPartnerEdit = this.dialog.open(PartnerratedialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.dialogRefvisaPartnerEdit.componentInstance.caseid = 'WorkLocationMaster'; // To get data from json-builder
      //this.dialogRefvisaPartnerEdit.componentInstance.rateCountry = this.rateCountry;
      this.dialogRefvisaPartnerEdit.componentInstance.countryId =this.params.dataId
      this.dialogRefvisaPartnerEdit.componentInstance.ratedataId = dataId.values;
      this.dialogRefvisaPartnerEdit.afterClosed().subscribe(resp=>{
        if(resp){
        let formBuildBaseObjworkLocaion = this.screenTB.formView('WorkLocationMaster');
        let apiData = { "formId": formBuildBaseObjworkLocaion.formId, "filterString": {  }, "languageCode": "en" };
             let preBuildEvFn = formBuildBaseObjworkLocaion.eventHandler.preBuild;
             if (preBuildEvFn != '') {
               const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
               if (eventCalls[preBuildEvFn]) {
                 let param = { formId: formBuildBaseObjworkLocaion.formId,resp:resp  };
                 let changed = eventCalls[preBuildEvFn](param);
                 console.log(changed.resp)
                 //this.visaRateDetails = this.newBuildFun(changed.resp,'');
                //  this.visaRateDetails = this.visaRateDetails.concat(this.newBuildFun(changed.resp,''));
                 this.workLocaionDetails = (this.newBuildFun(changed.resp,{ 'oldData': this.workLocaionDetails, 'operation': 'edit' }));
                 
                 // this.innerTemplate = changed.innerTemplate;
                 // this.breadcrumbs = changed.breadcrumbs;
                 // this.subTitle = changed.subTitle;
               }
             }
            }
        
      })
  }
  ngOnInit() {
    this.form_title = this.formBuildBaseObj.title;
    let a = this.formBuildBaseObj.showFields;
    let b = this.visaListId_value;
    var result = [];
    for (var i = 0; i < b.length; i++) {
      if (a[b[i].fieldKey]) {
        result.push(b[i]);
      }
    }
    this.visaListId_value = result;

  }

  newBuildFun(data,arrAlterData) {
    let finalData:any = [];
     data.map(resp =>{
       let innerArr = [];
       let reqPreview_value = [];
       let innerJson: any = {};
       let resourceDependentName;
       Object.keys(resp).map(key =>{
         let obj = {
           fieldKey:key,
           values:resp[key]
         }

         innerArr.push(obj);
       })
      
       finalData.push(innerArr);
     })
     let innerFinalData;
     if (arrAlterData != '') {
      if (arrAlterData.operation == 'edit') {
        innerFinalData = arrAlterData.oldData;
        finalData.map((finalData) => {
          finalData.map(finalDataResp => {
  
            innerFinalData.map((alterResp, index) => {
              alterResp.map((innerResp) => {
                if (finalDataResp.fieldKey == 'dataId' && innerResp.fieldKey == 'dataId') {
                  if (finalDataResp.values == innerResp.values) {
                    let filterAlterResp = finalData.filter(items => {
                      if (typeof items.values == 'object' && items.values != null) {
                        return items;
                      }
                    })
                    filterAlterResp.map(resp => {
  
                      alterResp.map(innerResp => {
                        if (typeof innerResp.values == 'object' && innerResp.values != null) {
                          if (resp.fieldKey == innerResp.fieldKey) {
                            innerResp.values = resp.values;
                          }
                        }
                      })
                    })
                    innerFinalData[index] = alterResp;
                  }
                }
              })
            })
          })
        })
        finalData = innerFinalData;
      } else
      if (arrAlterData.operation == 'add') {
        // finalData = arrAlterData.oldData.push(finalData[0]);
        // arrAlterData.oldData.push(finalData);
        // if(arrAlterData.oldData.length > 0)
        arrAlterData.oldData.push(finalData[0]);
        finalData =  arrAlterData.oldData;
      }
    } else {
      finalData = finalData;
    }
     return finalData;
  }
}