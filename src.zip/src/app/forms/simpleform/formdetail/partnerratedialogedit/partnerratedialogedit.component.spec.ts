import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerratedialogeditComponent } from './partnerratedialogedit.component';

describe('PartnerratedialogeditComponent', () => {
  let component: PartnerratedialogeditComponent;
  let fixture: ComponentFixture<PartnerratedialogeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartnerratedialogeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerratedialogeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
