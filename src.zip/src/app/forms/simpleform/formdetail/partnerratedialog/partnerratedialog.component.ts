import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { GlobalformService } from '../../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import { AlertService } from '../../../../shared/services/alert-service.service';
import { AbstractControl } from '@angular/forms';
import { GlobalFunctionService } from '../../../../shared/services/global-function.service';
import { Constants } from '../../../../constants';

@Component({
  selector: 'app-partnerratedialog',
  templateUrl: './partnerratedialog.component.html',
  styleUrls: ['./partnerratedialog.component.scss']
})
export class PartnerratedialogComponent implements OnInit {
  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  formId: any = {};
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  term_Ref: any;
  formBuildBaseObj: any;
  params: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  rateCountry:any;
  resourceId;
  partnerId;
  countryId;
  dependentId;
  contractId: any;
  buildData: any
  updatedId: any;
  caseid: any;
  resDataId: any;
  buttonData: any;
  cancelButton: any;
  _touched: boolean;
  workFlowData:any;


  ngOnInit() {
    // this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formAdd(this.caseid);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      console.log(data);
      this.buildData = data.data;
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData,rateCountry:this.rateCountry };
          let changed = eventCalls[preBuildEvFn](param);
          this.buildData = changed.formItems;
          this.buttonData = changed.buttonData;
          this.cancelButton = changed.cancelButton;

        }
      }
      setTimeout(() => {
        let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
        this.questions = buildData['fields'];
        this.form = buildData['controls'];
        console.log(buildData, this.buildData, this.formBuildBaseObj.showFields);
        this.cdRef.detectChanges();
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
      }, this.config.FORM_LOADING_SEC);
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
    })
  }
  constructor(
    public dialogRef: MatDialogRef<PartnerratedialogComponent>,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    public gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private alert: AlertService,
    private route: ActivatedRoute,
    public cdRef:ChangeDetectorRef,
    private config : Constants
  ) { }

  // buildForm(formData) {
  //   questions => [] = [];
  //   this.questions.length = 0;
  //   this.buildData = formData;
  //   let fieldData = [];
  //   let fieldGroupData = [];
  //   let fieldGroupIdData = [];

  //   /////// To Get fieldGroupId ///////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
  //     this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
  //   }

  //   /////// To Get FieldList /////////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     for (var j = 0; j < this.fieldGroupId.length; j++) {
  //       if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
  //         for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
  //           let pushData;
  //           pushData = this.buildData.fieldGroup[i].FieldList[k];
  //           pushData.visible = false;
  //           if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
  //             pushData.visible = true;
  //           }
  //           if (pushData.fieldType === 'shortText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'currencyText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'calcText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'text') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'simpleListMultiSelect') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'singleSelectOption') {
  //             let options = [
  //               { key: 'yes', value: 'Yes' },
  //               { key: 'no', value: 'No' },
  //             ]
  //             pushData.additionalMetaData = options;
  //             fieldData.push(new CheckboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'radio') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceListMulti') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileImage') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'date') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //         }
  //       }
  //     }
  //   }
  //   // let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId }};
  //   // this.service.getFormData(apiData).subscribe(resp =>{
  //   //   console.log(resp,apiData);
  //   //   fieldData.map(fromResp =>{
  //   //       resp.data.map(formDataResp =>{
  //   //         Object.keys(formDataResp).map(key =>{
  //   //           if(typeof formDataResp[key] == 'object' && formDataResp[key] != null && formDataResp[key] != undefined) {
  //   //             // // console.log(formDataResp[key])
  //   //             if(formDataResp[key].fieldId == fromResp.fieldId) {
  //   //               fromResp.value = formDataResp[key].value;
  //   //             }
  //   //             if (fromResp.fieldType === 'fileImage') {
  //   //               // // console.log(fieldData[i]);
  //   //               this.service.files = fromResp.value;
  //   //             }
  //   //           }
  //   //         })
  //   //       })
  //   //   })
  //     console.log(fieldData);
  //     this.questions = fieldData;
  //     this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
  //     this.form = this.qcs.toFormGroup(this.questions);
  //     this.cdRef.detectChanges();
  //     let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
  //     if (postBuildEvFn != '') {
  //       const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
  //       if (eventCalls[postBuildEvFn]) {
  //         let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
  //         let changed = eventCalls[postBuildEvFn](param);
  //       }
  //     }

  //   // })
  // }

  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {
    if(this.caseid == "PartnerVisaRateMaster"){
        this.form.patchValue({ partnerId: this.partnerId });
    }else if(this.caseid == "WorkLocationMaster"){
      this.form.patchValue({country:this.countryId});
    }
        let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
        let redirectTo, redirectData, apiCall,selectedItems;
        if (preSubmitEvFn != '') {
          const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preSubmitEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems,rawData:this.questions };
            let changed = eventCalls[preSubmitEvFn](param);
            this.form = changed.formItems;
            redirectTo = changed.redirectTo;
            apiCall = changed.apiCall
            redirectData = changed.redirectData;
            selectedItems = changed.selectedItems;
          }
        }
        
     
        if (!apiCall) {
         if (this.form.valid) {
          Object.keys(this.form.controls).map(fieldArrData => {
            let fieldKey = fieldArrData;
            let fieldData = this.form.controls[fieldKey]
            for (var question of this.questions) {
              if (question.fieldType === 'date') {
                var currentDate = new DatePipe('en-us');
                let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
                if (final != null)
                this.form.value[ question.fieldColumn ] = final;
              }
            }
            //  if (fieldData['nativeElement'].classList.contains('datePick')) {
            
            //   var currentDate = new DatePipe('en-us');
            //   let final = currentDate.transform(fieldData.value, 'yyyy-MM-dd')
            //   if (final != null)
            //     this.form.patchValue({ [fieldKey]: final });
            //  }
          });
          let apiValues = this.form.value;
          Object.keys(apiValues).map(resp => {
            if (apiValues[resp] == "" || apiValues[resp] == null) {
              apiValues[resp] = null;
            }
          });
          //  this.service.putForms(apiValues, this.formBuildBaseObj.formId).subscribe(resp => {
          //     console.log(resp);
          //     if(this.route.snapshot.url[0].path === 'country-selection') {
          //        localStorage.setItem("post_reqId",resp.data);
          //     }
          //    if (resp.status == 'success') {
          //       if(redirectTo != null && redirectTo != undefined && redirectTo != '') {
          //         let enquiryData;
          //         if(redirectData === 'enquiry') {
          //           enquiryData = resp.data;
          //        }
          //         this.router.navigate([redirectTo], { queryParams: {data: redirectData,enquiryId:enquiryData}});
          //       }
          //     }
    
          //     this.alertMsg(resp);
          //    });
             this.service.putForms(apiValues, this.formBuildBaseObj.formId).subscribe(data => {
               console.log(data);
              this.alertMsg(data);
              if(data.status == 'success') {
              //  var apiData = { "formId": this.formBuildBaseObj.formId, contractId:this.contractId , "languageCode": "en" };
              let apiData;
              if (this.caseid == 'PartnerVisaRateMaster'|| 'WorkLocationMaster'){
                apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: data.data }, "languageCode": "en" };
              }
              this.service.getFormData(apiData).subscribe(resp => {
                console.log(resp);
                if(resp.status == 'success')
                this.dialogRef.close(resp.data);
              })
            }
            })
          } else {
            this.alert.error("Please fill required fields.");
            this.questions.map(resp=>{
              if(this.form.controls[resp.fieldColumn].touched==false && this.form.controls[resp.fieldColumn].status=="INVALID"){
    
                this.form.controls[resp.fieldColumn].markAsTouched();
    
              }
            })
    
          }
        }else  if(selectedItems) {
          this.alert.error("This field is already listed in country list...");
        }
    
      }
    
      alertMsg(resp) {
        var message = resp.message;
        var action = '';
        if (resp.status == 'success') {
          this.alert.success(message);
        }
        else {
          this.alert.error(JSON.stringify(message));
        }
      }
}
