import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PartnerratedialogComponent } from './partnerratedialog.component';

describe('PartnerratedialogComponent', () => {
  let component: PartnerratedialogComponent;
  let fixture: ComponentFixture<PartnerratedialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PartnerratedialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PartnerratedialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
