import { TestBed, inject } from '@angular/core/testing';

import { FormBuildBaseService } from './form-build-base.service';

describe('FormBuildBaseService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FormBuildBaseService]
    });
  });

  it('should be created', inject([FormBuildBaseService], (service: FormBuildBaseService) => {
    expect(service).toBeTruthy();
  }));
});
