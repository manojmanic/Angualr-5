import { Injectable } from '@angular/core';
import { Http, Headers, Response } from "@angular/http";
import { GlobalformService } from '../../shared/services/globalform.service';
import { Observable } from 'rxjs/Rx';
import { ReactiveFormsModule, FormBuilder, FormControl, FormControlDirective, FormControlName, FormGroup, Validators } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
import { retry } from 'rxjs/operators/retry';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { GlobalFunctionService } from '../../shared/services/global-function.service';

// const originFormControlNgOnChanges = FormControlDirective.prototype.ngOnChanges;
// FormControlDirective.prototype.ngOnChanges = function () {
//   // if ((this.valueAccessor).hasOwnProperty('_elementRef') && (this.valueAccessor._elementRef).hasOwnProperty('nativeElement')) {
//     this.form.nativeElement = this.valueAccessor._elementRef.nativeElement;
//     return originFormControlNgOnChanges.apply(this, arguments);
//   // }
//   // return false;
// };

// const originFormControlNameNgOnChanges = FormControlName.prototype.ngOnChanges;
// FormControlName.prototype.ngOnChanges = function () {
//   const result = originFormControlNameNgOnChanges.apply(this, arguments);
//   // if ((this.valueAccessor).hasOwnProperty('_elementRef') && (this.valueAccessor._elementRef).hasOwnProperty('nativeElement')) {
//     this.control.nativeElement = this.valueAccessor._elementRef.nativeElement;
//     return result;
//   // }
//   // return false;
// };

@Injectable()
export class FormBuildBaseService {
  private returnData: any = {};
  private componentMethodCallSource = new Subject<any>();
  invokeEvent: Subject<any> = new Subject();
  isLogin;
  callComponent(value) {
    this.invokeEvent.next({ some: 'aaaaa' })
  }

  constructor(
    private http: Http,
    private globalFormService: GlobalformService,
    public gfService: GlobalFunctionService,
    private router: Router,
    private authGuardService: AuthGuardService
  ) {

  }

  //////////// FormView Function //////////////////
  visaViewBefore(form) {
    form.breadcrumbs = ['Home','Master','VisaType'];
    form.subTitle = '';
    return form;
  }

  visaViewAfter(form) {
    const eventCalls = this.globalFormService;
    // this.apiFun(form);
    let hostLocation;
    console.log(form);
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          
          if(resp[splitData].fieldColumn == "country"){
            hostLocation = resp[splitData].value;
          }

          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              resp[splitData]['refValue'] = resp[splitData].value;
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null){
              resp[splitData]['refValue'] = resp[splitData].value;
              splitValue = resp[splitData].value.split(",");
            }
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            else if (splitData == "preferredVisaPartner") {
              custom_data = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country="+hostLocation };
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }

  hostLocViewBefore(form) {
    form.breadcrumbs = ['Home','Master','HostLocation'];
    form.subTitle = '';
    return form;
  }

  hostLocViewAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }

  docMasterViewBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Documents'];
    form.subTitle = '';
    return form;
  }

  docMasterViewAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }

  rateCardViewBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'AddOnService'];
    form.subTitle = '';
    return form;
  }

  rateCardViewAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  termViewBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Terms'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  termViewAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  insuranceViewBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Insurance'];
    form.subTitle = '';
    return form;
  }
  insuranceViewAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  currencyViewBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Currency'];
    form.subTitle = '';
    return form;
  }
  currencyViewAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  viewQuotationViewBefore(form) {
    form.breadcrumbs = ['Home', 'Quotations'];
    form.subTitle = '';
    return form;
  }
  viewQuotationViewAfter(form) {
    return form;
  }

  viewQuotationResourceViewBefore(form) {
    return form;
  }
  viewQuotationResourceViewAfter(form) {
    return form;
  }

  viewQuotationResourceVisaViewBefore(form) {
    console.log(form);
    this.apiFun(form);
    return form;
  }
  viewQuotationResourceVisaViewAfter(form) {
    return form;
  }

  submitRequirementBefore(form) {
    form.breadcrumbs = '';
    form.subTitle = '';
    return form;

  }
  submitRequirementAfter(form) {
    return form;
  }

  singleResourceViewBefore(form) {
    Object.keys(form.resp[0]).map(key =>{
      if(key == 'emergencyContact'){
        form.resp[0][key].value = JSON.parse(form.resp[0][key].value)
        // console.log(form.emergencyContact.value);
      }
      if(key == 'mobileNo'){
        form.resp[0][key].value = JSON.parse(form.resp[0][key].value)
        // console.log(form.mobileNo.value);
      }
       if(key == 'proflePic') {
        if(form.resp[0][key] != null)
        form.profilePic = form.resp[0][key].value;
      }
      if(key == 'noOfDependents') {
        form.noOfDependents = form.resp[0][key];
      }
    })
    form.breadcrumbs = '';
    form.subTitle = form.cntNumber;
    this.apiFun(form);
    return form;
  }
  viewContractAfter(form) {
    return form;
  }
  paymentViewBefore(form) {
    form.breadcrumbs = '';
    form.subTitle = '';
    return form;
  }
  paymentViewAfter(form) {
    return form;
  }
  secondmentViewBefore(form) {
    form.breadcrumbs = '';
    form.subTitle = '';
    return form;
  }
  secondmentViewAfter(form) {
    return form;
  }
  viewDocumentsBefore(form) {
    return form;
  }
  viewDocumentsAfter(form) {
    return form;
  }
  PassportDetailsViewBefore(form) {
    this.apiFun(form);
    return form;
  }
  TravelDetailsViewBefore(form) {
    this.apiFun(form);
    return form;
  }
  ProfessionalDetailsViewBefore(form) {
    this.apiFun(form);
    return form;
  }
  VisaDetailsViewBefore(form) {
    this.apiFun(form);
    return form;
  }
  OnBoardingDetailsViewBefore(form) {
    this.apiFun(form);
    return form;
  }
  requirementDetailsViewBefore(form) {
    console.log(form);
    Object.keys(form.resp[0]).map(key =>{
      if(key == 'noOfResource') {
        form.noOfResources = form.resp[0][key].value;
      }
    })
    this.apiFun(form);
    return form;
  }

  tncViewBefore(form) {
    console.log(form);
    form.stringFormatData = { Client: 'Client', Candidate: 'Candidate' };
    return form;
  }
  tncViewAfter(form) {
    return form;
  }

  /////////////////////////////////////////////////

  ///////////////////////////////// FormAdd Function ///////////////////////////////////////////////////
  visaAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'VisaType'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    let finalData;
    let subscriptionComplete = false;

    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'country' && (arrData.fieldType == 'termsReferenceList' || arrData.fieldType == 'customList')) {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'preferredVisaPartner' && arrData.fieldType == 'customList') {
          let data = { "tableName": "VisaPartner", "keyValue": "dataId, name" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'quoteComponents' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "Components", "keyValue": "componentName,name" }
          console.log(data);
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'documentChecklist' && arrData.fieldType == 'customMultiSelectOptions') {
          let data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'documentChecklist' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'countrySimpleMulti' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }

        else if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data)
            .subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                arrData.additionalMetaData.push({ key, value: resp.data[key] });
              });
            });
        }
        else if (arrData.fieldColumn == 'addons' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data)
            .subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                arrData.additionalMetaData.push({ key, value: resp.data[key] });
              });
            });
        }
        else if (arrData.fieldColumn == 'visitType' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else {
          arrData.additionalMetaData = [];
        }
      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    form.innerTemplate = `<h3 class="descTitle">General</h3>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. 
  Aenean ultricies mi vitae est. Mauris placerat eleifend leo.`
    return form;
  }

  visaAddAfter(form) {
    const eventCalls = this.globalFormService;

    let extendableField = form.formItems.get('extendable');
    extendableField.valueChanges.subscribe(resp => {
      let extendableDuration = <HTMLElement>document.querySelector('#extendableDuration');

      if (resp == 'yes') {
        form.formItems.get('extendableDuration').setValidators([Validators.required]);
        form.formItems.get('extendableDuration').updateValueAndValidity();
        extendableDuration.hidden = false;
      } else {
        form.formItems.get('extendableDuration').setValidators(null);
        form.formItems.get('extendableDuration').updateValueAndValidity();
        extendableDuration.hidden = true;
      }
    });

    let countryField = form.formItems.get('country');
    let countryValue;
    countryField.valueChanges.subscribe(resp => {
      countryValue = resp;
      let customListData = form.rawData.filter(items => items.fieldType == 'customList');
      if (customListData.length) {
        customListData.map(customListDataResp => {
          let customListApiData;
          if (customListDataResp.fieldColumn == 'preferredVisaPartner') {
            customListApiData = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country = " + countryValue }
          }
          if (customListApiData) {
            customListDataResp.additionalMetaData = [];
            eventCalls.getCustomList(customListApiData).subscribe(resp => {
              if (resp.status == 'success') {
                Object.keys(resp.data).map(key => {
                  customListDataResp.additionalMetaData.push({ key, value: resp.data[key] });
                });
              }
            });
          }
        });
      }
    });

    return form;
  }

  visaAddSubmit(form) {
    form.redirectTo = "visa/VisaMaster";
    form.redirectData = "";
    return form;
  }
  hostLocAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'HostLocation'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  hostLocAddAfter(form) {
    return form;
  }
  hostLocAddSubmit(form) {
    //form.formItems.get('flagImage').reset({ value: '', disabled: true });
    // form.formItems.get('flagImage').setValidators(null);
    // form.formItems.get('flagImage').updateValueAndValidity();
    const eventCalls = this.globalFormService;
    if (eventCalls.files != '' && eventCalls.files) {
      form.formItems.get('flagImage').setValidators(null);
      form.formItems.get('flagImage').updateValueAndValidity();
      form.formItems.value['flagImage'] = eventCalls.files;
    } else {

      let flagImageField = form.formItems.get('flagImage');
      let flagImage = <HTMLElement>document.querySelector('.files');
      if (flagImageField.status == 'INVALID') {
        flagImage.classList.add('error');
      }
    }
    form.redirectTo = "host-location/HostLocationMaster";
    form.redirectData = "";
    return form
  }

  docMasterAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Documents'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  docMasterAddAfter(form) {
    return form;
  }
  docMasterAddSubmit(form) {
    form.redirectTo = "document/DocumentMaster";
    form.redirectData = "";
    return form;
  }

  rateCardAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'AddOnService'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    let finalData;
    let subscriptionComplete = false;

    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'rateCardType' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        if (arrData.fieldColumn == 'vendorName' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        if (arrData.fieldColumn == 'country' && arrData.fieldType == 'customList') {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        if (arrData.fieldColumn == 'visaTypeIfAny' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
          arrData.additionalMetaData = [];
          // eventCalls.getCustomList(data).subscribe(resp => {
          //   Object.keys(resp.data).map(key => {
          //     arrData.additionalMetaData.push({ key, value: resp.data[key] });
          //   });
          // });
        }
        if (arrData.fieldColumn == 'planNameIfAny' && arrData.fieldType == 'customList') {
          let data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }


      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  rateCardAddAfter(form) {
    
    const eventCalls = this.globalFormService;
    let countryValue;

    let countryField = form.formItems.get('country');
    countryField.valueChanges.subscribe(resp => {
      countryValue = resp;
      let customListData = form.rawData.find(items => items.fieldType == 'customListMultiSelect');
      if (customListData != 'undefind') {
        let customListApiData;
        if (customListData.fieldColumn == 'visaTypeIfAny') {
          customListApiData = { "tableName": "visatype", "keyValue": "dataId, visaName", "filterString": "country = " + countryValue }
        }
        customListData.additionalMetaData = [];
        eventCalls.getCustomList(customListApiData).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            customListData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });

    return form;
  }
  rateCardAddSubmit(form) {
    form.redirectTo = "rate-card/AddOnServiceMaster";
    form.redirectData = "";
    return form;
  }
  hostCountryAddBefore(form) {
    form.breadcrumbs = ['Home'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    formFileds.filter(arrData => {
      if ((arrData.fieldColumn == 'country' || arrData.fieldColumn == 'projectStatus' || arrData.fieldColumn == 'projectType') && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          // this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'country' && arrData.fieldType == 'customList') {
        let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          arrData.additionalMetaData.push({ key: 10, value: 'Others' });
        });
      }
      if (arrData.fieldColumn == 'workLocation' && arrData.fieldType == 'customList') {
        let data = { "tableName": "WorkLocation", "keyValue": "dataId, locationName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          arrData.additionalMetaData.push({ key: 10, value: 'Others' });
        });
      }
      if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          //this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'projectDomain' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          //this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.buttonData = "Submit";
    //form.cancelButton = "Cancel";
    return form;
  }

  hostCountryAddAfter(form) {
    const eventCalls = this.globalFormService;
    let countryField = form.formItems.get('country');
    countryField.valueChanges.subscribe(resp => {
      let countryName = <HTMLElement>document.querySelector('#countryName');
      let noOfResource = <HTMLElement>document.querySelector('#noOfResource');
      let projectStatus = <HTMLElement>document.querySelector('#projectStatus');
      let projectDomain = <HTMLElement>document.querySelector('#projectDomain');
      let endClient = <HTMLElement>document.querySelector('#endClient');
      let workLocation = <HTMLElement>document.querySelector('#workLocation');
      let projectType = <HTMLElement>document.querySelector('#projectType');
      let projectStartDate = <HTMLElement>document.querySelector('#projectStartDate');
      if (resp == '10') {
        countryName.hidden = false;
        noOfResource.hidden = true;
        projectStatus.hidden = true;
        projectDomain.hidden = true;
        endClient.hidden = true;
        workLocation.hidden = true;
        projectType.hidden = true;
        projectStartDate.hidden = true;
        // form.rawData.map(resp =>{
        //   if(resp.fieldColumn == 'countryName') {
        //     if(resp.fieldColumn == 'countryName') {
        //       form.formItems.get(resp.fieldColumn).setValidators([Validators.required]);
        //       form.formItems.get(resp.fieldColumn).updateValueAndValidity();
        //     }
        //   } else{
        //     form.formItems.get(resp.fieldColumn).setValidators(null);
        //     form.formItems.get(resp.fieldColumn).updateValueAndValidity();
        //   }
        // })
        form.formItems.get('countryName').setValidators([Validators.required]);
        form.formItems.get('noOfResource').setValidators(null);
        form.formItems.get('projectStatus').setValidators(null);
        form.formItems.get('projectDomain').setValidators(null);
        form.formItems.get('endClient').setValidators(null);
        form.formItems.get('workLocation').setValidators(null);
        form.formItems.get('projectType').setValidators(null);
        form.formItems.get('projectStartDate').setValidators(null);
        form.formItems.get('countryName').updateValueAndValidity();
        form.formItems.get('noOfResource').updateValueAndValidity();
        form.formItems.get('projectStatus').updateValueAndValidity();
        form.formItems.get('projectDomain').updateValueAndValidity();
        form.formItems.get('endClient').updateValueAndValidity();
        form.formItems.get('workLocation').updateValueAndValidity();
        form.formItems.get('projectType').updateValueAndValidity();
        form.formItems.get('projectStartDate').updateValueAndValidity();
      } else if (resp != undefined && resp != '10') {
        countryName.hidden = true;
        noOfResource.hidden = false;
        projectStatus.hidden = false;
        projectDomain.hidden = false;
        endClient.hidden = false;
        workLocation.hidden = false;
        projectType.hidden = false;
        projectStartDate.hidden = false;
        form.rawData.map(respData => {
        })
        // form.rawData.map(resp =>{
        //   // if(resp.isRequired == '1') {
        //     if(resp.fieldColumn == 'country' && resp.fieldColumn == 'countryName') {
        //       form.formItems.get(resp.fieldColumn).setValidators(null);
        //       form.formItems.get(resp.fieldColumn).updateValueAndValidity();
        //     }else  {
        //       form.formItems.get(resp.fieldColumn).setValidators([Validators.required]);
        //       form.formItems.get(resp.fieldColumn).updateValueAndValidity();
        //     }
        //   // } 
        // })
        form.formItems.get('countryName').setValidators(null);
        form.formItems.get('noOfResource').setValidators([Validators.required]);
        form.formItems.get('projectStatus').setValidators([Validators.required]);
        form.formItems.get('projectDomain').setValidators([Validators.required]);
        form.formItems.get('endClient').setValidators(null);
        form.formItems.get('workLocation').setValidators([Validators.required]);
        form.formItems.get('projectType').setValidators([Validators.required]);
        form.formItems.get('projectStartDate').setValidators([Validators.required]);
        form.formItems.get('countryName').updateValueAndValidity();
        form.formItems.get('noOfResource').updateValueAndValidity();
        form.formItems.get('projectStatus').updateValueAndValidity();
        form.formItems.get('projectDomain').updateValueAndValidity();
        form.formItems.get('endClient').updateValueAndValidity();
        form.formItems.get('workLocation').updateValueAndValidity();
        form.formItems.get('projectType').updateValueAndValidity();
        form.formItems.get('projectStartDate').updateValueAndValidity();
      } else {
        countryName.hidden = true;
        noOfResource.hidden = true;
        projectStatus.hidden = true;
        projectDomain.hidden = true;
        endClient.hidden = true;
        workLocation.hidden = true;
        projectType.hidden = true;
        projectStartDate.hidden = true;
        form.rawData.map(resp => {
          if (resp.isRequired == '1') {
            form.formItems.get(resp.fieldColumn).setValidators([Validators.required]);
            form.formItems.get(resp.fieldColumn).updateValueAndValidity();
          } else if (resp.isRequired == '0') {
            form.formItems.get(resp.fieldColumn).setValidators(null);
            form.formItems.get(resp.fieldColumn).updateValueAndValidity();
          }
        })
        // form.formItems.get('countryName').setValidators([Validators.required]);
        // form.formItems.get('noOfResource').setValidators([Validators.required]);
        // form.formItems.get('projectStatus').setValidators([Validators.required]);
        // form.formItems.get('projectDomain').setValidators([Validators.required]);
        // form.formItems.get('endClient').setValidators([Validators.required]);
        // form.formItems.get('workLocation').setValidators([Validators.required]);
        // form.formItems.get('projectType').setValidators([Validators.required]);
        // form.formItems.get('projectStartDate').setValidators([Validators.required]);
        // form.formItems.get('countryName').updateValueAndValidity();
        // form.formItems.get('noOfResource').updateValueAndValidity();
        // form.formItems.get('projectStatus').updateValueAndValidity();
        // form.formItems.get('projectDomain').updateValueAndValidity();
        // form.formItems.get('endClient').updateValueAndValidity();
        // form.formItems.get('workLocation').updateValueAndValidity();
        // form.formItems.get('projectType').updateValueAndValidity();
        // form.formItems.get('projectStartDate').updateValueAndValidity();
      }
    });
    
    let countryValue;
    countryField.valueChanges.subscribe(resp => {
      countryValue = resp;
      let customListData = form.rawData.filter(items => items.fieldType == 'customList');
      if (customListData.length) {
        customListData.map(customListDataResp => {
          let customListApiData;
          if (customListDataResp.fieldColumn == 'workLocation') {
            customListApiData = { "tableName": "WorkLocation", "keyValue": "dataId, locationName", "filterString": "country = " + countryValue }
          }
          if (customListApiData) {
            customListDataResp.additionalMetaData = [];
            eventCalls.getCustomList(customListApiData).subscribe(resp => {
              if (resp.status == 'success') {
                Object.keys(resp.data).map(key => {
                  customListDataResp.additionalMetaData.push({ key, value: resp.data[key] });
                });
              }
            });
          }
        });
      }
    });

    return form;
  }

  hostCountryAddSubmit(form) {
    const eventCalls = this.globalFormService;
    const functionCalls = this.gfService;
    if (form.route.snapshot.url[0].path === 'country-selection' && form.formItems.valid) {
      if (form.formItems.get('country').value == '10') {

        localStorage.setItem('country_selection_others', (form.formItems.get('countryName').value));
        form.apiCall = true;
        let countryName;
        countryName = form.formItems.get('countryName').value.toLowerCase();
        let preCountryName = form.rawData.find(items => (items.fieldType == 'customList') && (items.fieldColumn == 'country'))
        form.selectedItems = false;
        preCountryName.additionalMetaData.map(metaData => {
          if ((metaData.value).toLowerCase().trim() == countryName.trim()) {
            form.selectedItems = true;
          }
        })
        if (form.selectedItems == false)
          this.router.navigate(['enquiry/Enquiry']);
        // form.redirectTo = 'enquiry/003';
        // form.redirectData = "";
      }
      else {
        form.formItems.get('countryName').reset({ value: '', disabled: true }); // To disable CountryName(Others)
        let servicedCountry = {
          country: form.formItems.get('country').value,
          endClient: form.formItems.get('endClient').value,
          noOfResource: form.formItems.get('noOfResource').value,
          projectDomain: form.formItems.get('projectDomain').value,
          projectStatus: form.formItems.get('projectStatus').value,
          projectType: form.formItems.get('projectType').value,
          workLocation: form.formItems.get('workLocation').value,
        };
        if (localStorage.getItem("currentUser")) {
          let currentUserJson = JSON.parse(localStorage.getItem("currentUser"))
          currentUserJson["transactionId"] = functionCalls.randomHash(10);
          localStorage.setItem("currentUser", JSON.stringify(currentUserJson));
        } else {
          let currentUserJson = {
            transactionId: functionCalls.randomHash(10),
          }
          localStorage.setItem("currentUser", JSON.stringify(currentUserJson));
        }

        form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId;
        this.isLogin = this.authGuardService.isLogin;
        if (this.isLogin) {
          form.redirectTo = 'submit-requirement/submit-requirement';
          form.redirectData = "";
        }
        else {
          form.redirectTo = 'registration/SignUp';
          form.redirectData = "";
        }
      }
    }
    return form;
  }
  enquiryAddBefore(form) {
    form.breadcrumbs = ['Home'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    let finalData;
    let subscriptionComplete = false;
    console.log(form);
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if ((arrData.fieldColumn == 'projectStatus' || arrData.fieldColumn == 'projectType' || arrData.fieldColumn == 'projectDomain') && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          console.log(arrData.additionalMetaData.termsReferenceListId);
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        } else {
          arrData.additionalMetaData = [];
        }
      });
    });
    form.buttonData = "Submit";
    //form.cancelButton = "Cancel";
    return form;
  }

  enquiryAddAfter(form) {
    let enqCountry = localStorage.getItem('country_selection_others');
    form.formItems.patchValue({ hostCountry: enqCountry });
    return form;

  }

  enquiryAddSubmit(form) {
    if (form.route.snapshot.url[0].path === 'enquiry' && form.formItems.valid) {
      localStorage.removeItem('country_selection_others');
      form.redirectTo = 'successScreen';
      form.redirectData = "enquiry";
    }
    return form;
  }
  registrationAddBefore(form) {
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'companySize' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.breadcrumbs = ['Home'];
    form.subTitle = '';
    form.buttonData = "Submit";
    //form.cancelButton = "Cancel";
    return form;
  }
  registrationAddAfter(form) {
    let lsSignUpData = JSON.parse(localStorage.getItem('signupUserData'));
    if (lsSignUpData != null) {
      if (lsSignUpData.registrationType != 'Native') {
        let emailData = form.rawData.find(items => items.fieldColumn == 'emailId');
        let nameData = form.rawData.find(items => items.fieldColumn == 'contactPerson');
        emailData['readonly'] = true;
        nameData['readonly'] = true;
      }
      form.formItems.patchValue({ emailId: lsSignUpData.sigupEmail });
      form.formItems.patchValue({ contactPerson: lsSignUpData.name });

    }
    return form;
  }
  registrationAddSubmit(form) {
    
    const eventCalls = this.globalFormService;
    if (form.formItems.valid) {
      let lsSignUpData = JSON.parse(localStorage.getItem('signupUserData'));
      if (lsSignUpData != null) {
        if (lsSignUpData.registrationType == "Native") {
          form.redirectTo = 'successScreen';
          form.redirectData = "registration";
        } else {
          form.redirectTo = "signin";
          form.redirectData = "";
        }
        form.formItems.value['registrationType'] = lsSignUpData.registrationType;
        localStorage.removeItem('signupUserData');
      } else {
        form.formItems.value['registrationType'] = 'Native';
        form.redirectTo = 'successScreen';
        form.redirectData = "registration";
      }
      form.formItems.value['passwordUrl'] = document.location.origin + '/#/password-settings';

    }
    // form.formItems.patchValue ({alternatePhone:eventCalls.internationalPhoneData['alternatePhone']});
    // form.formItems.patchValue ({contactPhone:eventCalls.internationalPhoneData['contactPhone']});
    console.log(form);
    return form;
  }


  requirementAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'country' && arrData.fieldType == 'termsReferenceList') {
        let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'projectDomain' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          //this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
  }

  resourceAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'visaType' && arrData.fieldType == 'customList') {
        let data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'visaType' && arrData.fieldType == 'customListAdditionalDetail') {
        let data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'visitType' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'resNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }

    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  resourceAddAfter(form) {
    const eventCalls = this.globalFormService;
    let fieldArrLen = form.rawData.length;
    let visitTypeValue;
    let durationValue;

    let hostLocation = 0;
    Object.keys(form.requirementData).map(reqResp => {
      if (reqResp == 'country') {
        hostLocation = form.requirementData[reqResp].value;
      }
    });
    let visitTypeField = form.formItems.get('visitType');
    visitTypeField.valueChanges.subscribe(resp => {
      visitTypeValue = resp;
      let durationStart = (durationValue*30) - 15;
      let durationEnd = (durationValue*30) + 15;
      if (durationValue != '' && durationValue != null && durationValue != 'undefined') {
        let customListData = form.rawData.find(items => items.fieldType == 'customListAdditionalDetail');

        if (customListData != 'undefind') {
          let customListApiData;
          if (customListData.fieldColumn == 'visaType') {
            customListApiData = { "tableName": "visatype", "keyValue": "dataId, visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
          }
          customListData.additionalMetaData = [];
          eventCalls.getCustomList(customListApiData).subscribe(resp => {
            console.log(resp)
            if(resp.status == 'success') {
            form.formItems.patchValue({ visaType: null });
            Object.keys(resp.data).map(key => {
              customListData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            if (Object.keys(resp.data).length == 0) {
              form.rawData.map((resp,index) =>{
                if(resp.fieldType == 'tableAddons') {
                  form.rawData.splice(index,1);
                }
              })
            }
            customListApiData = { "tableName": "visatype", "keyValue": "dataId,CONCAT('Visa Type:',visaName, ',stay Validity:', stayValidity,',extendable:',  extendable,',Multiple Entries:',  multipleEntries,',entry validity:', entryValidity) as visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
            eventCalls.getCustomList(customListApiData).subscribe(innerResp => {
              console.log(innerResp);
              if (innerResp.status == "success") {
                let additionalCustomArr = innerResp.data;
                let additionalCustomDetailsArr: any = [];
                let additionalDetailsJson;
                Object.keys(additionalCustomArr).map(additionalCustomDataResp => {
                  additionalDetailsJson = {};
                  let additionalDetailsArr = additionalCustomArr[additionalCustomDataResp].split(',');
                  additionalDetailsArr.map(additionalDetailsArrResp => {
                    let additionalDetailsJsonArr = additionalDetailsArrResp.split(':');
                    console.log(additionalDetailsJsonArr);
                    additionalDetailsJson[additionalDetailsJsonArr[0]] = additionalDetailsJsonArr[1];
                  });
                  console.log(additionalDetailsArr, additionalDetailsJson);
                  if (Object.keys(additionalDetailsJson).length) {
                    additionalCustomDetailsArr.push(additionalDetailsJson);
                  }
                });
                customListData.additionalCustomData = additionalCustomDetailsArr;
              }
            })
          }
          });
        
        }
      } else {
        let customListData = form.rawData.find(items => items.fieldType == 'customListAdditionalDetail');
        customListData.additionalMetaData = [{
          key: '0',
          value: 'Please Select durationOfAssignment'
        }]
      }
    });
    let customListDataVal;
    let durationField = form.formItems.get('durationOfAssignment');
    durationField.valueChanges.subscribe(resp => {
      durationValue = Number(resp);
      let durationStart = (durationValue*30) - 15;
      let durationEnd = (durationValue*30) + 15;
      if (visitTypeValue != '' && visitTypeValue != null && visitTypeValue != 'undefined') {
        let customListData = form.rawData.find(items => items.fieldType == 'customListAdditionalDetail');
        if (customListData != 'undefind') {
          let customListApiData;
          if (customListData.fieldColumn == 'visaType') {
            customListApiData = { "tableName": "visatype", "keyValue": "dataId, visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
          }
          customListData.additionalMetaData = [];
          customListData.additionalCustomData = [];
          eventCalls.getCustomList(customListApiData).subscribe(resp => {
            if(resp.status == 'success') {
            form.formItems.patchValue({ visaType: null });
            Object.keys(resp.data).map(key => {
              customListData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            if (Object.keys(resp.data).length == 0) {
              form.rawData.map((resp,index) =>{
                if(resp.fieldType == 'tableAddons') {
                  form.rawData.splice(index,1);
                }
              })
            }
            console.log(form.rawData)
            customListApiData = { "tableName": "visatype", "keyValue": "dataId,CONCAT('Visa Type:',visaName, ',stay Validity:', stayValidity,',extendable:',  extendable,',Multiple Entries:',  multipleEntries,',entry validity:', entryValidity) as visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
            eventCalls.getCustomList(customListApiData).subscribe(innerResp => {
              if (innerResp.status == "success") {
                let additionalCustomArr = innerResp.data;
                let additionalCustomDetailsArr: any = [];
                let additionalDetailsJson;
                Object.keys(additionalCustomArr).map(additionalCustomDataResp => {
                  additionalDetailsJson = {};
                  let additionalDetailsArr = additionalCustomArr[additionalCustomDataResp].split(',');
                  additionalDetailsArr.map(additionalDetailsArrResp => {
                    let additionalDetailsJsonArr = additionalDetailsArrResp.split(':');
                    additionalDetailsJson[additionalDetailsJsonArr[0]] = additionalDetailsJsonArr[1];
                  });
                  if (Object.keys(additionalDetailsJson).length) {
                    additionalCustomDetailsArr.push(additionalDetailsJson);
                  }
                });
                customListData.additionalCustomData = additionalCustomDetailsArr;
              }
            })
          }
          });
        }
      } else {
        let customListData = form.rawData.find(items => items.fieldType == 'customListAdditionalDetail');
        customListData.additionalMetaData = [{
          key: '0',
          value: 'Please Select VisitType'
        }]
      }
    });
    let customListData = form.rawData.find(items => items.fieldType == 'customListAdditionalDetail');
    if ((visitTypeValue == null || visitTypeValue == '' || visitTypeValue == undefined) && (durationValue == null || durationValue == '' || durationValue == undefined)) {

      customListData.additionalMetaData = [{
        key: '0',
        value: 'Please Select Visit Type and Duration Of Assignment'
      }]
    }

    let visaTypeField = form.formItems.get('visaType');
    visaTypeField.valueChanges.subscribe(resp => {
      let addonsApiData = { "hostLocation": hostLocation, "visaType": resp };
      eventCalls.getAddons(addonsApiData).subscribe(resp => {
        console.log(resp);
        if(resp.status == 'success'){
          form.rawData[fieldArrLen] = {
            "fieldCaption": "Addon Services",
            "fieldColumn": "addonServices",
            "isRequired": "0",
            "isHidden": 0,
            "fieldOrder": 6,
            "fieldType": "tableAddons",
            "validationRegex": "",
            "fieldHelpText": "Onboarding By",
            "fieldHelpTextLong": "Onboarding By",
            "additionalMetaData": null,
            "validationMessage": "",
            "visible": true,
            'addonServices': resp.data
          };
        }
      });
    });
    return form;
  }

  resourceAddSubmit(form) {
    if (form.formItems.valid) {
      form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId // To Set transactionId
    }
    return form;
  }

  dependentAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'depNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'dGender' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'dBloodGroup' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'relationship' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  dependentAddAfter(form) {
    return form;
  }

  dependentAddSubmit(form) {
    form.formItems.get('dProflePic').setValidators(null);
    form.formItems.get('dProflePic').updateValueAndValidity();
    const eventCalls = this.globalFormService;
    form.formItems.value["dProflePic"] = eventCalls.files;
    // if (form.formItems.valid) {
    //   form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId // To Set transactionId
    // }
    return form;
  }

  passportAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'depNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'dGender' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'relationship' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  visaPartnerAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'VisaPartner'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'country' && arrData.fieldType == 'customList') {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";

    return form;
  }

  visaPartnerAddAfter(form) {
    return form;
  }

  visaPartnerAddSubmit(form) {
    form.redirectTo = "visapartner-list/VisaPartnerMaster";
    form.redirectData = "";
    return form;
  }

  visaPartnerEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'VisaPartner'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'country' && arrData.fieldType == 'customList') {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  visaPartnerEditAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.filter(formData => {
      if (formData.fieldType == "customList") {
        let subData = formData
        let disabledValueShow: boolean = false;
        for (var metaData of formData.additionalMetaData) {
          if (metaData.key === formData.value) {
            disabledValueShow = true;
            break;
          }
        }
        if (disabledValueShow === false && formData.value != null) {
          let custom_data;
          subData["statusData"] = formData.value;
          if (subData.fieldColumn == "country") {
            custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": subData.value }
          }
          eventCalls.getCustomList(custom_data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
            });
          })
        }
      }
    });
    return form;
  }

  visaPartnerEditSubmit(form) {
    Object.keys(form.formItems.controls).map(fieldArrData => {
      let fieldKey = fieldArrData;
      let fieldData = form.formItems.controls[fieldKey];
      for (var question of form.questions) {
        if (question.statusData) {
          if (question.fieldType == "customList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
        }
      }
    });
    form.redirectTo = "visapartner-list/VisaPartnerMaster";
    form.redirectData = "";
    return form;
  }

  visaPartnerListBefore(form) {
    return form;
  }

  visaPartnerListAfter(form) {
    const eventCalls = this.globalFormService;
    // form.resp = form.rawData;
    // this.apiFun(form);
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.toString().split(",");
            let custom_data;
             if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }

  visaPartnerViewBefore(form) {
    Object.keys(form.rawData).map(key=>{
      if(key == 'country'){
      form.country = form.rawData[key].value;
      }
  })
    form.breadcrumbs = ['Home', 'Master', 'VisaPartner'];
    form.subTitle = '';
    return form;
  }

  visaPartnerViewAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.toString().split(",");
            let custom_data;
             if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }

  visaPartnerViewSubmit(form) {
    return form;
  }

  partnerVisaRateAddBefore(form){
    console.log(form);
    form.breadcrumbs = ['Home', 'Master', 'PartnerVisaRate'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'visaType' && arrData.fieldType == 'customList') {
          let data = { "tableName": "visatype", "keyValue": "dataId, visaName","filterString": "country = " + form.rateCountry}
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  partnerVisaRateAfter(form){
    return form;
  }

  partnerVisaRateSubmit(form){
    console.log(form);
    return form;
  }

  partnerVisaRateEditBefore(form){
    console.log(form);
    form.breadcrumbs = ['Home', 'Master', 'PartnerVisaRate'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'visaType' && arrData.fieldType == 'customList') {
          let data = { "tableName": "visatype", "keyValue": "dataId, visaName","filterString": "country = " + form.rateCountry}
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  partnerVisaRateEditAfter(form){
    return form;
  }

  partnerVisaRateLEditSubmit(form){
    return form;
  }

  partnerVisaRateListBefore(form){
    return form;
  }

  partnerVisaRateListAfter(form){
    return form;
  }

  partnerVisaRateViewBefore(form){
    this.apiFun(form);
    return form;
  }

  partnerVisaRateViewAfter(form){
    return form;
  }

  partnerVisaRateViewSubmit(form){
    return form;
  }

  workLocAddBefore(form){
    form.breadcrumbs = ['Home', 'Master', 'WorkLocation'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  workLocAddAfter(form){
    return form;
  }

  workLocAddSubmit(form){
    return form;
  }

  workLocEditBefore(form){
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  workLocEditAfter(form){
    return form;
  }

  workLocEditSubmit(form){
    return form;
  }

  workLocViewBefore(form){
    return form;
  }

  workLocViewAfter(form){
    return form;
  }

  passportAddAfter(form) {
    return form;
  }

  passportAddSubmit(form) {
    return form;
  }

  previousPassportAddBefore(form){
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
 
  previousPassportAddAfter(form){
    
    return form;
  }

  previousPassportAddSubmit(form){
    return form;
  }

  previousPassportEditAddBefore(form){
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  previousPassportEditAddAfter(form){
    return form;
  }

  previousPassportEditAddSubmit(form){
    return form;
  }

  previousPassportViewBefore(form){
    this.apiFun(form);
    return form;
  }

  previousCompanyDetailsAddBefore(form){
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  previousCompanyDetailsAddAfter(form){
    return form;
  }

  previousCompanyDetailsAddSubmit(form){
    return form;
  }

  previousCompanyDetailsEditAddBefore(form){
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  previousCompanyDetailsEditAddAfter(form){
    return form;
  }

  previousCompanyDetailsEditAddSubmit(form){
    return form;
  }

  previousCompanyDetailsViewBefore(form){
    this.apiFun(form);
    return form;
  }
  travelDetailsAddBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  travelDetailsAddAfter(form) {
    return form;
  }
  travelDetailsAddSubmit(form) {
    return form;
  }
  professionalDetailsAddBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  professionalDetailsAddAfter(form) {
    return form;
  }
  professionalDetailsAddSubmit(form) {
    const eventCalls = this.globalFormService;
    form.questions.find(items => {


      Object.keys(form.formItems.value).map(key => {
        if (items.fieldType == 'fileDoc') {
          if (items.fieldColumn == key) {
            form.formItems.get(key).setValidators(null);
            form.formItems.get(key).updateValueAndValidity();
            form.formItems.value[key] = eventCalls.files[key];
          }
        }
      })
    })
    return form;
  }
  VisaDetailsAddBefore(form) {
    console.log(form);
    let country;
    if (form.hasOwnProperty('additionalData')) {
      country = form.additionalData.find(items => items.fieldKey == 'country').values.refValue;
    }
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'visaPartner' && (arrData.fieldType == 'termsReferenceList' || arrData.fieldType == 'customList')) {
          let data = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": { "country": country } };
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        } else {
          arrData.additionalMetaData = [];
        }
      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  VisaDetailsAddAfter(form) {
    return form;
  }
  VisaDetailsAddSubmit(form) {
    return form;
  }

  onBoardingDetailsAddBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  onBoardingDetailsAddAfter(form) {
    return form;
  }
  onBoardingDetailsAddSubmit(form) {
    return form;
  }

  termAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Terms'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  termAddAfter(form) {
    return form;
  }
  termAddSubmit(form) {
    form.redirectTo = "Term/TermMaster";
    form.redirectData = "";
    return form;
  }

  insuranceAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Insurance'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  insuranceAddAfter(form) {
    return form;
  }
  insuranceAddSubmit(form) {
    form.redirectTo = "insurance-list/InsuranceMaster";
    form.redirectData = "";
    return form;
  }
  currencyAddBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Currency'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  currencyAddAfter(form) {
    return form;
  }
  currencyAddSubmit(form) {
    form.redirectTo = "currency-list/CurrencyMaster";
    form.redirectData = "";
    return form;
  }
  documentAddBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  documentAddAfter(form) {
    return form;
  }
  documentAddSubmit(form) {
    const eventCalls = this.globalFormService;
    Object.keys(form.formItems.value).map(key => {
      form.formItems.get(key).setValidators(null);
      form.formItems.get(key).updateValueAndValidity();

    })
    form.formItems.value = eventCalls.files;
    // form.formItems.patchValue({1:eventCalls.files})

    // if (eventCalls.files != '' && eventCalls.files) {
    //   form.formItems.get('1').setValidators(null);
    //   form.formItems.get('1').updateValueAndValidity();
    //   form.formItems.value['1'] = eventCalls.files;
    //   form.formItems.get('2').setValidators(null);
    //   form.formItems.get('2').updateValueAndValidity();
    //   form.formItems.value['2'] = eventCalls.files;
    //   form.formItems.get('3').setValidators(null);
    //   form.formItems.get('3').updateValueAndValidity();
    //   form.formItems.value['3'] = eventCalls.files;
    //   form.formItems.get('4').setValidators(null);
    //   form.formItems.get('4').updateValueAndValidity();
    //   form.formItems.value['4'] = eventCalls.files;
    //   form.formItems.get('5').setValidators(null);
    //   form.formItems.get('5').updateValueAndValidity();
    //   form.formItems.value['5'] = eventCalls.files;
    //   form.formItems.get('6').setValidators(null);
    //   form.formItems.get('6').updateValueAndValidity();
    //   form.formItems.value['6'] = eventCalls.files;
    //   form.formItems.get('7').setValidators(null);
    //   form.formItems.get('7').updateValueAndValidity();
    //   form.formItems.value['7'] = eventCalls.files;
    //   form.formItems.get('8').setValidators(null);
    //   form.formItems.get('8').updateValueAndValidity();
    //   form.formItems.value['8'] = eventCalls.files;
    //   form.formItems.get('9').setValidators(null);
    //   form.formItems.get('9').updateValueAndValidity();
    //   form.formItems.value['9'] = eventCalls.files;
    //   form.formItems.get('10').setValidators(null);
    //   form.formItems.get('10').updateValueAndValidity();
    //   form.formItems.value['10'] = eventCalls.files;
    //   form.formItems.get('11').setValidators(null);
    //   form.formItems.get('11').updateValueAndValidity();
    //   form.formItems.value['11'] = eventCalls.files;
    // } else {

    //   let oneImageField = form.formItems.get('1');
    //   let twoImageField = form.formItems.get('2');
    //   let threeImageField = form.formItems.get('3');
    //   let fourImageField = form.formItems.get('4');
    //   let fiveImageField = form.formItems.get('5');
    //   let sixImageField = form.formItems.get('6');
    //   let sevenImageField = form.formItems.get('7');
    //   let eightImageField = form.formItems.get('8');
    //   let nineImageField = form.formItems.get('9');
    //   let tenImageField = form.formItems.get('10');
    //   let elevenImageField = form.formItems.get('11');

    //   let oneImage = <HTMLElement>document.querySelector('.files');
    //   if (oneImageField.status == 'INVALID') {
    //     oneImage.classList.add('error');
    //   }
    //   let twoImage = <HTMLElement>document.querySelector('.files');
    //   if (twoImageField.status == 'INVALID') {
    //     twoImage.classList.add('error');
    //   }
    //   let threeImage = <HTMLElement>document.querySelector('.files');
    //   if (threeImageField.status == 'INVALID') {
    //     threeImage.classList.add('error');
    //   }
    //   let fourImage = <HTMLElement>document.querySelector('.files');
    //   if (fourImageField.status == 'INVALID') {
    //     fourImage.classList.add('error');
    //   }
    //   let fiveImage = <HTMLElement>document.querySelector('.files');
    //   if (fiveImageField.status == 'INVALID') {
    //     fiveImage.classList.add('error');
    //   }
    //   let sixImage = <HTMLElement>document.querySelector('.files');
    //   if (sixImageField.status == 'INVALID') {
    //     sixImage.classList.add('error');
    //   }
    //   let sevenImage = <HTMLElement>document.querySelector('.files');
    //   if (sevenImageField.status == 'INVALID') {
    //     sevenImage.classList.add('error');
    //   }
    //   let eightImage = <HTMLElement>document.querySelector('.files');
    //   if (eightImageField.status == 'INVALID') {
    //     eightImage.classList.add('error');
    //   }
    //   let nineImage = <HTMLElement>document.querySelector('.files');
    //   if (nineImageField.status == 'INVALID') {
    //     nineImage.classList.add('error');
    //   }
    //   let tenImage = <HTMLElement>document.querySelector('.files');
    //   if (tenImageField.status == 'INVALID') {
    //     tenImage.classList.add('error');
    //   }
    //   let elevenImage = <HTMLElement>document.querySelector('.files');
    //   if (elevenImageField.status == 'INVALID') {
    //     elevenImage.classList.add('error');
    //   }

    // }
    return form;
  }

  passwordAddBefore(form){
    form.breadcrumbs = ['Home','Requirement','Password'];
    form.subTitle = '';
    form.innerTemplate = `<div style='padding:10px;background:#eaffe4;'>Welcome user! Please complete registration by setting up the password.</div>`
    form.buttonData = "Submit";
    // form.cancelButton = "Cancel";
    return form;
  }

  passwordAddAfter(form) {
    return form;
  }

  passwordAddSubmit(form) {
    return form;
  }
  /////////////////////////////////////////////////////////////////////////////////////////////////////


  ///////////////////////////////////// FormEdit Function ///////////////////////////////////////////
  visaEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'VisaType'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    let finalData;
    let subscriptionComplete = false;
    let hostLocation;
    console.log(form);
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'country' && (arrData.fieldType == 'termsReferenceList' || arrData.fieldType == 'customList')) {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          hostLocation = arrData.value;
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'documentChecklist' && arrData.fieldType == 'customMultiSelectOptions') {
          let data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'preferredVisaPartner' && arrData.fieldType == 'customList') {
          console.log(arrData)
          let data = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country = " + hostLocation };
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'documentChecklist' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }
        else if (arrData.fieldColumn == 'countrySimpleMulti' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
            // this.invokeEvent.next({ some: form });
          });
        }

        else if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data)
            .subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                arrData.additionalMetaData.push({ key, value: resp.data[key] });
              });
            });
        }
        else if (arrData.fieldColumn == 'addons' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data)
            .subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                arrData.additionalMetaData.push({ key, value: resp.data[key] });
              });
            });
        }
        else if (arrData.fieldColumn == 'visitType' && arrData.fieldType == 'termsReferenceListMulti') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        else {
          arrData.additionalMetaData = [];
        }
      });
    });
    // let extendableDuration = <HTMLElement>document.querySelector('#extendableDuration');
    // setTimeout(()=>extendableDuration.hidden = true,5000);
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  visaEditAfter(form) {
    console.log(JSON.parse(JSON.stringify(form.rawData)))
    const eventCalls = this.globalFormService;
    let hostLocation;
    form.rawData.filter(formData => {

      if (formData.fieldColumn == "country") {
        hostLocation = formData.value;
      }
      // if (formData.fieldColumn == 'preferredVisaPartner' && (formData.fieldType == 'termsReferenceList' || formData.fieldType == 'customList')) {
      //   let data = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country = " + hostLocation };
      //   formData.additionalMetaData = [];
      //   eventCalls.getCustomList(data).subscribe(resp => {
      //     console.log(resp)
      //     Object.keys(resp.data).map(key => {
      //       formData.additionalMetaData.push({ key, value: resp.data[key] });
      //     });
      //   });
      // }
      let disabledValueShow: boolean = false;
      if (formData.fieldType == "customList") {
        console.log(formData)
        console.log(JSON.parse(JSON.stringify(formData)))
        // if(formData.fieldColumn == 'preferredVisaPartner') {
        //   // let preferredVisaPartnerArr = [];
        //   let data = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country = " + hostLocation };
        //   formData.additionalMetaData = [];
        //   eventCalls.getCustomList(data).subscribe(resp => {
        //     console.log(resp)
        //     Object.keys(resp.data).map(key => {
        //       formData.additionalMetaData.push({ key, value: resp.data[key] });
        //     });
        //     // formData.additionalMetaData = preferredVisaPartnerArr
        //   });
        // }
        let subData = formData
        let disabledValueShow: boolean = false;
        for (var metaData of formData.additionalMetaData) {
          if (metaData.key === formData.value) {
            disabledValueShow = true;
            break;
          }
        }
        if (disabledValueShow === false && formData.value != null) {
          let custom_data;
          subData["statusData"] = formData.value;
          if (subData.fieldColumn == "country") {
            custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": subData.value }
          } else if (subData.fieldColumn == "planNameIfAny") {
            custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": subData.value }
          } else if (subData.fieldColumn == "visaTypeIfAny") {
            custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": subData.value }
          } else if (subData.fieldColumn == "documentChecklist") {
            custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": subData.value };
          } else if (subData.fieldColumn == "preferredVisaPartner") {
            custom_data = { "tableName": "VisaPartner", "keyValue": "dataId, name","dataId": subData.value, "filterString": "country = " + hostLocation };
          }
          
          eventCalls.getCustomList(custom_data).subscribe(resp => {
            console.log(resp,custom_data)
            console.log(resp,custom_data)
            if(resp.status == 'success'){
              Object.keys(resp.data).map(key => {
                subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
              });
            }
          })
        }
      } else if (formData.fieldType == "customListMultiSelect") {
        let subData = { ...formData };
        let innerSubData = subData;
        if (formData.value != null) {
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let custom_data;
            if (subData.fieldColumn == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": resp }
            } else if (subData.fieldColumn == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": resp }
            } else if (subData.fieldColumn == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": resp }
            } else if (subData.fieldColumn == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": resp };
            }
            eventCalls.getCustomList(custom_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceListMulti") {
        let subData = { ...formData };
        if (formData.value) {
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let termsReferenceListId = subData.additionalMetaData.termsReferenceListId;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": resp,
            };
            eventCalls.getCustomList(term_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceList") {
        if (formData.value) {
          let subData = formData;
          let disabledValueShow: boolean = false;
          for (var metaData of formData.additionalMetaData) {
            if (metaData.key === formData.value) {
              disabledValueShow = true;
              break;
            }
          }
          if (disabledValueShow === false) {
            subData["statusData"] = formData.value;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": subData.value,
            };
            eventCalls.getCustomList(term_data).subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
              });
            })
          }
        }
      }
    });

    let extendableField = form.formItems.get('extendable');
    extendableField.valueChanges.subscribe(resp => {
      let extendableDuration = <HTMLElement>document.querySelector('#extendableDuration');
      if (resp == 'yes') {
        form.formItems.get('extendableDuration').setValidators([Validators.required]);
        form.formItems.get('extendableDuration').updateValueAndValidity();
        extendableDuration.hidden = false;
      } else {
        form.formItems.get('extendableDuration').setValidators(null);
        form.formItems.get('extendableDuration').updateValueAndValidity();
        extendableDuration.hidden = true;
      }
    });
    if (extendableField.value == 'yes') {
      form.formItems.get('extendableDuration').setValidators([Validators.required]);
      form.formItems.get('extendableDuration').updateValueAndValidity();
    }




    let countryField = form.formItems.get('country');
    let countryValue;
    countryField.valueChanges.subscribe(resp => {
      countryValue = resp;
      let customListData = form.rawData.filter(items => items.fieldType == 'customList');
      if (customListData.length) {
        customListData.map(customListDataResp => {
          let customListApiData;
          if (customListDataResp.fieldColumn == 'preferredVisaPartner') {
            customListApiData = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country = " + countryValue }
          }
          if (customListApiData) {
            customListDataResp.additionalMetaData = [];
            eventCalls.getCustomList(customListApiData).subscribe(resp => {
              if (resp.status == 'success') {
                Object.keys(resp.data).map(key => {
                  customListDataResp.additionalMetaData.push({ key, value: resp.data[key] });
                });
              }
            });
          }
        });
      }
    });

    return form;
  }
  visaEditSubmit(form) {
    Object.keys(form.formItems.controls).map(fieldArrData => {
      let fieldKey = fieldArrData;
      let fieldData = form.formItems.controls[fieldKey];
      for (var question of form.questions) {
        if (question.statusData) {
          if (question.fieldType == "customList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
          if (question.fieldType == "customListMultiSelect") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceListMulti") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
        }
      }
    });
    form.redirectTo = "visa/VisaMaster";
    form.redirectData = "";
    return form;
  }
  hostLocEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'HostLocation'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  hostLocEditAfter(form) {

    return form;
  }

  hostLocEditSubmit(form) {
    // form.formItems.get('flagImage').setValidators(null);
    // form.formItems.get('flagImage').updateValueAndValidity();
    const eventCalls = this.globalFormService;
    if (eventCalls.files != '' && eventCalls.files != undefined) {
      form.formItems.get('flagImage').setValidators(null);
      form.formItems.get('flagImage').updateValueAndValidity();
      form.formItems.value['flagImage'] = eventCalls.files;
    } else {
      let flagImageField = form.formItems.get('flagImage');
      let flagImage = <HTMLElement>document.querySelector('.files');
      if (flagImageField.status == 'INVALID') {
        flagImage.classList.add('error');
      }
    }
    form.redirectTo = "host-location/HostLocationMaster";
    form.redirectData = "";
    return form
  }

  docMasterEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Documents'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  docMasterEditAfter(form) {
    return form;
  }
  docMasterEditSubmit(form) {
    form.redirectTo = "document/DocumentMaster";
    form.redirectData = "";
    return form;
  }
  rateCardEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'AddOnService'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    let finalData;
    let subscriptionComplete = false;

    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'rateCardType' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        if (arrData.fieldColumn == 'vendorName' && arrData.fieldType == 'termsReferenceList') {
          let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
          arrData.additionalMetaData = [];
          eventCalls.getTerms(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        if (arrData.fieldColumn == 'country' && arrData.fieldType == 'customList') {
          let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        if (arrData.fieldColumn == 'visaTypeIfAny' && arrData.fieldType == 'customListMultiSelect') {
          let data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
        if (arrData.fieldColumn == 'planNameIfAny' && arrData.fieldType == 'customList') {
          let data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }


      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  rateCardEditAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.filter(formData => {
      if (formData.fieldType == "customList") {
        let subData = formData
        let disabledValueShow: boolean = false;
        for (var metaData of formData.additionalMetaData) {
          if (metaData.key === formData.value) {
            disabledValueShow = true;
            break;
          }
        }
        if (disabledValueShow === false && formData.value != null) {
          let custom_data;
          subData["statusData"] = formData.value;
          if (subData.fieldColumn == "country") {
            custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": subData.value }
          } else if (subData.fieldColumn == "planNameIfAny") {
            custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": subData.value }
          } else if (subData.fieldColumn == "visaTypeIfAny") {
            custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": subData.value }
          } else if (subData.fieldColumn == "documentChecklist") {
            custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": subData.value };
          }
          eventCalls.getCustomList(custom_data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
            });
          })
        }
      } else if (formData.fieldType == "customListMultiSelect") {
        let subData = { ...formData };
        let innerSubData = subData;
        if (formData.value != null) {
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let custom_data;
            if (subData.fieldColumn == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": resp }
            } else if (subData.fieldColumn == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": resp }
            } else if (subData.fieldColumn == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": resp }
            } else if (subData.fieldColumn == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": resp };
            }
            eventCalls.getCustomList(custom_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceListMulti") {
        let subData = { ...formData };
        if (formData.value != null) {
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let termsReferenceListId = subData.additionalMetaData.termsReferenceListId;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": resp,
            };
            eventCalls.getCustomList(term_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceList") {
        if (formData.value != null) {
          let subData = formData;
          let disabledValueShow: boolean = false;
          for (var metaData of formData.additionalMetaData) {
            if (metaData.key === formData.value) {
              disabledValueShow = true;
              break;
            }
          }
          if (disabledValueShow === false && subData.value) {
            subData["statusData"] = formData.value;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": subData.value,
            };
            eventCalls.getCustomList(term_data).subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
              });
            })
          }
        }
      }
    })
    return form;
  }
  rateCardEditSubmit(form) {
    Object.keys(form.formItems.controls).map(fieldArrData => {
      let fieldKey = fieldArrData;
      let fieldData = form.formItems.controls[fieldKey];
      for (var question of form.questions) {
        if (question.statusData) {
          if (question.fieldType == "customList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
          if (question.fieldType == "customListMultiSelect") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceListMulti") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }

        }
      }
    });
    form.redirectTo = "rate-card/AddOnServiceMaster";
    form.redirectData = "";
    return form;
  }
  resourceEditAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'visaType' && arrData.fieldType == 'customList') {
        let custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(custom_data).subscribe(resp => {
          
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
            // if(key !== eventCalls.disabledValue) {
            //   custom_data["dataId"] = eventCalls.disabledValue;
            //   eventCalls.getCustomList(custom_data).subscribe(resp=>{
            //   })
            // }
          });
        });
      }
      if (arrData.fieldColumn == 'resNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'visitType' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  resourceEditAddAfter(form) {
    const eventCalls = this.globalFormService;
    let fieldArrLen = form.rawData.length;
    let visitTypeValue;
    let durationValue;

    let hostLocation = 0;
    Object.keys(form.requirementData).map(reqResp => {
      if (reqResp == 'country') {
        hostLocation = form.requirementData[reqResp].value;
      }
    });

    let visitTypeField = form.formItems.get('visitType');
    visitTypeField.valueChanges.subscribe(resp => {
      visitTypeValue = resp;
      let durationStart = (durationValue*30) - 15;
      let durationEnd = (durationValue*30) + 15;
      if (durationValue != '' && durationValue != null && durationValue != 'undefined') {
        let customListData = form.rawData.find(items => items.fieldType == 'customListAdditionalDetail');
        if (customListData != 'undefind') {
          let customListApiData;
          if (customListData.fieldColumn == 'visaType') {
            customListApiData = { "tableName": "visatype", "keyValue": "dataId, visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
          }
          customListData.additionalMetaData = [];
          eventCalls.getCustomList(customListApiData).subscribe(resp => {
            if (Object.keys(resp.data).length == 0) {
              // form.rawData[fieldArrLen] = []
              form.rawData.map((resp,index) =>{
                if(resp.fieldType == 'tableAddons') {
                  form.rawData.splice(index,1);
                }
              })
            } else {
              form.formItems.patchValue({ visaType: customListData.value });
              let addonsApiData = { "hostLocation": hostLocation, "visaType": customListData.value };
              eventCalls.getAddons(addonsApiData).subscribe(resp => {
                console.log(resp.data, form.respData, addonsApiData)
                resp.data.map(addonData => {
                  addonData.values.map(addonVal => {
                    if (addonVal['selected']) {
                      delete addonVal['selected'];
                    }
                    form.respData.map(innerData => {
                      if (innerData.fieldKey == "addons") {
                        Object.keys(innerData.values).map(splitData => {
                          if (typeof innerData.values[splitData] == "object") {
                            if (innerData.values[splitData].addonDataId == addonVal.addonDataId) {
                              addonVal['selected'] = true;
                            }
                          }
                        })
                      }
                    })
                  })
                })
                form.rawData[fieldArrLen] = {
                  "fieldCaption": "Addon Services",
                  "fieldColumn": "addonServices",
                  "isRequired": "0",
                  "isHidden": 0,
                  "fieldOrder": 6,
                  "fieldType": "tableAddons",
                  "validationRegex": "",
                  "fieldHelpText": "Onboarding By",
                  "fieldHelpTextLong": "Onboarding By",
                  "additionalMetaData": null,
                  "validationMessage": "",
                  "visible": true,
                  'addonServices': resp.data
                };
              });
            }
            Object.keys(resp.data).map(key => {
              customListData.additionalMetaData.push({ key, value: resp.data[key] });
            });

            customListApiData = { "tableName": "visatype", "keyValue": "dataId,CONCAT('Visa Type:',visaName, ',stay Validity:', stayValidity,',extendable:',  extendable,',Multiple Entries:',  multipleEntries,',entry validity:', entryValidity) as visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
            eventCalls.getCustomList(customListApiData).subscribe(innerResp => {
              console.log(innerResp);
              if (innerResp.status == "success") {
                let additionalCustomArr = innerResp.data;
                let additionalCustomDetailsArr: any = [];
                let additionalDetailsJson;
                Object.keys(additionalCustomArr).map(additionalCustomDataResp => {
                  additionalDetailsJson = {};
                  let additionalDetailsArr = additionalCustomArr[additionalCustomDataResp].split(',');
                  additionalDetailsArr.map(additionalDetailsArrResp => {
                    let additionalDetailsJsonArr = additionalDetailsArrResp.split(':');
                    additionalDetailsJson[additionalDetailsJsonArr[0]] = additionalDetailsJsonArr[1];
                  });
                  if(Object.keys(additionalDetailsJson).length){
                    additionalCustomDetailsArr.push(additionalDetailsJson);
                  }
                });
                customListData.additionalCustomData = additionalCustomDetailsArr;
              }
            })
          });
        }
      }
    });

    let durationField = form.formItems.get('durationOfAssignment');
    durationField.valueChanges.subscribe(resp => {
      durationValue = Number(resp);
      let durationStart = (durationValue*30) - 15;
      let durationEnd = (durationValue*30) + 15;
      if (visitTypeValue != '' && visitTypeValue != null && visitTypeValue != 'undefined') {
        let customListData = form.rawData.find(items => items.fieldType == 'customListAdditionalDetail');
        if (customListData != 'undefind') {
          let customListApiData;
          if (customListData.fieldColumn == 'visaType') {
            customListApiData = { "tableName": "visatype", "keyValue": "dataId, visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
          }
          customListData.additionalMetaData = [];
          eventCalls.getCustomList(customListApiData).subscribe(resp => {
            if (resp.status == 'success') {
              if (Object.keys(resp.data).length == 0) {
                // form.rawData[fieldArrLen] = []
                form.rawData.map((resp,index) =>{
                  if(resp.fieldType == 'tableAddons') {
                    form.rawData.splice(index,1);
                  }
                })
              } else {
                form.formItems.patchValue({ visaType: customListData.value });
                let addonsApiData = { "hostLocation": hostLocation, "visaType": customListData.value };
                eventCalls.getAddons(addonsApiData).subscribe(resp => {
                  console.log(resp.data, form.respData, addonsApiData)
                  resp.data.map(addonData => {
                    addonData.values.map(addonVal => {
                      if (addonVal['selected']) {
                        delete addonVal['selected'];
                      }
                      form.respData.map(innerData => {
                        if (innerData.fieldKey == "addons") {
                          Object.keys(innerData.values).map(splitData => {
                            if (typeof innerData.values[splitData] == "object") {
                              if (innerData.values[splitData].addonDataId == addonVal.addonDataId) {
                                addonVal['selected'] = true;
                              }
                            }
                          })
                        }
                      })
                    })
                  })
                  form.rawData[fieldArrLen] = {
                    "fieldCaption": "Addon Services",
                    "fieldColumn": "addonServices",
                    "isRequired": "0",
                    "isHidden": 0,
                    "fieldOrder": 6,
                    "fieldType": "tableAddons",
                    "validationRegex": "",
                    "fieldHelpText": "Onboarding By",
                    "fieldHelpTextLong": "Onboarding By",
                    "additionalMetaData": null,
                    "validationMessage": "",
                    "visible": true,
                    'addonServices': resp.data
                  };
                });
              }
              // form.rawData[fieldArrLen] = []
              Object.keys(resp.data).map(key => {
                customListData.additionalMetaData.push({ key, value: resp.data[key] });
              });
            }
            customListApiData = { "tableName": "visatype", "keyValue": "dataId,CONCAT('Visa Type:',visaName, ',stay Validity:', stayValidity,',extendable:',  extendable,',Multiple Entries:',  multipleEntries,',entry validity:', entryValidity) as visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
            eventCalls.getCustomList(customListApiData).subscribe(innerResp => {
              console.log(innerResp);
              if (innerResp.status == "success") {
                let additionalCustomArr = innerResp.data;
                let additionalCustomDetailsArr: any = [];
                let additionalDetailsJson;
                Object.keys(additionalCustomArr).map(additionalCustomDataResp => {
                  additionalDetailsJson = {};
                  let additionalDetailsArr = additionalCustomArr[additionalCustomDataResp].split(',');
                  additionalDetailsArr.map(additionalDetailsArrResp => {
                    let additionalDetailsJsonArr = additionalDetailsArrResp.split(':');
                    additionalDetailsJson[additionalDetailsJsonArr[0]] = additionalDetailsJsonArr[1];
                  });
                  console.log(additionalDetailsArr, additionalDetailsJson);
                  if (Object.keys(additionalDetailsJson).length) {
                    additionalCustomDetailsArr.push(additionalDetailsJson);
                  }
                });
                customListData.additionalCustomData = additionalCustomDetailsArr;
              }
            })
          });
        }
      }
    });

    let visaTypeField = form.formItems.get('visaType');
    visaTypeField.valueChanges.subscribe(data => {
      let addonsApiData = { "hostLocation": hostLocation, "visaType": data };
      console.log(addonsApiData)
      eventCalls.getAddons(addonsApiData).subscribe(resp => {
        if(resp.status == 'success') {
        console.log(resp.data, form.respData, addonsApiData)
        resp.data.map(addonData => {
          addonData.values.map(addonVal => {
            if (addonVal['selected']) {
              delete addonVal['selected'];
            }
            form.respData.map(innerData => {
              if (innerData.fieldKey == "addons") {
                Object.keys(innerData.values).map(splitData => {
                  if (typeof innerData.values[splitData] == "object") {
                    if (innerData.values[splitData].addonDataId == addonVal.addonDataId) {
                      addonVal['selected'] = true;
                    }
                  }
                })
              }
            })
          })
        })
        form.rawData[fieldArrLen] = {
          "fieldCaption": "Addon Services",
          "fieldColumn": "addonServices",
          "isRequired": "0",
          "isHidden": 0,
          "fieldOrder": 6,
          "fieldType": "tableAddons",
          "validationRegex": "",
          "fieldHelpText": "Onboarding By",
          "fieldHelpTextLong": "Onboarding By",
          "additionalMetaData": null,
          "validationMessage": "",
          "visible": true,
          'addonServices': resp.data
        };
      }
      });
    });
    /////////////////////// Before Onchange ///////////////////////////
    let visitTypeVal;
    let durationFieldValue;
    let visaTypeFieldValue;
    form.rawData.filter(splitData => {
      if (splitData.fieldType == "termsReferenceList" && splitData.fieldColumn == "visitType") {

        visitTypeValue = splitData.value;
      }
      if (splitData.fieldType == "shortText" && splitData.fieldColumn == "durationOfAssignment") {
        durationValue = Number(splitData.value);
      }
      // if (splitData.fieldType == "currencyText" && splitData.fieldColumn == "durationOfAssignment") {
      //   durationValue = Number(splitData.value);
      // }
      if (splitData.fieldType == "customListAdditionalDetail" && splitData.fieldColumn == "visaType") {
        visaTypeFieldValue = splitData.value;
        let durationStart = (durationValue*30) - 15;
        let durationEnd = (durationValue*30) + 15;
        splitData.additionalMetaData = [];
        let customListApiData = { "tableName": "visatype", "keyValue": "dataId, visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
        eventCalls.getCustomList(customListApiData).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            splitData.additionalMetaData.push({ key, value: resp.data[key] });
          });

          customListApiData = { "tableName": "visatype", "keyValue": "dataId,CONCAT('Visa Type:',visaName, ',stay Validity:', stayValidity,',extendable:',  extendable,',Multiple Entries:',  multipleEntries,',entry validity:', entryValidity) as visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
          eventCalls.getCustomList(customListApiData).subscribe(innerResp => {
            console.log(innerResp);
            if (innerResp.status == "success") {
              let additionalCustomArr = innerResp.data;
              let additionalCustomDetailsArr: any = [];
              let additionalDetailsJson;
              Object.keys(additionalCustomArr).map(additionalCustomDataResp => {
                additionalDetailsJson = {};
                let additionalDetailsArr = additionalCustomArr[additionalCustomDataResp].split(',');
                additionalDetailsArr.map(additionalDetailsArrResp => {
                  let additionalDetailsJsonArr = additionalDetailsArrResp.split(':');
                  additionalDetailsJson[additionalDetailsJsonArr[0]] = additionalDetailsJsonArr[1];
                });
                console.log(additionalDetailsArr, additionalDetailsJson);
                if (Object.keys(additionalDetailsJson).length) {
                  additionalCustomDetailsArr.push(additionalDetailsJson);
                }
              });
              splitData.additionalCustomData = additionalCustomDetailsArr;
            }
          })
        });
      }
    })
    let addonsApiData = { "hostLocation": hostLocation, "visaType": visaTypeFieldValue };
    eventCalls.getAddons(addonsApiData).subscribe(resp => {
      console.log(resp)
      if(resp.status == 'success')
      resp.data.map(addonData => {
        addonData.values.map(addonVal => {
          if (addonVal['selected']) {
            delete addonVal['selected'];
          }
          form.respData.map(innerData => {
            if (innerData.fieldKey == "addons") {
              Object.keys(innerData.values).map(splitData => {
                if (typeof innerData.values[splitData] == "object") {
                  if (innerData.values[splitData].addonDataId == addonVal.addonDataId) {
                    addonVal['selected'] = true;
                  }
                }
              })
            }
          })
        })
      })
      form.rawData[fieldArrLen] = {
        "fieldCaption": "Addon Services",
        "fieldColumn": "addonServices",
        "isRequired": "0",
        "isHidden": 0,
        "fieldOrder": 6,
        "fieldType": "tableAddons",
        "validationRegex": "",
        "fieldHelpText": "Onboarding By",
        "fieldHelpTextLong": "Onboarding By",
        "additionalMetaData": null,
        "validationMessage": "",
        "visible": true,
        'addonServices': resp.data
      };
    });
    return form;
  }

  resourceEditAddSubmit(form) {
    Object.keys(form.formItems.controls).map(fieldArrData => {
      let fieldKey = fieldArrData;
      let fieldData = form.formItems.controls[fieldKey];
      for (var question of form.questions) {
        if (question.fieldType == "customList" && question.fieldColumn == "visaType") {
          if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
            form["status"] = "DeActivated";
          }

        }
      }
    });
    if (form.formItems.valid) {
      form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId // To Set transactionId
    }
    return form;
  }
  dependentEditAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'depNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'dGender' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'dBloodGroup' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'relationship' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  dependentEditAddAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.filter(formData => {
      if (formData.fieldType == "customList") {
        let subData = formData
        let disabledValueShow: boolean = false;
        for (var metaData of formData.additionalMetaData) {
          if (metaData.key === formData.value) {
            disabledValueShow = true;
            break;
          }
        }
        if (disabledValueShow === false && formData.value != null) {
          let custom_data;
          subData["statusData"] = formData.value;
          if (subData.fieldColumn == "country") {
            custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": subData.value }
          } else if (subData.fieldColumn == "planNameIfAny") {
            custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": subData.value }
          } else if (subData.fieldColumn == "visaTypeIfAny") {
            custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": subData.value }
          } else if (subData.fieldColumn == "documentChecklist") {
            custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": subData.value };
          }
          eventCalls.getCustomList(custom_data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
            });
          })
        }
      } else if (formData.fieldType == "customListMultiSelect") {
        if (formData.value != null) {
          let subData = { ...formData };
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let custom_data;
            if (subData.fieldColumn == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": resp }
            } else if (subData.fieldColumn == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": resp }
            } else if (subData.fieldColumn == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": resp }
            } else if (subData.fieldColumn == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": resp };
            }
            eventCalls.getCustomList(custom_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceListMulti") {
        let subData = { ...formData };
        if (formData.value != null) {
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let termsReferenceListId = subData.additionalMetaData.termsReferenceListId;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": resp,
            };
            eventCalls.getCustomList(term_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceList") {
        if (formData.value != null) {
          let subData = formData;
          let disabledValueShow: boolean = false;
          for (var metaData of formData.additionalMetaData) {
            if (metaData.key === formData.value) {
              disabledValueShow = true;
              break;
            }
          }
          if (disabledValueShow === false) {
            subData["statusData"] = formData.value;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": subData.value,
            };
            eventCalls.getCustomList(term_data).subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
              });
            })
          }
        }
      }
    });

    return form;
  }

  dependentEditAddSubmit(form) {
    form.formItems.get('dProflePic').setValidators(null);
    form.formItems.get('dProflePic').updateValueAndValidity();
    const eventCalls = this.globalFormService;
    form.formItems.value["dProflePic"] = eventCalls.files;
    Object.keys(form.formItems.controls).map(fieldArrData => {
      let fieldKey = fieldArrData;
      let fieldData = form.formItems.controls[fieldKey];
      for (var question of form.questions) {
        if (question.statusData) {
          if (question.fieldType == "customList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
          if (question.fieldType == "customListMultiSelect") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceListMulti") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
        }
      }
    });
    // if (form.formItems.valid) {
    //   form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId // To Set transactionId
    // }
    return form;
  }

  passportEditAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'depNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'dGender' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'relationship' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }

  passportEditAddAfter(form) {
    return form;
  }

  passportEditAddSubmit(form) {
    return form;
  }
  TravelDetailsEditAddBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  TravelDetailsEditAddAfter(form) {
    return form;
  }
  TravelDetailsEditAddSubmit(form) {
    return form;
  }
  ProfessionalDetailsEditAddBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  ProfessionalDetailsEditAddAfter(form) {
    return form;
  }
  ProfessionalDetailsEditAddSubmit(form) {
    const eventCalls = this.globalFormService;
    form.questions.find(items => {


      Object.keys(form.formItems.value).map(key => {
        if (items.fieldType == 'fileDoc') {
          if (items.fieldColumn == key) {
            form.formItems.get(key).setValidators(null);
            form.formItems.get(key).updateValueAndValidity();
            form.formItems.value[key] = eventCalls.files[key];
          }
        }
      })
    })
    //  form.formItems.value=eventCalls.files;

    return form;
  }

  VisaDetailsEditAddBefore(form) {
    let country;
    if (form.hasOwnProperty('additionalData')) {
      country = form.additionalData.find(items => items.fieldKey == 'country').values.refValue;
      // console.log(country)
    }
    const eventCalls = this.globalFormService;
    let formGroups = form.formItems.fieldGroup;
    formGroups.filter(formGroupsData => {
      let formFields = formGroupsData.FieldList;
      formFields.filter(arrData => {
        if (arrData.fieldColumn == 'visaPartner' && (arrData.fieldType == 'termsReferenceList' || arrData.fieldType == 'customList')) {
          let data = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country=" + country };
          arrData.additionalMetaData = [];
          eventCalls.getCustomList(data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
            });
          });
        }
      });
    });
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  VisaDetailsEditAddAfter(form) {
    return form;
  }
  VisaDetailsEditAddSubmit(form) {
    return form;
  }
  onBoardingDetailsEditBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  onBoardingDetailsEditAfter(form) {
    return form;
  }
  onBoardingDetailsEditSubmit(form) {
    return form;
  }
  contractResourceEditAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'visaType' && arrData.fieldType == 'customList') {
        let data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'resNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'gender' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'bloodGroup' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    form.buttonData = "Submit";
    form.cancelButton = "Close";
    return form;
  }

  contractResourceEditAddAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.filter(formData => {
      if (formData.fieldType == "customList") {
        let subData = formData
        let disabledValueShow: boolean = false;
        for (var metaData of formData.additionalMetaData) {
          if (metaData.key === formData.value) {
            disabledValueShow = true;
            break;
          }
        }
        if (disabledValueShow === false && formData.value != null) {
          let custom_data;
          subData["statusData"] = formData.value;
          if (subData.fieldColumn == "country") {
            custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": subData.value }
          } else if (subData.fieldColumn == "planNameIfAny") {
            custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": subData.value }
          } else if (subData.fieldColumn == "visaTypeIfAny") {
            custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": subData.value }
          } else if (subData.fieldColumn == "documentChecklist") {
            custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": subData.value };
          }
          eventCalls.getCustomList(custom_data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
            });
          })
        }
      } else if (formData.fieldType == "customListMultiSelect") {
        if (formData.value != null) {
          let subData = { ...formData };
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let custom_data;
            if (subData.fieldColumn == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": resp }
            } else if (subData.fieldColumn == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": resp }
            } else if (subData.fieldColumn == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": resp }
            } else if (subData.fieldColumn == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": resp };
            }
            eventCalls.getCustomList(custom_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceListMulti") {
        if (formData.value != null) {
          let subData = { ...formData };
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let termsReferenceListId = subData.additionalMetaData.termsReferenceListId;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": resp,
            };
            eventCalls.getCustomList(term_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceList") {
        if (formData.value != null) {
          let subData = formData;
          let disabledValueShow: boolean = false;
          for (var metaData of formData.additionalMetaData) {
            if (metaData.key === formData.value) {
              disabledValueShow = true;
              break;
            }
          }
          if (disabledValueShow === false && subData.value != null) {
            subData["statusData"] = formData.value;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": subData.value,
            };
            eventCalls.getCustomList(term_data).subscribe(resp => {
              if(resp.status == 'success')
              //  if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
              });
            })
          }
        }
      }
    });
    return form;
  }

  contractResourceEditAddSubmit(form) {
    form.formItems.get('proflePic').setValidators(null);
    form.formItems.get('proflePic').updateValueAndValidity();
    const eventCalls = this.globalFormService;
    // form.formItems.patchValue({ proflePic: eventCalls.files });
    form.formItems.value["proflePic"] = eventCalls.files;
    Object.keys(form.formItems.controls).map(fieldArrData => {
      let fieldKey = fieldArrData;
      let fieldData = form.formItems.controls[fieldKey];
      for (var question of form.questions) {
        if (question.statusData && question.visible && !question.readonly) {
          if (question.fieldType == "customList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
          if (question.fieldType == "customListMultiSelect") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceListMulti") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
        }
      }
    });
    // if (form.formItems.valid) {
    //   form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId// To Set transactionId
    // }
    return form;
  }
  contractDependentEditAddBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    let additionalMetaData = [];
    formFileds.filter(arrData => {
      if (arrData.fieldColumn == 'depNationality' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'gender' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'relationship' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    return form;
  }

  contractDependentEditAddAfter(form) {
    return form;
  }

  contractDependentEditAddSubmit(form) {
    if (form.formItems.valid) {
      form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId// To Set transactionId
    }
    return form;
  }
  quotationEditBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";

    // let formFileds = form.formItems.fieldGroup[0].FieldList;

    // let addonGroup: any = {};
    // form.resp.map(respData => {

    //   let addonGrp: any = {};
    //   let finalGrp: any = {};
    //   let addonArr: any = [];
    //   let finalData: any = [];
    //   Object.keys(respData).map(splitVal => {

    //       if (splitVal == "addons") {
    //         respData[splitVal].map(addonData => {

    //           let innerAddonArr: any[] = [];
    //           let addonCntrl = {};
    //           Object.keys(addonData).map(addonSplit => {
    //             addonData['formGroupName'] = 'addonId_' + addonData.addonDataId['value'];
    //             if (typeof addonData[addonSplit] == "object") {
    //               addonData[addonSplit].fieldColumn = addonSplit;
    //               addonData[addonSplit].fieldName = addonData.addonName;
    //               if (addonData[addonSplit].fieldColumn == 'addonId') {
    //                 addonData[addonSplit].fieldColumn = 'dataId';
    //               }
    //               addonData[addonSplit].FieldGroupName = 'addonId_' + addonData.addonDataId['value']
    //               innerAddonArr.push(addonData[addonSplit]);
    //             }
    //           })
    //           addonArr.push(innerAddonArr)
    //         });
    //         addonGroup = finalGrp;
    //         let jsonData = {
    //           "fieldCaption": "Addon Services",
    //           "fieldColumn": "addonServices",
    //           // "isRequired": "0",
    //           // "isHidden": 0,
    //           "fieldOrder": 0,
    //           "fieldType": "tableAddon",
    //           // "validationRegex": "",
    //           // "fieldHelpText": "",
    //           // "fieldHelpTextLong": "",
    //           // "additionalMetaData": null,
    //           // "validationMessage": "",
    //           "visible": true,
    //           'addonServices': addonArr
    //         };
    //         formFileds.push(addonArr);
    //         finalData.push(jsonData);
    //       }
    //   });
    // });
    
    return form;
  }

  quotationEditAfter(form) {
    let initialQuotationAmt = 0;
    let initialAddonAmt = 0;
    let loginData = JSON.parse(localStorage.getItem("currentUser"));
    let globalTaxAmount;
    if (loginData != null) {
      if (loginData.hasOwnProperty('globalConfiguration')) {
        globalTaxAmount = Number(loginData.globalConfiguration.tax);
      }
    }
    form.rawData.map(respData => {
      // if (respData.fieldColumn == "passportStampingCost" || respData.fieldColumn == "visaAmount") {
      //   if (respData.value != undefined)
      //     initialQuotationAmt = initialQuotationAmt + respData.value;
      // }
      if (respData.fieldColumn == "taxAmount" || respData.fieldColumn == "totalAmount" || respData.fieldColumn == "subTotal") {
        if (respData.readOnly) {
          delete respData.readOnly;
        }
        respData.readOnly = true;
      }
      if (respData.visible == true && respData.readOnly != true && respData.fieldType == 'currencyText') {
        if (respData.value != undefined)
          initialQuotationAmt = initialQuotationAmt + respData.value;
      }
      if (respData.fieldType == "tableAddon") {
        respData.addonServices.map(addonRes => {
          let addonRate = addonRes.find(items => items.fieldColumn == 'rate');
          initialAddonAmt = initialAddonAmt + addonRate.value;
        })
      }
    })
    let initialSubTot = 0;
    let initialRedutAmt = 0;
    let initialTotAmt = 0;
    initialSubTot = initialQuotationAmt + initialAddonAmt;
    initialRedutAmt = initialSubTot * globalTaxAmount / 100;
    //initialTotAmt = initialTotAmt + initialRedutAmt;
    form.formItems.controls['taxAmount'].value = initialRedutAmt;
    form.formItems.controls['subTotal'].value = initialSubTot;
    form.formItems.controls['totalAmount'].value = initialSubTot + initialRedutAmt;
    //let visaAmountField = form.formItems.get('visaAmount');
    // visaAmountField.valueChanges.subscribe(resp => {
    //   let addonTot = 0;
    //   let quotationTot = 0;
    //   quotationTot = Number(form.formItems.controls['passportStampingCost'].value);
    //   let addonData = form.formItems.controls['addonGroup'].value;
    //   Object.keys(addonData).map(addonRes => {
    //     addonTot = addonTot + Number(addonData[addonRes].rate);
    //   })

    //   let sub_total = 0;
    //   let totalAmount = 0;
    //   let reductionAmount = 0;
    //   sub_total = addonTot + quotationTot + Number(resp);
    //   reductionAmount = sub_total * globalTaxAmount / 100;
    //   totalAmount = sub_total + reductionAmount;
    //   form.formItems.patchValue({ subTotal: sub_total });
    //   form.formItems.patchValue({ totalAmount: totalAmount });
    // })
    ///////////// passportStampingCost ////////////////////
    // let passportStampingCostField = form.formItems.get('passportStampingCost');
    // passportStampingCostField.valueChanges.subscribe(resp => {
    //   let addonTot = 0;
    //   let quotationTot = 0;
    //   quotationTot = Number(form.formItems.controls['visaAmount'].value);
    //   let addonData = form.formItems.controls['addonGroup'].value;
    //   Object.keys(addonData).map(addonRes => {
    //     addonTot = addonTot + Number(addonData[addonRes].rate);
    //   })

    //   let sub_total = 0;
    //   let totalAmount = 0;
    //   let reductionAmount = 0;
    //   sub_total = addonTot + quotationTot + Number(resp);
    //   reductionAmount = sub_total * globalTaxAmount / 100;
    //   totalAmount = sub_total + reductionAmount;
    //   form.formItems.patchValue({ subTotal: sub_total });
    //   form.formItems.patchValue({ totalAmount: totalAmount });
    // })
    // Object.keys(demoData).map(demoRes =>{
    //   if(demoRes != 'addonGroup') {
    //   }
    // })

    //////////////  Quotation Total Calc ////////////////
    form.rawData.map(resp => {
      if (resp.visible == true && resp.readOnly != true && resp.fieldType == 'currencyText') {
        form.formItems.controls[resp.fieldColumn].valueChanges.subscribe(formResp => {
          let quotationTot = 0;
          let addonTot = 0;
          form.rawData.map(innerResp => {
            if (innerResp.visible == true && innerResp.readOnly != true && innerResp.fieldType == 'currencyText') {
              if (resp.fieldColumn != innerResp.fieldColumn) {
                quotationTot = quotationTot + Number(form.formItems.controls[innerResp.fieldColumn].value);

              }
            }
          })
          let addonData = form.formItems.controls['addonGroup'].value;
          Object.keys(addonData).map(addonRes => {
            addonTot = addonTot + Number(addonData[addonRes].rate);
          })
          addonTot = addonTot + Number(formResp);
          let sub_total = 0;
          let totalAmount = 0;
          let reductionAmount = 0;
          sub_total = addonTot + quotationTot;
          reductionAmount = sub_total * globalTaxAmount / 100;
          totalAmount = sub_total + reductionAmount;
          form.formItems.patchValue({ subTotal: sub_total });
          form.formItems.patchValue({ taxAmount: reductionAmount });
          form.formItems.patchValue({ totalAmount: totalAmount });
        })
      }
    })

    ////////////////// Addon Total Calc ///////////////
    // form.rawData.map(formRes =>{
    //   if(formRes.fieldType == 'tableAddon') {
    //     formRes.addonServices.map(addonRes =>{
    //       addonRes.map(addonSplit =>{
    //         form.formItems.controls['addonGroup'].controls[addonSplit.addonGroupName].get('rate').valueChanges.subscribe(resp => {
    //            let quotationTot = 0;
    //            let addonTot = 0;
    //            form.rawData.map(innerformRes =>{
    //             // addonTot = 0;
    //             if(innerformRes.fieldType == 'tableAddon') {
    //               innerformRes.addonServices.map(innerAddonRes =>{
    //                // addonTot = 0;
    //                 innerAddonRes.map(innerAddonSplit =>{
    //                  // addonTot = 0;
    //                   if (addonSplit.addonGroupName != innerAddonSplit.addonGroupName){ 
    //                     addonTot = 0;
    //                   addonTot = Number(addonTot) + (Number(form.formItems.controls['addonGroup'].controls[innerAddonSplit.addonGroupName].get('rate').value))
    //                   }
    //                 })
    //               })
    //             }
    //           })
    //          })
    //       })
    //     })
    //   }
    // })
    let addonData = form.formItems.controls['addonGroup'].value;
     // form.rawData.map(formRes =>{
    //   if(formRes.fieldType == 'tableAddon') {
    //     formRes.addonServices.map(addonRes =>{
    //       addonRes.map(addonSplit =>{
    //
    Object.keys(addonData).map(addonRes => {
      let contrlAddonRes = addonRes;
      form.formItems.controls['addonGroup'].controls[addonRes].get('rate').valueChanges.subscribe(resp => {
         if(resp) {
        let addonTot = 0;
        let currentAddonRate = 0;
        currentAddonRate = resp;
        Object.keys(addonData).map(inneraddonRes => {
          // resp = 0;
          if (addonRes != inneraddonRes) {
            addonTot = Number(addonTot) + Number(form.formItems.controls['addonGroup'].controls[inneraddonRes].get('rate').value);

          }
        })
        addonTot = Number(addonTot) + Number(currentAddonRate);
        let quotationTot = 0;
        // quotationTot = Number(form.formItems.controls['visaAmount'].value) + Number(form.formItems.controls['passportStampingCost'].value);
        form.rawData.map(rawDataResp => {
          if (rawDataResp.visible == true && rawDataResp.readOnly != true && rawDataResp.fieldType == 'currencyText') {
            quotationTot = Number(quotationTot) + Number(form.formItems.controls[rawDataResp.fieldColumn].value);
          }
        })
        let sub_total = 0;
        let totalAmount = 0;
        let reductionAmount = 0;
        sub_total = addonTot + quotationTot;
        reductionAmount = sub_total * globalTaxAmount / 100;
        totalAmount = sub_total + reductionAmount;
        form.formItems.patchValue({ subTotal: sub_total });
        form.formItems.patchValue({ taxAmount: reductionAmount });
        form.formItems.patchValue({ totalAmount: totalAmount });
      }
      })
    })
    return form;
  }

  quotationEditSubmit(form) {

    return form;
  }
  quotationResourceEditBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";

    return form;
  }

  quotationResourceEditAfter(form) {

    return form;
  }

  quotationResourceEditSubmit(form) {

    return form;
  }


  quotationResourceVisaInfoEditBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";

    return form;
  }

  quotationResourceVisaInfoEditAfter(form) {


    const eventCalls = this.globalFormService;
    console.log(form);
    let durationValue = form.getFormData[0].durationOfAssignment;
    let visitTypeValue = form.getFormData[0].visitType;
    let countryValue = form.dialogData.find(items => items.fieldKey == 'country');
    let hostLocation = countryValue.values.refValue;
    form.rawData.filter(splitData => {
      if (splitData.fieldType == "customListAdditionalDetail" && splitData.fieldColumn == "visaType") {
        let durationStart = (durationValue*30) - 15;
        let durationEnd = (durationValue*30) + 15;
        splitData.additionalMetaData = [];
        let customListApiData = { "tableName": "visatype", "keyValue": "dataId, visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
        eventCalls.getCustomList(customListApiData).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            splitData.additionalMetaData.push({ key, value: resp.data[key] });
          });

          customListApiData = { "tableName": "visatype", "keyValue": "dataId,CONCAT('Visa Type:',visaName, ',stay Validity:', stayValidity,',extendable:',  extendable,',Multiple Entries:',  multipleEntries,',entry validity:', entryValidity) as visaName", "filterString": "country = " + hostLocation + " AND find_in_set('" + visitTypeValue + "',visitType) <> 0 AND(stayValidity BETWEEN " + durationStart + " AND " + durationEnd + ")" }
          eventCalls.getCustomList(customListApiData).subscribe(innerResp => {
            console.log(innerResp);
            if (innerResp.status == "success") {
              let additionalCustomArr = innerResp.data;
              let additionalCustomDetailsArr: any = [];
              let additionalDetailsJson;
              Object.keys(additionalCustomArr).map(additionalCustomDataResp => {
                additionalDetailsJson = {};
                let additionalDetailsArr = additionalCustomArr[additionalCustomDataResp].split(',');
                additionalDetailsArr.map(additionalDetailsArrResp => {
                  let additionalDetailsJsonArr = additionalDetailsArrResp.split(':');
                  additionalDetailsJson[additionalDetailsJsonArr[0]] = additionalDetailsJsonArr[1];
                });
                console.log(additionalDetailsArr, additionalDetailsJson);
                if (Object.keys(additionalDetailsJson).length) {
                  additionalCustomDetailsArr.push(additionalDetailsJson);
                }
              });
              splitData.additionalCustomData = additionalCustomDetailsArr;
            }
          })
        });
      }
    })
    return form;
  }
  quotationResourceVisaInfoEditSubmit(form) {

    return form;
  }
  quotationDependentEditBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";

    return form;
  }

  quotationDependentEditAfter(form) {

    return form;
  }

  quotationDependentEditSubmit(form) {

    return form;
  }
  projectDetailsEditBefore(form) {
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    // let hostLocation;
    const eventCalls = this.globalFormService;
    let formFileds = form.formItems.fieldGroup[0].FieldList;
    formFileds.filter(arrData => {
      if ((arrData.fieldColumn == 'country' || arrData.fieldColumn == 'projectStatus' || arrData.fieldColumn == 'projectType') && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        // hostLocation = arrData.value;
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            if (key !== "10")
              arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          //this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'country' && arrData.fieldType == 'customList') {
        let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
      if (arrData.fieldColumn == 'workLocation' && arrData.fieldType == 'customList') {
        let data = { "tableName": "WorkLocation", "keyValue": "dataId, locationName","filterString": "country = " + 7 }
        arrData.additionalMetaData = [];
        eventCalls.getCustomList(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          arrData.additionalMetaData.push({ key: 10, value: 'Others' });
        });
      }
      if (arrData.fieldColumn == 'projectDomain' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          //this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'photoBgColor' && arrData.fieldType == 'termsReferenceList') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
          //this.invokeEvent.next({ some: form });
        });
      }
      if (arrData.fieldColumn == 'photoBgColorMulti' && arrData.fieldType == 'termsReferenceListMulti') {
        let data = { "termSetId": arrData.additionalMetaData.termsReferenceListId };
        arrData.additionalMetaData = [];
        eventCalls.getTerms(data).subscribe(resp => {
          if(resp.status == 'success')
          Object.keys(resp.data).map(key => {
            arrData.additionalMetaData.push({ key, value: resp.data[key] });
          });
        });
      }
    });
    
    form.buttonData = "Submit";
    form.cancelButton = "Close";
    return form;
  }
  projectDetailsEditAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.filter(formData => {
      if (formData.fieldType == "customList") {
        let subData = formData
        let disabledValueShow: boolean = false;
        if(formData.additionalMetaData != null && formData.value != '' && formData.value != null && formData.value != undefined)
        for (var metaData of formData.additionalMetaData) {
          if (metaData.key === formData.value) {
            disabledValueShow = true;
            break;
          }
        }
        if (disabledValueShow === false && formData.value != null && formData.value != '') {
          let custom_data;
          subData["statusData"] = formData.value;
          if (subData.fieldColumn == "country") {
            custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": subData.value }
          } else if (subData.fieldColumn == "planNameIfAny") {
            custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": subData.value }
          } else if (subData.fieldColumn == "visaTypeIfAny") {
            custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": subData.value }
          } else if (subData.fieldColumn == "documentChecklist") {
            custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": subData.value };
          }
          eventCalls.getCustomList(custom_data).subscribe(resp => {
            if(resp.status == 'success')
            Object.keys(resp.data).map(key => {
              subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
            });
          })
        }
      } else if (formData.fieldType == "customListMultiSelect") {
        if (formData.value != null && formData.value != '') {
          let subData = { ...formData };
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let custom_data;
            if (subData.fieldColumn == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName", "dataId": resp }
            } else if (subData.fieldColumn == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName", "dataId": resp }
            } else if (subData.fieldColumn == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName", "dataId": resp }
            } else if (subData.fieldColumn == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName", "dataId": resp };
            }
            eventCalls.getCustomList(custom_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceListMulti") {
        if (formData.value != null && formData.value != '') {
          let subData = { ...formData };
          let innerSubData = subData;
          for (var values of formData.value) {
            for (var metaData of formData.additionalMetaData) {
              if (metaData.key === values) {
                innerSubData.value = innerSubData.value.filter(item => item != values);
              }
            }
          }
          innerSubData.value.map(resp => {
            formData["statusData"] = [];
            formData["statusData"].push(resp);
            let termsReferenceListId = subData.additionalMetaData.termsReferenceListId;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": resp,
            };
            eventCalls.getCustomList(term_data).subscribe(respData => {
              if(respData.status == 'success')
              Object.keys(respData.data).map(key => {
                subData.additionalMetaData.push({ key, value: respData.data[key] + " (Deactivated)" });
              });
            })
          })
        }
      } else if (formData.fieldType == "termsReferenceList") {
        if (formData.value != null && formData.value != '') {
          let subData = formData;
          let disabledValueShow: boolean = false;
          for (var metaData of formData.additionalMetaData) {
            if (metaData.key === formData.value) {
              disabledValueShow = true;
              break;
            }
          }
          if (disabledValueShow === false) {
            subData["statusData"] = formData.value;
            let term_data = {
              "tableName": "Terms",
              "keyValue": "dataId, term",
              "dataId": subData.value,
            };
            eventCalls.getCustomList(term_data).subscribe(resp => {
              if(resp.status == 'success')
              Object.keys(resp.data).map(key => {
                subData.additionalMetaData.push({ key, value: resp.data[key] + "(Deactivated)" });
              });
            })
          }
        }
      }
    });
    let countryField = form.formItems.get('country');
    let countryValue;
    countryField.valueChanges.subscribe(resp => {
      countryValue = resp;
      let customListData = form.rawData.filter(items => items.fieldType == 'customList');
      if (customListData.length) {
        customListData.map(customListDataResp => {
          let customListApiData;
          if (customListDataResp.fieldColumn == 'workLocation') {
            customListApiData = { "tableName": "WorkLocation", "keyValue": "dataId, locationName", "filterString": "country = " + countryValue }
          }
          if (customListApiData) {
            customListDataResp.additionalMetaData = [];
            eventCalls.getCustomList(customListApiData).subscribe(resp => {
              if(resp.status == 'success')
              if (resp.status == 'success') {
                Object.keys(resp.data).map(key => {
                  customListDataResp.additionalMetaData.push({ key, value: resp.data[key] });
                });
              }
            });
          }
        });
      }
    });

    return form;
  }
  projectDetailsEditSubmit(form) {
    // form.formItems.get('countryName').setValidators(null);
    // form.formItems.get('countryName').updateValueAndValidity();
    form.formItems.get('countryName').reset({ value: '', disabled: true });
    Object.keys(form.formItems.controls).map(fieldArrData => {
      let fieldKey = fieldArrData;
      let fieldData = form.formItems.controls[fieldKey];
      for (var question of form.rawData) {
        if (question.statusData) {
          if (question.fieldType == "customList") {
            if (form.formItems.controls[question.fieldColumn].value == question.statusData) {
              form["status"] = "DeActivated";
            }

          }
          if (question.fieldType == "customListMultiSelect") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
          if (question.fieldType == "termsReferenceListMulti") {
            form.formItems.controls[question.fieldColumn].value.map(resp => {
              question.statusData.map(status => {
                if (status.length && status == resp) {
                  form["status"] = "DeActivated";
                }
              })
            })
          }
        }
      }
    });
    if (form.formItems.valid) {
      form.formItems.value['transactionId'] = JSON.parse(localStorage.getItem("currentUser")).transactionId // To Set transactionId
    }
    return form;
  }
  termEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Terms'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  termEditAfter(form) {
    return form;
  }
  termEditSubmit(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    form.redirectTo = "Term/TermMaster";
    form.redirectData = "";
    return form;
  }


  insuranceEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Insurance'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  insuranceEditAfter(form) {
    return form;
  }
  insuranceEditSubmit(form) {
    form.redirectTo = "insurance-list/InsuranceMaster";
    form.redirectData = "";
    return form;
  }
  currencyEditBefore(form) {
    form.breadcrumbs = ['Home', 'Master', 'Currency'];
    form.subTitle = '';
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  currencyEditAfter(form) {
    return form;
  }
  currencyEditSubmit(form) {
    form.redirectTo = "currency-list/CurrencyMaster";
    form.redirectData = "";
    return form;
  }
  documentEditBefore(form) {
    form.buttonData = "Submit";
    form.cancelButton = "Cancel";
    return form;
  }
  documentEditAfter(form) {
    return form;
  }
  documentEditSubmit(form) {
    const eventCalls = this.globalFormService;
    Object.keys(form.formItems.value).map(key => {
      form.formItems.get(key).setValidators(null);
      form.formItems.get(key).updateValueAndValidity();

    })
    form.formItems.value = eventCalls.files;
    return form;
  }


  ///////////////////////////////////////////////////////////////////////////////////////////////////

  ////////////////////////////////////// FormList Function //////////////////////////////////////////
  visaListBefore(form) {
    form.breadcrumbs = ['Home', 'Master'];
    form.subTitle = '';
    return form;
  }

  visaListAfter(form) {
    const eventCalls = this.globalFormService;
    form.resp = form.rawData;
    this.apiFun(form);
    return form;
  }
  hostLocListBefore(form) {
    form.breadcrumbs = ['Home', 'Master'];
    form.subTitle = '';
    return form;
  }

  hostLocListAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  docMasterListBefore(form) {
    form.breadcrumbs = ['Home', 'Master'];
    form.subTitle = '';
    return form;
  }

  docMasterListAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }

  rateCardListBefore(form) {
    form.breadcrumbs = ['Home', 'Master'];
    form.subTitle = '';
    return form;
  }

  rateCardListAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
               }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  RequirementListBefore(form) {
    const eventCalls = this.globalFormService;
 
    let headerData = [
      'country',
      'noOfResource'
    ];
    let footerData = [
      'createdDTStamp',
      'workLocation'
    ];
    form.headerData = headerData;
    form.footerData = footerData;


    //////////////////// Filter Fields Starting /////////////////////
    form['filterFields'] = [];
    let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
    eventCalls.getCustomList(data).subscribe(resp => {
      if (resp.status == 'success') {
        let hostLocation = {
          'fieldColumn': 'hostLocation',
          'fieldCaption': 'Host Location',
          'fieldType': 'customList',
          'fieldOrder': 1,
        };
        hostLocation['additionalMetaData'] = [];
        Object.keys(resp.data).map(key => {
          hostLocation['additionalMetaData'].push({ key, value: resp.data[key] });
        });
        form['filterFields'].push(hostLocation);
      }
    });
    let sortingData = [
      { 'key': 1, 'value': 'Work Locaiton Ascending' },
      { 'key': 2, 'value': 'Work Locaiton Descending' },
      { 'key': 3, 'value': 'No. Of Resource Ascending' },
      { 'key': 4, 'value': 'No. Of Resource Descending' }
    ];
    let sortBy = {
      'additionalMetaData': sortingData,
      'fieldColumn': 'sortBy',
      'fieldCaption': 'Sort By',
      'fieldType': 'customList',
      'fieldOrder': 2,
    };
    form['filterFields'].push(sortBy);
    //////////////////// End Of Filter Fields /////////////////////


    form['searchData'] = [
      'noOfResource',
      'workLocation',
    ];
    console.log(form);
    this.apiFun(form);
    return form;
  }

  RequirementListAfter(form) {
    return form;
  }
  RequirementListSubmit(form) {
    const eventCalls = this.globalFormService;
    if (form.formItems.controls['hostLocation'].value != '' && form.formItems.controls['hostLocation'].value != null) {
      if (form.formItems.controls['sortBy'].value != '' && form.formItems.controls['sortBy'].value != null) {
        if (form.formItems.controls['sortBy'].value == 3) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY noOfResource ASC" };
        } else if (form.formItems.controls['sortBy'].value == 4) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY noOfResource DESC" };
        } else if (form.formItems.controls['sortBy'].value == 1) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY workLocation ASC" };
        } else if (form.formItems.controls['sortBy'].value == 2) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY workLocation DESC" };
        }
      } else {
        form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value } };
      }
    } else {
      if (form.formItems.controls['sortBy'].value != '' && form.formItems.controls['sortBy'].value != null) {
        if (form.formItems.controls['sortBy'].value == 3) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY noOfResource ASC" };
        } else if (form.formItems.controls['sortBy'].value == 4) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY noOfResource DESC" };
        } else if (form.formItems.controls['sortBy'].value == 1) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY workLocation ASC" };
        } else if (form.formItems.controls['sortBy'].value == 2) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY workLocation DESC" };
        }
      }
    }
    form['apiData'] = form.apiData;
    return form;
  }
  EnquiryListBefore(form) {
    let headerData = [
      'hostCountry',
      'contactPerson'
    ];
    let footerData = [
      'createdDTStamp',
      'contactEmailId'
    ];
    form['searchData'] = [
      'hostCountry',
      'contactPerson',
      'contactEmailId'
    ]
    form.headerData = headerData;
    form.footerData = footerData;
    form.breadcrumbs = ['Master'];
    form.subTitle = '';
    this.apiFun(form);
    return form;
  }

  EnquiryListAfter(form) {
    return form;
  }
  ContractListBefore(form) {
    const eventCalls = this.globalFormService;
    let headerData = [
      'workLocation',
      'noOfResource'
    ];
    let footerData = [
      'createdDTStamp',
      'contractNo',
      // 'startDate'     
    ];
    form.headerData = headerData;
    form.footerData = footerData;


    //////////////////// Filter Fields Starting /////////////////////
    form['filterFields'] = [];
    let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
    eventCalls.getCustomList(data).subscribe(resp => {
      if (resp.status == 'success') {
        let hostLocation = {
          'fieldColumn': 'hostLocation',
          'fieldCaption': 'Host Location',
          'fieldType': 'customList',
          'fieldOrder': 1,
        };
        hostLocation['additionalMetaData'] = [];
        Object.keys(resp.data).map(key => {
          hostLocation['additionalMetaData'].push({ key, value: resp.data[key] });
        });
        form['filterFields'].push(hostLocation);
      }
    });
    let sortingData = [
      { 'key': 1, 'value': 'Work Locaiton Ascending' },
      { 'key': 2, 'value': 'Work Locaiton Descending' },
      { 'key': 3, 'value': 'No. Of Resource Ascending' },
      { 'key': 4, 'value': 'No. Of Resource Descending' }
    ];
    let sortBy = {
      'additionalMetaData': sortingData,
      'fieldColumn': 'sortBy',
      'fieldCaption': 'Sort By',
      'fieldType': 'customList',
      'fieldOrder': 2,
    };
    form['filterFields'].push(sortBy);
    //////////////////// End Of Filter Fields /////////////////////

    form['searchData'] = [
      'noOfResource',
      'workLocation',
    ]
    this.apiFun(form);
    return form;
  }
  ContractListAfter(form) {
    return form;
  }
  ContractListSubmit(form) {
    const eventCalls = this.globalFormService;
    if (form.formItems.controls['hostLocation'].value != '' && form.formItems.controls['hostLocation'].value != null) {
      if (form.formItems.controls['sortBy'].value != '' && form.formItems.controls['sortBy'].value != null) {
        if (form.formItems.controls['sortBy'].value == 3) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY noOfResource ASC" };
        } else if (form.formItems.controls['sortBy'].value == 4) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY noOfResource DESC" };
        } else if (form.formItems.controls['sortBy'].value == 1) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY workLocation ASC" };
        } else if (form.formItems.controls['sortBy'].value == 2) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY workLocation DESC" };
        }
      } else {
        form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value } };
      }
    } else {
      if (form.formItems.controls['sortBy'].value != '' && form.formItems.controls['sortBy'].value != null) {
        if (form.formItems.controls['sortBy'].value == 3) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY noOfResource ASC" };
        } else if (form.formItems.controls['sortBy'].value == 4) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY noOfResource DESC" };
        } else if (form.formItems.controls['sortBy'].value == 1) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY workLocation ASC" };
        } else if (form.formItems.controls['sortBy'].value == 2) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY workLocation DESC" };
        }
      }
    }
    form['apiData'] = form.apiData;
    return form;
  }
  QuotationListBefore(form) {
    const eventCalls = this.globalFormService;
    let headerData = [
      'companyName',
      'country',
      'noOfResource',
    ];
    let footerData = [
      'quoteNo',
      // 'createdDTStamp',
      'totalAmount'
      // 'workLocation'     
    ];
    form.headerData = headerData;
    form.footerData = footerData;


    //////////////////// Filter Fields Starting /////////////////////
    form['filterFields'] = [];
    let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
    eventCalls.getCustomList(data).subscribe(resp => {
      if (resp.status == 'success') {
        let hostLocation = {
          'fieldColumn': 'hostLocation',
          'fieldCaption': 'Host Location',
          'fieldType': 'customList',
          'fieldOrder': 1,
        };
        hostLocation['additionalMetaData'] = [];
        Object.keys(resp.data).map(key => {
          hostLocation['additionalMetaData'].push({ key, value: resp.data[key] });
        });
        form['filterFields'].push(hostLocation);
      }
    });
    let sortingData = [
      { 'key': 1, 'value': 'Work Locaiton Ascending' },
      { 'key': 2, 'value': 'Work Locaiton Descending' },
      { 'key': 3, 'value': 'No. Of Resource Ascending' },
      { 'key': 4, 'value': 'No. Of Resource Descending' }
    ];
    let sortBy = {
      'additionalMetaData': sortingData,
      'fieldColumn': 'sortBy',
      'fieldCaption': 'Sort By',
      'fieldType': 'customList',
      'fieldOrder': 2,
    };
    form['filterFields'].push(sortBy);
    //////////////////// End Of Filter Fields /////////////////////

    form['searchData'] = [
      'cp.companyName',
      'r.noOfResource',
      'q.quoteNo'
    ]
    this.apiFun(form);
    return form;
  }
  QuotationListAfter(form) {
    return form;
  }
  QuotationListSubmit(form) {
    const eventCalls = this.globalFormService;
    if (form.formItems.controls['hostLocation'].value != '' && form.formItems.controls['hostLocation'].value != null) {
      if (form.formItems.controls['sortBy'].value != '' && form.formItems.controls['sortBy'].value != null) {
        if (form.formItems.controls['sortBy'].value == 3) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY noOfResource ASC" };
        } else if (form.formItems.controls['sortBy'].value == 4) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY noOfResource DESC" };
        } else if (form.formItems.controls['sortBy'].value == 1) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY workLocation ASC" };
        } else if (form.formItems.controls['sortBy'].value == 2) {
          form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value }, sortBy: "ORDER BY workLocation DESC" };
        }
      } else {
        form.apiData = { "formId": form.formId, "filterString": { country: form.formItems.controls['hostLocation'].value } };
      }
    } else {
      if (form.formItems.controls['sortBy'].value != '' && form.formItems.controls['sortBy'].value != null) {
        if (form.formItems.controls['sortBy'].value == 3) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY noOfResource ASC" };
        } else if (form.formItems.controls['sortBy'].value == 4) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY noOfResource DESC" };
        } else if (form.formItems.controls['sortBy'].value == 1) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY workLocation ASC" };
        } else if (form.formItems.controls['sortBy'].value == 2) {
          form.apiData = { "formId": form.formId, "filterString": {}, sortBy: "ORDER BY workLocation DESC" };
        }
      }
    }
    form['apiData'] = form.apiData;
    return form;
  }
  termListBefore(form) {
    form.breadcrumbs = ['Home', 'Master'];
    form.subTitle = '';
    return form;
  }
  termListAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  insuranceListBefore(form) {
    form.breadcrumbs = ['Home', 'Master'];
    form.subTitle = '';
    return form;
  }
  insuranceListAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  currencyListBefore(form) {
    form.breadcrumbs = ['Home', 'Master'];
    form.subTitle = '';
    return form;
  }
  currencyListAfter(form) {
    const eventCalls = this.globalFormService;
    form.rawData.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              resp[splitData]['refValue'] = resp[splitData].value; 
              splitValue = resp[splitData].value.split(",");
              eventCalls.getTerms(term_data).subscribe(res_data => {
                if(res_data.status == 'success')
                for (var j = 0; j < splitValue.length; j++) {
                  for (var keys in res_data.data) {
                    if (splitValue[j] === keys) {
                      splitValue[j] = res_data.data[keys];
                    }
                  }
                }
                let respSplitData = [];
                splitValue.map((splitResp, index) => {
                  let crtLength = splitValue.length;
                  if (Number(splitResp) > 0) {
                    resp[splitData]["deactivated"] = 1;
                    let term_data = {
                      "tableName": "Terms",
                      "keyValue": "dataId, term",
                      "dataId": splitResp,
                    };
                    eventCalls.getCustomList(term_data).subscribe(respData => {
                      if(respData.status == 'success')
                      for (var keys in respData.data) {
                        if (splitResp === keys) {
                          splitValue.splice(splitValue.indexOf(keys), 1);
                          splitResp = respData.data[keys];
                          respSplitData.push(splitResp);
                        }
                      }
                      resp[splitData].value = splitValue.concat(respSplitData);
                    })
                  } else {
                    resp[splitData].value = splitValue;
                  }
                });
                resp[splitData].value = splitValue;
              });
            }
          }
          if (resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null)
              splitValue = resp[splitData].value.split(",");
            let custom_data;
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            eventCalls.getCustomList(custom_data).subscribe(res_data => {
              if(res_data.status == 'success')
              for (var j = 0; j < splitValue.length; j++) {
                for (var keys in res_data.data) {
                  if (splitValue[j] === (keys)) {
                    splitValue[j] = res_data.data[keys];
                  }
                }
              }
              let respSplitData = [];
              splitValue.map((splitResp, index) => {
                let crtLength = splitValue.length;
                if (Number(splitResp) > 0) {
                  resp[splitData]["deactivated"] = 1;
                  custom_data["dataId"] = splitResp;
                  eventCalls.getCustomList(custom_data).subscribe(respData => {
                    if(respData.status == 'success')
                    for (var keys in respData.data) {
                      if (splitResp === keys) {
                        splitValue.splice(splitValue.indexOf(keys), 1);
                        splitResp = respData.data[keys];
                        respSplitData.push(splitResp);
                      }
                    }
                    resp[splitData].value = splitValue.concat(respSplitData);
                  })
                } else {
                  resp[splitData].value = splitValue;
                }
              });
              resp[splitData].value = splitValue;
            });
          }
        }
      })
    })
    return form;
  }
  personalDetailsViewBefore(form) {
    this.apiFun(form);
    return form;
  }
  viewContractBefore(form) {
    Object.keys(form.resp[0]).map(key =>{
      if(key == 'emergencyContact'){
        form.resp[0][key].value = JSON.parse(form.resp[0][key].value)
        // console.log(form.emergencyContact.value);
      }
      if(key == 'mobileNo'){
        form.resp[0][key].value = JSON.parse(form.resp[0][key].value)
        // console.log(form.mobileNo.value);
      }
    })
    form.breadcrumbs = '';
    form.subTitle = form.cntNumber;
    const eventCalls = this.globalFormService;
    this.apiFun(form);
    return form;
  }
  resourceViewBefore(form) {
    this.apiFun(form);
    let hostCountry;
    let visaType;
    let addonsList;
    let addonsServiceList = [];
    const eventCalls = this.globalFormService;
    form.resValidationMsg = `<div style='padding:10px;background:#fff3e4;'>Please provide the resource details. Use the 'Add Resource' button to add resources.</div>`
    console.log(form);
    // Object.keys(form.additionalDetails[0]).map(key =>{
    //   if(key == 'country') {
    //     hostCountry = form.additionalDetails[0][key].value;
    //   }
    // })
    // Object.keys(form.resp[0]).map(key =>{
    //   if(key == 'visaType') {
    //     visaType = form.resp[0][key].refValue;
    //   }
    //   if(key == 'addons') {
    //     addonsList = form.resp[0][key]
    //   }
    // })
    // console.log(hostCountry,visaType);
    // let addonsApiData = { "hostLocation": hostCountry, "visaType": visaType };
    // eventCalls.getAddons(addonsApiData).subscribe(resp => {
    //   console.log(resp);
    //   if(resp.status == 'success') {
    //     if (resp.data.length) {
    //       resp.data.map(respData => {
    //         addonsList.map(addonsListMap => {
    //           if (respData.fieldColumn == addonsListMap.addonId) {
    //             addonsServiceList.push(respData);
    //           }
    //         });

    //       });
    //       // console.log(addonsServiceList,resp)
    //       addonsServiceList.map((respList, index) => {
    //         let addonsJSONList;
    //         respList.values.map(respListLDataValue => {
    //           Object.keys(addonsList).map(respData => {
    //             if (respListLDataValue.addonDataId == addonsList[respData].addonDataId && respListLDataValue.addonId == addonsList[respData].addonId) {
    //               addonsJSONList = respListLDataValue;
    //             }
    //           })
    //           addonsServiceList[index].values = [];
    //           addonsServiceList[index].values.push(addonsJSONList);
    //         })
    //       })
    //     }
    //   }
    //   console.log(addonsServiceList);
    //   Object.keys(form.resp[0]).map(key =>{
    //     if(key == 'addons') {
    //       form.resp[0][key] = addonsServiceList
    //     }
    //   })
    //   console.log(form);
    // })
    return form;
  }

  /////////////// Api Function ////////////////
  apiFun(form) {
    console.log(form);
    let hostLocation;

    if(form.additionalDetails){
      form.additionalDetails.map(resp => {
        if (resp.fieldKey == "country") {
          hostLocation = resp.values.value;
        }
      });
    }

    if(form.resp)
    form.resp.map(resp => {
      Object.keys(resp).map(splitData => {
        if (typeof resp[splitData] == "object" && resp[splitData] != null) {
          resp[splitData]["deactivated"] = 0;
          if (resp[splitData].fieldType == "termsReferenceList" || resp[splitData].fieldType == "termsReferenceListMulti") {
            let termsReferenceListId = resp[splitData].additionalMetaData.termsReferenceListId;
            var term_data = { "termSetId": termsReferenceListId };
            let splitValue: any = [];
            if (resp[splitData].value != null) {
              resp[splitData]['refValue'] = resp[splitData].value;
              splitValue = resp[splitData].value.toString().split(",");
              this.termCalls(term_data, splitValue, resp[splitData]);
            }
          }

          if (splitData == "country") {
            form.hostLocationValue = resp[splitData].value;
            hostLocation = resp[splitData].value;
          }

          if (splitData == "visaType") {
            form.visaTypeValue = resp[splitData].value;
          }

          if (resp[splitData].fieldType === "customListAdditionalDetail" || resp[splitData].fieldType === "customList" || resp[splitData].fieldType === "customListMultiSelect" || resp[splitData].fieldType === "customMultiSelectOptions") {
            let splitValue: any = [];
            if (resp[splitData].value != null){
              resp[splitData]['refValue'] = resp[splitData].value;
              splitValue = resp[splitData].value.toString().split(",");
            }
            let custom_data = {};
            if (splitData == "documentChecklist") {
              custom_data = { "tableName": "DocumentMaster", "keyValue": "dataId, documentName" };
            } else if (splitData == "planNameIfAny") {
              custom_data = { "tableName": "Insurance", "keyValue": "dataId, planName" }
            } else if (splitData == "country") {
              custom_data = { "tableName": "Location", "keyValue": "dataId, countryName" };
            }
            else if (splitData == "visaTypeIfAny" || splitData == "visaType") {
              custom_data = { "tableName": "visatype", "keyValue": "dataId, visaName" }
            }
            else if (splitData == "userId") {
              custom_data = { "tableName": "ClientProfile", "keyValue": "dataId, companyName" }
            }
            else if (splitData == "visaPartner") {
              custom_data = { "tableName": "VisaPartner", "keyValue": "dataId, name", "filterString": "country="+hostLocation };
            }
            else if (splitData == "workLocation") {
              custom_data = { "tableName": "WorkLocation", "keyValue": "dataId, locationName" }
            }
            this.customCalls(custom_data, splitValue, resp[splitData]);
          }
        }
      })
    })
  }
  ////////////////// Terms Call Function //////////////////
  termCalls(term_data, value, resp) {
    const eventCalls = this.globalFormService;
    eventCalls.getTerms(term_data).subscribe(res_data => {
      if(res_data.status == 'success')
      for (var j = 0; j < value.length; j++) {
        for (var keys in res_data.data) {
          if (value[j] === keys) {
            value[j] = res_data.data[keys];
          }
        }
      }
      let respSplitData = [];
      value.map((splitResp, index) => {
        let crtLength = value.length;
        if (Number(splitResp) > 0) {
          resp["deactivated"] = 1;
          let term_data = {
            "tableName": "Terms",
            "keyValue": "dataId, term",
            "dataId": splitResp,
          };
          eventCalls.getCustomList(term_data).subscribe(respData => {
            if(respData.status == 'success')
            for (var keys in respData.data) {
              if (splitResp === keys) {
                value.splice(value.indexOf(keys), 1);
                splitResp = respData.data[keys];
                respSplitData.push(splitResp);
              }
            }
            resp.value = value.concat(respSplitData);
          })
        } else {
          resp.value = value;
        }
      });
      resp.value = value;
    });
  }

  ///////////////// Custom Call Function //////////////////
  customCalls(custom_data, value, resp) {
    const eventCalls = this.globalFormService;
    eventCalls.getCustomList(custom_data).subscribe(res_data => {
      if(res_data.status == 'success')
      for (var j = 0; j < value.length; j++) {
        for (var keys in res_data.data) {
          if (value[j] === (keys)) {
            value[j] = res_data.data[keys];
          }
        }
      }
      let respSplitData = [];
      value.map((splitResp, index) => {
        let crtLength = value.length;
        if (splitResp != null && splitResp != undefined)
          if (Number(splitResp) > 0) {
            resp["deactivated"] = 1;
            custom_data["dataId"] = splitResp;
            eventCalls.getCustomList(custom_data).subscribe(respData => {
              if(respData.status == 'success')
              for (var keys in respData.data) {
                if (splitResp === keys) {
                  value.splice(value.indexOf(keys), 1);
                  splitResp = respData.data[keys];
                  respSplitData.push(splitResp);
                }
              }
              resp.value = value.concat(respSplitData);
            })
          } else {
            resp.value = value;
          }
      });
      resp.value = value;
    });
  }
}



