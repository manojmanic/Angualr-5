import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalformService } from '../../shared/services/globalform.service';
import { MatSnackBar } from '@angular/material';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';

@Component({
  selector: 'app-passwordcreation',
  templateUrl: './passwordcreation.component.html',
  styleUrls: ['./passwordcreation.component.scss']
})
export class PasswordcreationComponent implements OnInit {
  
  formBuildBaseObj: any;
  form_title:any;
  breadcrumbs:any;
  subTitle:any;
  buttonData: any;
  innerTemplate: any;

  constructor(
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private router: Router,
    private activated: ActivatedRoute,
    private service: GlobalformService,
    public snackBar: MatSnackBar,
    private authGuardService: AuthGuardService,
  ) {
    this.formBuildBaseObj = this.screenTB.formAdd('password');
    
    
    this.form_title = this.formBuildBaseObj.title;
    let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId};
        let changed = eventCalls[preBuildEvFn](param);
        this.breadcrumbs = changed.breadcrumbs;
        this.subTitle = changed.subTitle;
        this.buttonData = changed.buttonData;
        this.innerTemplate = changed.innerTemplate;
      }
    }
  }
  //form_title = 'Registration Completed';
  loginId = atob(this.activated.snapshot.queryParams.key);
  ngOnInit() {
    let logData = JSON.parse(localStorage.getItem('currentUser'));
    
    if (logData != null && logData.hasOwnProperty('id')) {

      this.authGuardService
        .logout({ ClientID: logData.tokenId })
        .subscribe(resp => {
          if (resp.status == 'success') {
            localStorage.removeItem('currentUser');
            this.authGuardService.changeState = false;
            this.authGuardService.changeState = { isLogin: false, currentUser: '' };
            
          }
          this.openSnackBar({ message: resp.message, status: resp.status });
        })

    }
    this.userForm = new FormGroup({
      password: new FormControl('', [Validators.required]),
      reEnterpassword: new FormControl('', [Validators.required]),
    });

  }
  userForm: any;
  onSubmit() {
    if(this.userForm.valid) {
    let passData = {
      emailId: atob(this.activated.snapshot.queryParams.key),
      password: this.userForm.get("reEnterpassword").value
    }
    this.service.passwordSettings(passData).subscribe(resp => {
     
      this.openSnackBar({ message: JSON.stringify(resp.message), status: JSON.stringify(resp.status) });
      if (resp.status === "Success") {
        this.router.navigate(['/signin']);
      }
    })
  }
  }
  openSnackBar(snackData) {
    let message = snackData.message;
    let action = '';
    let classess;

    if (snackData.status == 'success') {
      classess = 'success';
    } else if (snackData.status == 'error') {
      classess = 'error';
    } else {
      classess = 'warn';
    }

    this.snackBar.open(message, action, {
      duration: 2000,
      extraClasses: [classess]
    });
  }
}
