import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-workflow',
  templateUrl: './workflow.component.html',
  styleUrls: ['./workflow.component.scss']
})
export class WorkflowComponent implements OnInit {
  alertMsg= false;
  @Input() workFlowData: any;
  @Input() todoTitle: any;
  @Input() referrence: any;
  remarks: any = ''; 

  constructor() { }

  ngOnInit() {
  }

  @Output() navigation = new EventEmitter<boolean>();
  navigateFunc(tabLink) {
    let navigationData: any = {
      'tabLink': tabLink,
      'referrence': this.referrence
    };
    this.navigation.emit(navigationData);
  }

  ngOnChanges() {
    // if (this.workFlowData !== undefined) {
    //   if (this.workFlowData.length) {
    //     this.workFlowData.map(resp => {
          
    //       this.workFlowData = resp;
    //     })
    //   }
    // }
  }


}
