import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WorkflowComponent } from './workflow/workflow.component';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatToolbarModule,
  MatCardModule,
  MatTabsModule,
  MatInputModule,
  MatIconModule,
  MatGridListModule,
  MatSidenavModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatFormFieldModule,
  MatSelectModule,
  MatRadioModule,
  MatAutocompleteModule,
  MatTooltipModule,
  MatSnackBarModule,
  MatDialogModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatChipsModule,
  MatExpansionModule,
  MatStepperModule,
  MatSliderModule,
  MatSlideToggleModule
} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    MatButtonModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatCardModule,
    MatTabsModule,
    MatInputModule,
    MatIconModule,
    MatGridListModule,
    MatSidenavModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatDialogModule,
    MatNativeDateModule,
    MatDatepickerModule,
    MatChipsModule,
    MatExpansionModule,
    MatStepperModule,
    MatSliderModule,
    MatSlideToggleModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [
    WorkflowComponent
  ],
  exports: [
    WorkflowComponent
  ]
})
export class TodoModule { }
