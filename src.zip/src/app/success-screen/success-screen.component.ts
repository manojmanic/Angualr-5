import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';

@Component({
  selector: 'app-success-screen',
  templateUrl: './success-screen.component.html',
  styleUrls: ['./success-screen.component.scss']
})
export class SuccessScreenComponent implements OnInit {
  public data;
  public enquiryId;
  public contractId;
  quotationNo;
  reqRefNo;
  constructor(private activateRoute: ActivatedRoute,private router:Router) { }
  
  ngOnInit() {
    
    this.data = this.activateRoute.snapshot.queryParamMap.get('data');
    if(this.activateRoute.snapshot.queryParams.enquiryId)
    this.enquiryId = this.activateRoute.snapshot.queryParamMap.get('enquiryId');
    if(this.activateRoute.snapshot.queryParams.contractId)
    this.contractId = this.activateRoute.snapshot.queryParamMap.get('contractId');
    if(this.activateRoute.snapshot.queryParams.quotationNo)
    this.quotationNo = this.activateRoute.snapshot.queryParamMap.get('quotationNo');
    if(this.activateRoute.snapshot.queryParams.reqRefNo)
    this.reqRefNo = this.activateRoute.snapshot.queryParamMap.get('reqRefNo');
  }
  payment() {
    this.router.navigate(['payment']);
  }

}
