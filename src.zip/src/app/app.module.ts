
/////////////////MODULES/////////////////////
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AppRoutingModule } from './shared/routing/app-routing.module';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatStepperModule } from '@angular/material/stepper';
import { Constants } from './constants';
import {AccessControlFunctions} from './shared/common/accessControl'

/////////////////Social Login/////////////////////
import {
  SocialLoginModule,
  AuthServiceConfig,
  GoogleLoginProvider,
  // TwitterLoginProvider,
  FacebookLoginProvider
} from "angular5-social-login";
// Configs 
export function getAuthServiceConfigs() {
  let config = new AuthServiceConfig(
    [
      {
        id: FacebookLoginProvider.PROVIDER_ID,
        provider: new FacebookLoginProvider("324706244634750")
      },
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        // provider: new GoogleLoginProvider("131835384002-v856f75n6ut87ar6agnspbe5l2dqpv8h.apps.googleusercontent.com") // oauth client 
        provider: new GoogleLoginProvider("131835384002-6o0r34muhb98fasevvgvgebpi0cs6gf9.apps.googleusercontent.com") // web oauth client
      },
      // {
      //   id: TwitterLoginProvider.PROVIDER_ID,
      //   provider: new TwitterLoginProvider("131835384002-v856f75n6ut87ar6agnspbe5l2dqpv8h.apps.googleusercontent.com")
      // },
    ]);
  return config;
}
import {
  MatButtonModule,
  MatCheckboxModule,
  MatToolbarModule,
  MatCardModule,
  MatTabsModule,
  MatInputModule,
  MatIconModule,
  MatGridListModule,
  MatSidenavModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatFormFieldModule,
  MatSelectModule,
  MatRadioModule,
  MatAutocompleteModule,
  MatTooltipModule,
  MatSnackBarModule,
  MatDialogModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatChipsModule,
  MatExpansionModule,
  MatSliderModule,
  MatSlideToggleModule
} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { PipeModule } from './shared/pipes/pipe.module'
import { AlertModule } from './alert/alert.module';

////////////COMPONENTS//////////////////////
import { AppComponent } from './app.component';
import { SidemenuComponent } from './shared/sidemenu/sidemenu.component';
import { HeaderComponent } from './shared/header/header.component';
import { FooterComponent } from './shared/footer/footer.component';
import { DialogComponent } from './forms/simpleform/formlist/dialog/dialog.component';
import { FormaddComponent } from './forms/simpleform/formadd/formadd.component';
import { FormdetailComponent } from './forms/simpleform/formdetail/formdetail.component';
import { FormlistComponent } from './forms/simpleform/formlist/formlist.component';
import { FormeditComponent } from './forms/simpleform/formedit/formedit.component';
import { TotallistComponent } from './totallist/totallist.component';
import { RequirementsComponent } from './totallist/requirements/requirements.component';
import { EnquiryComponent } from './totallist/enquiry/enquiry.component';
import { QuotationComponent } from './totallist/quotation/quotation.component';
import { ContractComponent } from './totallist/contract/contract.component';
import { HomeComponent } from './home/home.component';
import { ProjectDetailsComponent } from './forms/hierarchyform/project-details/project-details.component';
import { ResourceDetailsComponent } from './forms/hierarchyform/resource-details/resource-details.component';
import { PreviewComponent } from './forms/hierarchyform/preview/preview.component';
import { DeldialogComponent } from './forms/hierarchyform/resource-details/deldialog/deldialog.component';
import { PaymentComponent } from './payment/payment.component';
import { SubmitRequirementsComponent } from './forms/hierarchyform/submit-requirements/submit-requirements.component';
import { ResourcedialogComponent } from './forms/hierarchyform/resourcedialog/resourcedialog.component';
import { PasswordcreationComponent } from './forms/passwordcreation/passwordcreation.component';
import { AuthComponent } from './auth/auth.component';
import { SuccessScreenComponent } from './success-screen/success-screen.component';
import { ResourcedialogeditComponent } from './forms/hierarchyform/resourcedialogedit/resourcedialogedit.component';
import { ProjectdetailseditComponent } from './forms/hierarchyform/project-details/projectdetailsedit/projectdetailsedit.component';
import { PartnerratedialogComponent } from './forms/simpleform/formdetail/partnerratedialog/partnerratedialog.component';

////////////SERVICES///////////////////////
import { GlobalformService } from './shared/services/globalform.service';
import { GlobalformControlService } from './shared/services/globalform-control.service';
import { GlobalFunctionService } from './shared/services/global-function.service';
import { AuthGuardService } from './shared/guard/auth-guard.service';
import { AlertService } from './shared/services/alert-service.service';

/////////// -- Builder -- ///////////
import { ScreenTemplateJsonBuilder } from './shared/common/screentemplate-jsonbuilder';
import { FormBuildFunctionsService } from './shared/common/form-build-functions.service';
import { FormBuildBaseService } from '../app/forms/formbuilds/form-build-base.service';

////////// Guard ///////////////
import { AuthGuard } from './shared/guard/auth.guard';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { MenulistComponent } from './shared/sidemenu/menulist/menulist.component';
import { RenderModule } from './render/render.module';
import { DownloadService } from './shared/services/download.service';
import * as FusionCharts from 'fusioncharts';
import * as Charts from 'fusioncharts/fusioncharts.charts';
import * as FintTheme from 'fusioncharts/themes/fusioncharts.theme.fint';
import { FusionChartsModule } from 'angular4-fusioncharts';
import { PartnerratedialogeditComponent } from './forms/simpleform/formdetail/partnerratedialogedit/partnerratedialogedit.component';




FusionChartsModule.fcRoot(FusionCharts, Charts, FintTheme);

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SidemenuComponent,
    DialogComponent,
    FormaddComponent,
    FormdetailComponent,
    FormlistComponent,
    FormeditComponent,
    SubmitRequirementsComponent,
    ResourcedialogComponent,
    PasswordcreationComponent,
    AuthComponent,
    SuccessScreenComponent,
    ResourcedialogeditComponent,
    HomeComponent,
    ProjectDetailsComponent,
    ResourceDetailsComponent,
    PreviewComponent,
    DeldialogComponent,
    PaymentComponent,
    TotallistComponent,
    RequirementsComponent,
    EnquiryComponent,
    QuotationComponent,
    ContractComponent,
    ProjectdetailseditComponent,
    MenulistComponent,
    PartnerratedialogComponent,
    PartnerratedialogeditComponent,
    
  ],
  imports: [
    BrowserModule,
    PipeModule,
    AppRoutingModule,
    HttpModule,
    FlexLayoutModule,
    MatButtonModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatCardModule,
    MatTabsModule,
    MatInputModule,
    MatIconModule,
    MatGridListModule,
    MatSidenavModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatDialogModule,
    MatSliderModule,
    MatSlideToggleModule,
    FormsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatExpansionModule,
    SocialLoginModule,
    RenderModule,
    AlertModule,
    PipeModule,
    FusionChartsModule
  ],
  entryComponents: [
    HomeComponent,
    ResourcedialogeditComponent,
    ResourcedialogComponent,
    DialogComponent,
    FormaddComponent,
    SubmitRequirementsComponent,
    PasswordcreationComponent,
    AuthComponent,
    DeldialogComponent,
    PaymentComponent,
    TotallistComponent,
    ProjectdetailseditComponent,
    PartnerratedialogComponent,
    PartnerratedialogeditComponent
  ],

  providers: [
    GlobalformService,
    GlobalformControlService,
    GlobalFunctionService,
    Constants,
    ScreenTemplateJsonBuilder,
    FormBuildFunctionsService,
    AuthGuard,
    AuthGuardService,
    FormBuildBaseService,
    AccessControlFunctions,
    AlertService,
    DownloadService,
    {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    },
    {
      provide: LocationStrategy,
      useClass: HashLocationStrategy
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
