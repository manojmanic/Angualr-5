import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
// import { User } from './user.model';
import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Router } from '@angular/router';
import { Constants } from '../../constants';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';

@Injectable()
export class PermissionService {
    files: any;
    constructor(
        private http: Http,
        private config: Constants,
        private router: Router,
        private authGuardService: AuthGuardService
    ) {
        // this.head['Token'] = this.user.tokenId;
        // this.head['Content-Type'] = 'application/json';
    }

    token: any;
    roleId: any;
    getRoleUsers(apidata, page_number, limit) {
        let data = { ...apidata };
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        data["Limit"] = limit;
        data["PageNumber"] = page_number;
        var api = this.config.API_URL + "/api/get_role_users";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ));
    }
    createRole(role_name) {
        let data = {
            "roleName": role_name,
        };
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        var api = this.config.API_URL + "/api/create_role";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ));
    }

    getRoles() {
        let data = {};
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        var api = this.config.API_URL + "/api/get_roles";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ));
    }

    getRolePermission(data) {
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        var api = this.config.API_URL + "/api/get_role_app_permissions";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ))

    }
    setPermission(data) {
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        var api = this.config.API_URL + "/api/set_permissions";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ))

    }
    setUserRole(data) {
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        var api = this.config.API_URL + "/api/set_users_role";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ))
    }
    uploadFile(data) {
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
          'Token': currentUser.tokenId
        });
        var api = this.config.API_URL + "/api/upload_file";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ))
    }
    createUser(data) {
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        var api = this.config.API_URL + "/api/create_user";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ))
    }

    deleteRole(data) {
        let currentUser = this.authGuardService.getLoginUser();
        let tokenId = this.config.TEMP_TOKEN;
        if (currentUser != null) {
            tokenId = currentUser.tokenId;
        }
        let head = new Headers({
            'Content-Type': 'application/json',
            'Token': tokenId
        });
        var api = this.config.API_URL + "/api/delete_role";
        return this.http.post(api, data, { headers: head })
            .map((res: Response) => (
                res.json()
            ))
    }


}