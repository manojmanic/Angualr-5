import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import { Constants } from '../../constants';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';

@Injectable()
export class ProfileService {


  token: any;
  roleId: any;
  constructor(
    private http: Http,
    private router: Router,
    private config: Constants,
    private authGuardService: AuthGuardService
  ) {
  }



  getProfile(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    var api = this.config.API_URL + "/api/get_profile";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }


  updateProfile(data) {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new Headers({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    var api = this.config.API_URL + "/api/update_profile";
    return this.http.post(api, data, { headers: head })
      .map((res: Response) => (
        res.json()
      ))
  }
}
