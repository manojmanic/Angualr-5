import { Component, OnInit, Input } from '@angular/core';
import {
  ObservableMedia
} from '@angular/flex-layout';
import { MatDialog, MatDialogRef } from '@angular/material';
import { DialogComponent } from '../dialog/dialog.component';
import { PermissionService } from '../service/permission.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { Constants } from '../../constants';
import { GlobalFunctionService } from '../../shared/services/global-function.service';

@Component({
  selector: 'app-permission',
  templateUrl: './permission.component.html',
  styleUrls: ['./permission.component.scss', '../../../assets/css/global.scss']
})
export class PermissionComponent implements OnInit {
  dialogRef: MatDialogRef<DialogComponent>;
  role_name: string;
  roles: any[] = [];
  permissions: any[] = [];
  defaultUser: number;
  role_id: number;
  user_count_zeroId: number;
  user_count_zeroName: any;
  selectedValue: any;
  token: any;
  addUserButton:boolean = false;

  currentUser = this.authGuardService.getLoginUser();
  userList: any[] = [];
  userCount: any;
  selected: any;
  optionsRole: any = [];
  constructor(
    private router: Router,
    private roleservice: PermissionService,
    public gfService: GlobalFunctionService,
    private dialog: MatDialog,
    private authGuardService: AuthGuardService,
    private config: Constants,
    public snackBar: MatSnackBar
  ) {
    this.token = this.currentUser.tokenId;
    this.token = '?Token=' + this.token;
    roleservice.getRoles().subscribe(data => {
     
      for (let i = 0; i < data.Roles.length; i++) {
        
        if (data.Roles[i].userCount === 0) {
          this.user_count_zeroId =data.Roles[i].roleId;
          this.user_count_zeroName = data.Roles[i].roleName;
        }
        this.roles.push(data.Roles[i]);
        /////////// To get Default User//////////////
        if (data.Roles[i].DefaultRole === 1) {
          this.selected = data.Roles[i];
          this.role_name = data.Roles[i].roleName;
          this.role_id = data.Roles[i].DefaultRole;
          let apiData = { "roleId": data.Roles[i].DefaultRole };
          roleservice.getRoleUsers(apiData, 1, this.config.PG_LIMIT_DEFAULT).subscribe(data => {
            this.userList = (data.Users);
            this.userCount = (data.UserCount);
          })
          roleservice.getRolePermission(apiData).subscribe(data => {
            for (var i = 0; i < data.data.length; i++) {
              if (data.data[i].Permission === 1) {
                data.data[i].Permission = true;
              }
              if (data.data[i].Permission === 0) {
                data.data[i].Permission = false;
              }
            }
            this.permissions = data.data;

          })
        }
      }
      this.optionsRole = this.roles.filter(items => items.roleId != null);
    })
  }

  ngOnInit() {

  }
  new_role() {
    let perCoderole=this.gfService.createRole();
    if(perCoderole){
    this.dialogRef = this.dialog.open(DialogComponent);
    this.dialogRef.componentInstance.new_role_form = true;
    this.dialogRef.afterClosed().subscribe(resp => {
      if (resp) {
        this.roles.push(resp);
        this.optionsRole = this.roles.filter(items => items.roleId != null);
      }
    });
  }else{
    this.snackBar.open('Create Role is not accessable for you', '', {
      duration: 2000,
      extraClasses: ['error']
    });
  }
  }
  user(role, roleName: string, roleId: number, userCount: any) {
    this.selected = role;
    this.role_name = (roleName);
    ////// To disable AddUser Button ///////////
    if(roleId == null) {
      this.addUserButton = true;
    }else{
      this.addUserButton = false
    }
    //////// To Get roleName and roleId for Zero Count Roles/////////
    if (userCount === 0) {
      this.user_count_zeroId = roleId;
      this.user_count_zeroName = roleName;
    }
    for (var i = 0; i < this.roles.length; i++) {
      ///////To Change color from defaultUser///////////
      if (this.roles[i].roleName === 'user') {
        this.roles[i].roleName = 'user';
      }

    }
    this.role_id = roleId;
    let apiData;

    if (roleId != null) {
      apiData = { "roleId": roleId };
    } else {
      this.permissions = [];
      apiData = {};
    }
    this.optionsRole = this.roles.filter(items => items.roleId != null);
    ///////////To Get Role Users///////////////////
    this.roleservice.getRoleUsers(apiData, 1, this.config.PG_LIMIT_DEFAULT).subscribe(data => {
      this.userList = (data.Users);
      this.userCount = (data.UserCount);
    })
    ///////////To Get Role Permission//////////////
    if(roleId != null) {
    this.roleservice.getRolePermission(apiData).subscribe(data => {
      for (var i = 0; i < data.data.length; i++) {
        if (data.data[i].Permission === 1) {
          data.data[i].Permission = true;
        }
        if (data.data[i].Permission === 0) {
          data.data[i].Permission = false;
        }
      }
      this.permissions = data.data;
    })
  }

  }
  Onselect(event, data) {

    let el = event;
    let selectedOption = JSON.parse((el.source.selected._element.nativeElement).getAttribute('data-role'));
    this.dialogRef = this.dialog.open(DialogComponent);
    this.dialogRef.componentInstance.roleName = selectedOption.roleName;
    this.dialogRef.componentInstance.userName = data.FirstName;
    this.dialogRef.componentInstance.roleId = el.value;
    this.dialogRef.componentInstance.userId = data.UserID;
    this.dialogRef.afterClosed().subscribe(resp => {
      if (resp) {
        for (var role of this.roles) {
          if (role.roleId == data.crntRoleId) {
            role.userCount = role.userCount - 1;
            this.selected = role;
            this.user(role, role.roleName, role.roleId, role.userCount);
          }
          if (role.roleId == selectedOption.roleId) {
            role.userCount = role.userCount + 1;

          }
        }
        selectedOption.userCount = selectedOption.userCount + 1;
      }
      if (!resp)
        el.source.value = data.crntRoleId;
    });

  }
  addUser(roleId: number) {
    let perCodeuser=this.gfService.DeactivatePermissioncode();
    if(perCodeuser){
    this.roleservice.roleId = roleId;
    this.router.navigate(['/users/profile-add',roleId]);
    }
    else{
      this.snackBar.open('Create User is not accessable for you', '', {
        duration: 2000,
        extraClasses: ['error']
      });
    }
  }
  DeactvatePermission(){
    let permission = this.gfService.PermissionDeactivate();
    return permission;
  }
  slide(status: any, id: any, permission_code: any) {
   
    var permission_status;
    if (status.value === false) {
      permission_status = true;

    }
    if (status.value === true) {
      permission_status = false;
    }
    var arr = [];
    var permission_build = { permissionCode: permission_code, Permission: permission_status };
    arr.push(permission_build);
    var data = { permissions: [permission_build] };
    data["roleId"] = id;
    this.roleservice.setPermission(data).subscribe(data => {
      if (permission_status === true) {
        this.snackBar.open('Permission Granted', 'CLOSE', {
          duration: 2000,

        });
      }
      else {
        this.snackBar.open('Permission Revoked', 'CLOSE', {
          duration: 2000
        });
      }
    })
  
  
  }
  deleteRole() {
    let perCodeDelete=this.gfService.DeactivatePermissioncode();
    if(perCodeDelete){
    this.dialogRef = this.dialog.open(DialogComponent);
    this.dialogRef.componentInstance.user_count_zeroId = this.user_count_zeroId;
    this.dialogRef.componentInstance.user_count_zeroName = this.user_count_zeroName;
    this.dialogRef.afterClosed().subscribe(resp => {
      if (resp) {
        this.roles = this.roles.filter(items =>
          items.roleId !== this.user_count_zeroId
        )
        // console.log(this.roles)
        for (var role of this.roles) {
          if (role.DefaultRole == 1) {
            this.user(role, role.roleName, role.roleId, role.userCount);
          }
        }
      }
    });
  }else{
    this.snackBar.open('Delete Role Permissions not accessable for you', '', {
      duration: 2000,
      extraClasses: ['error']
    });
  }
  }
  isActive(item) {
    return this.selected === item;
  };


  user_profile(name: string, UserID: number) {
    if (UserID)
      this.router.navigate(['profile/', UserID]);
    return false;
  }

  openSnackBar(resp) {
      var message = resp.message;
      var action = '';
    if (resp.status == 'success') {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['success']
      });
    }
    else {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['error']
      });
    }
  }

  paginationFunction(pageEvent) {
    console.log(pageEvent);
     ///////////To Get Role Users///////////////////
     var data = { "roleId": this.role_id };
     this.roleservice.getRoleUsers(data, pageEvent.pageIndex+1, pageEvent.pageSize).subscribe(data => {
       this.userList = (data.Users);
       this.userCount = (data.UserCount);
       console.log(data);
     })
  }

}
