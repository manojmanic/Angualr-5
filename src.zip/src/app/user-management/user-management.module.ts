import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserManagementComponent } from './user-management.component';
import { UserManagementRoutingModule } from './user-management-routing.module';
import { ProfileComponent } from './profile/profile.component';
import { ProfileService } from './service/profile.service';
import { AuthGuardService } from '../shared/guard/auth-guard.service';
import { PermissionComponent } from './permission/permission.component';
import { DialogComponent } from './dialog/dialog.component';
import { PermissionService } from './service/permission.service';
import {AlertModule} from '../alert/alert.module';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatToolbarModule,
  MatCardModule,
  MatTabsModule,
  MatInputModule,
  MatIconModule,
  MatGridListModule,
  MatSidenavModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatFormFieldModule,
  MatSelectModule,
  MatRadioModule,
  MatAutocompleteModule,
  MatTooltipModule,
  MatSnackBarModule,
  MatDialogModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatChipsModule,
  MatExpansionModule,
  MatStepperModule,
  MatSliderModule,
  MatSlideToggleModule
} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddUserComponent } from './profile/add/addUser.component';
import { ProfileEditComponent } from './profile/profile-edit/profile-edit.component';
import { PipeModule } from '../shared/pipes/pipe.module';
import { RenderModule } from '../render/render.module';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatCardModule,
    MatTabsModule,
    MatInputModule,
    MatIconModule,
    MatGridListModule,
    MatSidenavModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatDialogModule,
    MatStepperModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatExpansionModule,
    MatSliderModule,
    MatSlideToggleModule,
    FormsModule,
    ReactiveFormsModule,
    UserManagementRoutingModule,
    AlertModule,
    PipeModule,
    RenderModule
  ],
  declarations: [
    UserManagementComponent,
    ProfileComponent,
    PermissionComponent,
    AddUserComponent,
    ProfileEditComponent,
    DialogComponent,
  ],
  entryComponents: [DialogComponent],
  providers: [
    AuthGuardService,
    ProfileService,
    PermissionService,
  ]
})
export class UserManagementModule { }
