import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserManagementComponent } from './user-management.component';
import { ProfileComponent } from './profile/profile.component';
import { PermissionComponent } from './permission/permission.component';
import { AddUserComponent } from './profile/add/addUser.component';
import { ProfileEditComponent } from './profile/profile-edit/profile-edit.component';
import { AuthGuard } from '../shared/guard/auth.guard';

const routes: Routes = [
  {
    path: '',
    component: UserManagementComponent,
    canActivate: [AuthGuard],
    children: [

    // {
    //     path: '',
    //     canActivateChild:[AuthGuard],
    //     children: [
            { path: '', redirectTo: 'permission' },
            { path: 'profile-view/:id', component: ProfileComponent },
            { path: 'permission', component: PermissionComponent },
            { path: 'profile-add/:id', component: AddUserComponent },
            { path: 'profile-edit/:id', component: ProfileEditComponent }
    //     ]
    //    }
    ]
  }  
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class UserManagementRoutingModule {}
