import { Component, OnInit,ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ProfileService } from '../../service/profile.service';
import { PermissionService } from '../../service/permission.service';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';
import { Constants } from '../../../constants';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import {AlertService} from '../../../shared/services/alert-service.service';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
@Component({
  selector: 'app-profile-edit',
  templateUrl: './profile-edit.component.html',
  styleUrls: ['./profile-edit.component.scss']
})
export class ProfileEditComponent implements OnInit {

  userDetails : any = [];
  files:any;
  token: any;
  userForm:any;
  currentUser = this.authGuardService.getLoginUser();
  constructor(
    private router:Router, 
    private route: ActivatedRoute, 
    private profileServise: ProfileService,
    private el:ElementRef,
    private roleservice:PermissionService,
    private authGuardService:AuthGuardService,
    private alert:AlertService,
    public config: Constants,
    public gfService: GlobalFunctionService,
  ) {
    this.token = this.currentUser.tokenId;
    this.token = '?Token=' + this.token;
    this.userForm = new FormGroup({
      address: new FormControl('', [Validators.required]),
      branchOffice: new FormControl('', [Validators.required]),
      //displayPicture:new FormControl('', Validators.required),
      mobileNo:new FormControl('', [Validators.required]),
      
    });
   }

  ngOnInit() {
    let userData = {"userId":this.route.snapshot.params.id}
        this.profileServise
            .getProfile(userData)
            .subscribe((resp) => {
              this.userDetails = resp.profile[0];
              this.userForm.patchValue({address:  this.userDetails.address}); 
              this.userForm.patchValue({branchOffice: this.userDetails.branchOffice}); 
              this.userForm.patchValue({mobileNo: this.userDetails.mobileNo}); 

            });
            
  }
   
    
Gender = [
    {status: 'Male'},
    {status: 'Female'},
  ];
  Marital_status = [
    {status: 'Married'},
    {status: 'unMarried'},
  ];



  onSubmit() {
    this.userForm.value["userId"] = this.route.snapshot.params.id;
    if(this.files) {
      this.userForm.value["displayPicture"] = this.files;
    }else {
      this.userForm.value["displayPicture"] = this.userDetails.DP;
    }
    console.log(this.userForm,this.files)
    if(this.userForm.valid) {
    this.profileServise
      .updateProfile(this.userForm.value)
      .subscribe(data => {
      this.alertMsg(data)
      if (data.status === "Success") {
        this.router.navigate(['/users/profile-view',data.User[0].userId]);
      }
     
    })
  } else {
    this.alert.error("Please fill required fields.");
  }
    //this.router.navigate(['/profile']);
  }
  onChange(event) {
    let fileList: FileList = event.target.files;
    let file: File = fileList[0];
    let labelSpan = <HTMLLabelElement>this.el.nativeElement.querySelector('.files');
    if(typeof file != 'undefined'){
      let formData: FormData = new FormData();
      labelSpan.classList.remove('error');
      labelSpan.classList.add('added');
      labelSpan.children[1].innerHTML = file.name;
      formData.append('file', file);
      this.roleservice.uploadFile(formData).subscribe(resp => {
        console.log(resp);
        this.files = resp.SavedFileName;
        console.log(this.files)
        this.userDetails.DP = this.files
      })
    } else {
      labelSpan.children[1].innerHTML = '';
      labelSpan.classList.remove('added');
      if(event.target.required)
        labelSpan.classList.add('error');
    }
  }
  alertMsg(resp) {
    var message = resp.message;
    var action = '';
  if (resp.status == 'success') {
    this.alert.success(message);
  }
  else {
    this.alert.error(message);
  }
}
}
