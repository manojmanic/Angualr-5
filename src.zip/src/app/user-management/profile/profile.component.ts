
import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import {
    ObservableMedia
} from '@angular/flex-layout';
import { ProfileService } from '../service/profile.service';
import { Constants } from '../../constants';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';

@Component({
    selector: "app-profile",
    templateUrl: "./profile.component.html",
    styleUrls: ["./profile.component.scss", '../../../assets/css/global.scss']
})
export class ProfileComponent implements OnInit {
    userDetails: any = [];
    token: any;
    currentUser = this.authGuardService.getLoginUser();

    constructor(private router: Router,
        private authGuardService: AuthGuardService,
        private route: ActivatedRoute, private profileServise: ProfileService,
        public config: Constants) {
        this.token = this.currentUser.tokenId;
        this.token = '?Token=' + this.token;
    }
    userData: any = [];
    generalUserDet: any;
    personalUserDet:any;
    userProfileDet:any;
    profilePic:any = {};
    public ngOnInit() {
        let userData = { "userId": this.route.snapshot.params.id }
        this.profileServise
            .getProfile(userData)
            .subscribe((resp) => {
                console.log(resp)
                if(resp.Status == 'success')
                if(resp.profile.length) {
                this.profilePic = {
                    DP:resp.profile[0].DP,
                    FirstName: resp.profile[0].FirstName
                }
                this.userData = [{

                    fieldKey: 'FirstName',
                    values: {
                        value: resp.profile[0].FirstName,
                        fieldCaption: 'First Name'
                    }

                }, {
                  
                    fieldKey: 'LastName',
                    values: {
                        value: resp.profile[0].LastName,
                        fieldCaption: 'Last Name'
                    }  
                },
                {
                    
                      fieldKey: 'roleName',
                      values: {
                          value: resp.profile[0].roleName,
                          fieldCaption: 'role Name'
                      }  
                  },
                  {
                    
                      fieldKey: 'mobileNo',
                      values: {
                          value: resp.profile[0].mobileNo,
                          fieldCaption: 'mobile No'
                      }  
                  },
                  {
                    
                      fieldKey: 'address',
                      values: {
                          value: resp.profile[0].address,
                          fieldCaption: 'address'
                      }  
                  },
                  {
                    
                      fieldKey: 'DP',
                      values: {
                          value: resp.profile[0].DP,
                          fieldCaption: 'DP'
                      }  
                  },
                  {
                    
                      fieldKey: 'UserID',
                      values: {
                          value: resp.profile[0].UserID,
                          fieldCaption: 'UserID'
                      }  
                  },
                  {
                    
                      fieldKey: 'branchOffice',
                      values: {
                          value: resp.profile[0].branchOffice,
                          fieldCaption: 'branch Office'
                      }  
                  },
                  {
                    
                      fieldKey: 'roleId',
                      values: {
                          value: resp.profile[0].roleId,
                          fieldCaption: 'roleId'
                      }  
                  },
                ]
                  this.generalUserDet = [
                    'FirstName',
                    'LastName',
                    'roleName'
                ]
                this.personalUserDet = [
                    'mobileNo',
                    'address',
                ]
                this.userProfileDet = [
                    'FirstName',
                    'branchOffice',
                ]
                console.log(this.userData)
                resp.profile.map(innerResp => {
                    console.log(innerResp)

                    // Object.keys(innerResp).map(key =>{
                    //     let obj = {
                    //         fieldKey:key,
                    //         values : {
                    //         value:innerResp.value,
                    //         fieldColumn:key
                    //         }
                    //     }
                    //     this.userData.push(obj);
                    // })
                })
                console.log(this.userData)

                this.userDetails = resp.profile[0];
                //     Object.keys(resp.profile[0]).map(splitData => {
                //         let obj = {
                //           fieldKey: splitData,
                //           values: { value: resp.profile[0][splitData] },
                //         }
                //         this.userDetails.push(obj);
                //       })
                console.log(this.userDetails, resp);
            }
            });
    }

    profileEdit() {
        let userId = this.userData.find(items => items.fieldKey == 'UserID');
        this.router.navigate(['/users/profile-edit', userId.values.value]);
        // [routerLink]="['/users/profile-edit', userDetails?.UserID]"
        // this.profile_edit=true;

    }
}
