import { Component, OnInit, EventEmitter, ElementRef } from '@angular/core';
import { PermissionService } from '../../service/permission.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { Constants } from '../../../constants';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';

@Component({
  selector: 'app-addUser',
  templateUrl: './addUser.component.html',
  styleUrls: ['./addUser.component.scss', '../../../../assets/css/global.scss']
})
export class AddUserComponent implements OnInit {
  roleId;
  _touched:boolean;
  token: any;
  currentUser = this.authGuardService.getLoginUser();
  constructor(
    private roleservice: PermissionService,
    private router: Router,
    private el: ElementRef,
    private activateRoute: ActivatedRoute,
    private snackBar: MatSnackBar,
    public gfService: GlobalFunctionService,
    public config: Constants,
    private authGuardService:AuthGuardService,
  ) {
    this.roleId = this.activateRoute.snapshot.params.id;

    this.token = this.currentUser.tokenId;
    this.token = '?Token=' + this.token;

  }
  ngOnInit() {
    this.userForm = new FormGroup({
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', Validators.required),
      address: new FormControl('', Validators.required),
      branchOffice: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required),
      emailId: new FormControl('', Validators.required),
      mobileNo: new FormControl('', [Validators.required]),
      displayPicture: new FormControl(null),
    })
  }
  data: any = {};
  reason: any;
  files: any;
  userForm: any;
  
  onSubmit() {
    this.userForm.value["displayPicture"] = this.files;
    
    if (this.userForm.valid) {
      
      this.userForm.value["status"] = 1;
      this.userForm.value["roleId"] = this.roleId;
      this.userForm.value["registrationType"] = "Native";
      this.roleservice.createUser(this.userForm.value).subscribe(resp => {
       
        this.openSnackBar({ status: resp.status, message: JSON.stringify(resp.message) });
        if (resp.status === "Success") {
          this.router.navigate(['/users/permission']);
        }
      })
    } else {
      this.openSnackBar({ status: "error", message: "Please type required fields" });
    }



  }
  onChange(event) {
    let fileList: FileList = event.target.files;
    let file: File = fileList[0];
    
    let labelSpan = <HTMLLabelElement>this.el.nativeElement.querySelector('.files');
    if (typeof file != 'undefined') {
      let formData: FormData = new FormData();
      labelSpan.classList.remove('error');
      labelSpan.classList.add('added');
      labelSpan.children[1].innerHTML = file.name;
      formData.append('file', file);
      this.roleservice.uploadFile(formData).subscribe(resp => {
       
        this.files = resp.SavedFileName;
        this.roleservice.files = resp.SavedFileName;
      })
    } else {
      labelSpan.children[1].innerHTML = '';
      labelSpan.classList.remove('added');
      if (event.target.required)
        labelSpan.classList.add('error');
    }
  }
  openSnackBar(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'Success' || resp.status == 'success') {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['success']
      });
    }
    else {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['error']
      });
    }

  }

}