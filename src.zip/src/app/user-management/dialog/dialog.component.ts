import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { Router } from '@angular/router';
import { PermissionService } from '../service/permission.service';
import { MatSnackBar } from '@angular/material';
import { FormControl, Validators } from '@angular/forms';
import { PermissionComponent } from '../permission/permission.component';
import {AlertService} from '../../shared/services/alert-service.service';

// import { FormsModule }   from '@angular/forms';
@Component({
  selector: 'your-dialog-selector',
  styleUrls: ['./dialog.component.scss'],
  templateUrl: './dialog.component.html'
})
export class DialogComponent {

  roleName: string;
  user_count_zeroId:any;
  user_count_zeroName:any;
  userName: string;
  roleId: number;
  userId: number;
  new_role_form: boolean = false;
  dialog_form: boolean;
  form: boolean;
  constructor(
    public dialogRef: MatDialogRef<DialogComponent>,
    public snackBar: MatSnackBar,
    private router: Router,
    private roleservice: PermissionService,
    private alert:AlertService,
    
    // private form1:FormsModule
  ) {

  }

  new_role(role_name: string, role_desc: any) {
    if(role_name != '' && role_name != undefined){
    this.roleservice.createRole(role_name).subscribe(data => {
      
      this.openSnackBar({status:data.status,message:data.message});
      if(data.status == "success") {
      let newRoleData:any = [];
      let obj = {
        roleId:data.Roles[0].roleId,
        roleName:role_name,
        userCount:data.Roles[0].UserCount,
        DefaultRole:0
     }
     this.alert.success(data.message);
     newRoleData = (obj);
     this.dialogRef.close(newRoleData);
    }
    else {
      this.alert.error(data.message);
    }
    })
  } else {
    this.openSnackBar({status:'error',message:'please type Role name...'});
  }
  }
  role_change() {
    var data;
    data = { userId: [this.userId], roleId: this.roleId };
    this.roleservice.setUserRole(data).subscribe(data => {
      this.openSnackBar({status:data.status,message:data.message});
      this.dialogRef.close(true);
    })
  }
  role_delete() {
    var data ={"roleId":this.user_count_zeroId};
    this.roleservice.deleteRole(data).subscribe(data=>{
      if(data.status == "Success") {
        //this.openSnackBar({status:data.status,message:data.message});
        this.dialogRef.close(true);
      }
      this.openSnackBar({status:data.status,message:data.message});
    })
  }
  openSnackBar(resp) {
    var message = resp.message;
    var action = '';
  if (resp.status == 'Success' || resp.status == 'success') {
    this.snackBar.open(message, action, {
      duration: 1000,
      extraClasses: ['success']
    });
  }
  else {
    this.snackBar.open(message, action, {
      duration: 1000,
      extraClasses: ['error']
    });
  }
}
}