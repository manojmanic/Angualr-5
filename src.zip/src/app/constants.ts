export class Constants {
    // API_URL: String = "http://reqruit.dev.betabasket.net";
    // API_URL: String = "http://192.168.99.126:3001";
    // API_URL: String = "http://192.168.99.86:3000";    
    API_URL : String = "http://reqruit.dev.betabasket.net:3000"
    // API_URL : String = "http://localhost:3000";
    FORM_LOADING_SEC = 1000;
    PG_LOADING_SEC = 2000;
    SEARCH_LOADING_SEC = 2000;
    ROUTE_ID_QUOTATION = '1';
    ROUTE_ID_CONTRACT = '3';
    LOGIN_EXPIRY = 180000000000000; // 4 in Days
    PG_LIMIT_OPTIONS = [2, 10, 25, 100];
    PG_LIMIT_DEFAULT = 10;
    ORIGNAL_IMAGE_PATH = this.API_URL+"/uploads/originals/";
    RESIZE_IMAGE_PATH = this.API_URL+"/uploads/resize-image/";
    M_RESIZE_IMAGE_PATH = this.API_URL+"/uploads/m-resize-image/";
    FILE_PATH = this.API_URL+"/uploads/files/";
    TEMP_TOKEN = '294de3557d9d00b3d2d8a1e6aab028cf';    
}