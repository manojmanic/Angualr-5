import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Constants } from '../../constants';

@Injectable()
export class ContractService {

  head = new HttpHeaders();

  constructor(
      private http: HttpClient,
      private config: Constants
    ) { 
    this.head['Content-Type'] = 'application/json';
  }

  getContractList(data): Observable<any>{
    let postUrl = this.config.API_URL+'/api/contract_data'; 
    return this.http.post(postUrl, data, { headers: this.head });
  }

}
