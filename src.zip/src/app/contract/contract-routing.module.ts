import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContractComponent } from './contract.component';
import { ViewContractComponent } from './view-contract/view-contract.component';
import { SingleContractComponent } from './view-contract/resource/single-contract/single-contract.component';
const routes: Routes = [
    {
        path: '',
        component: ContractComponent,
        children: [
            { path: '', redirectTo: 'view-contract' },
            { path: 'view-contract/:id', component: ViewContractComponent },
            { path: 'single-contract/:id/:resDataid', component: SingleContractComponent }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ContractRoutingModule {}
