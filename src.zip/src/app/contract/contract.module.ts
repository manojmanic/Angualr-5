import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { AlertModule } from '../alert/alert.module';
import {
  MatButtonModule,
  MatCheckboxModule,
  MatToolbarModule,
  MatCardModule,
  MatTabsModule,
  MatInputModule,
  MatIconModule,
  MatGridListModule,
  MatSidenavModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatFormFieldModule,
  MatSelectModule,
  MatRadioModule,
  MatAutocompleteModule,
  MatTooltipModule,
  MatSnackBarModule,
  MatDialogModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatChipsModule,
  MatExpansionModule,
  MatStepperModule,
  MatSliderModule,
  MatSlideToggleModule
} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PipeModule } from '../shared/pipes/pipe.module';

import { ContractRoutingModule } from './contract-routing.module';
import { ContractComponent } from './contract.component';
import { ViewContractComponent } from './view-contract/view-contract.component';
import { ResourceComponent } from './view-contract/resource/resource.component';

import { ContractService } from './services/contract.service';
import { DialogComponent } from './view-contract/resource/dialog/dialog.component';
import { SingleContractComponent } from './view-contract/resource/single-contract/single-contract.component';
import { DependentdialogComponent } from './view-contract/resource/single-contract/dependentdialog/dependentdialog.component';
import { DependentdialogeditComponent } from './view-contract/resource/single-contract/dependentdialogedit/dependentdialogedit.component';
import { ProfiledialogComponent } from './view-contract/resource/single-contract/profiledialog/profiledialog.component';
import { ProfiledialogeditComponent } from './view-contract/resource/single-contract/profiledialogedit/profiledialogedit.component';
import { DeldialogdependentComponent } from './view-contract/resource/single-contract/dependentdialog/deldialogdependent/deldialogdependent.component';
import { DocumentsComponent } from './view-contract/resource/single-contract/documents/documents.component';
import { DocdialogComponent } from './view-contract/resource/single-contract/documents/docdialog/docdialog.component';
import { DocdialogeditComponent } from './view-contract/resource/single-contract/documents/docdialogedit/docdialogedit.component';
import { ProfileComponent } from './view-contract/resource/single-contract/profile/profile.component';
import { RenderModule } from '../render/render.module';
import { DependentComponent } from './view-contract/resource/single-contract/dependent/dependent.component';
import { TodoModule } from '../todo/todo.module';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatCardModule,
    MatTabsModule,
    MatInputModule,
    MatIconModule,
    MatGridListModule,
    MatSidenavModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatDialogModule,
    MatStepperModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatExpansionModule,
    MatSliderModule,
    MatSlideToggleModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    ContractRoutingModule,
    AlertModule,
    PipeModule,
    RenderModule,
    TodoModule
  ],
  declarations: [
    ContractComponent,
    ViewContractComponent,
    ResourceComponent,
    DialogComponent,
    SingleContractComponent,
    DependentdialogComponent,
    DependentdialogeditComponent,
    ProfiledialogComponent,
    ProfiledialogeditComponent,
    DeldialogdependentComponent,
    DocumentsComponent,
    DocdialogComponent,
    DocdialogeditComponent,
    ProfileComponent,
    DependentComponent
  ],
  entryComponents: [DialogComponent,DependentdialogComponent,DependentdialogeditComponent,ProfiledialogComponent,
    ProfiledialogeditComponent,DeldialogdependentComponent,DocumentsComponent,DocdialogComponent,
    DocdialogeditComponent
  ],
  providers: [
    ContractService
  ]
})
export class ContractModule { }
