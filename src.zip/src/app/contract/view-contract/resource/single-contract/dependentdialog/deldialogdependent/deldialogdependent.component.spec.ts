import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeldialogdependentComponent } from './deldialogdependent.component';

describe('DeldialogdependentComponent', () => {
  let component: DeldialogdependentComponent;
  let fixture: ComponentFixture<DeldialogdependentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeldialogdependentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeldialogdependentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
