import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { ScreenTemplateJsonBuilder } from '../../../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalformService } from '../../../../../../shared/services/globalform.service';
import { ContractService } from '../../../../../services/contract.service';
@Component({
  selector: 'app-deldialogdependent',
  templateUrl: './deldialogdependent.component.html',
  styleUrls: ['./deldialogdependent.component.scss']
})
export class DeldialogdependentComponent implements OnInit {

  
  depDataId: any;
  contractId:any;
  caseId: any;
  formBuildBaseObj: any;
  dFirstName:any;
  constructor(
    public deldialog: MatDialogRef<DeldialogdependentComponent>,
    private screenTB: ScreenTemplateJsonBuilder,
    private service:GlobalformService,
    private contractService:ContractService
  ) {
  }

  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formAdd(this.caseId);
  }
  delete() {
    this.service.deleteForm(this.depDataId,this.formBuildBaseObj.formId,'','').subscribe(resp=>{
      if(resp.status == "success") {
        // var apiData = { "formId": this.formBuildBaseObj.formId, contractId:this.contractId , "languageCode": "en" }
        // this.contractService.getContractList(apiData).subscribe(resp=>{
        //   this.deldialog.close(resp);
        // })
        this.deldialog.close(this.depDataId);
      }
    })
  }

}

