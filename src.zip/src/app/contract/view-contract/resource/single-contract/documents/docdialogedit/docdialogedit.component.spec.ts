import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocdialogeditComponent } from './docdialogedit.component';

describe('DocdialogeditComponent', () => {
  let component: DocdialogeditComponent;
  let fixture: ComponentFixture<DocdialogeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocdialogeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocdialogeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
