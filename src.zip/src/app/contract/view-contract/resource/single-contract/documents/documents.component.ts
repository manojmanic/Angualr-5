import { Component, OnInit, ElementRef, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContractService } from '../../../../services/contract.service';
import { GlobalFunctionService } from '../../../../../shared/services/global-function.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TextboxQuestion } from '../../../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../../../shared/models/question-base';
import { DropdownQuestion } from '../../../../../shared/models/question-dropdown';
import { AlertService } from '../../../../../shared/services/alert-service.service';
import { DatePipe } from '@angular/common';
import { FormBuildBaseService } from '../../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../../shared/common/form-build-functions.service';
import { ScreenTemplateJsonBuilder } from '../../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalformService } from '../../../../../shared/services/globalform.service';
import { AuthGuardService } from '../../../../../shared/guard/auth-guard.service';
import { AbstractControl } from '@angular/forms';
import { Constants } from '../../../../../constants';
import { GlobalformControlService } from '../../../../../shared/services/globalform-control.service';
import { DocdialogComponent } from '../../../../view-contract/resource/single-contract/documents/docdialog/docdialog.component';
import { DocdialogeditComponent } from '../../../../view-contract/resource/single-contract/documents/docdialogedit/docdialogedit.component';
@Component({
  selector: 'app-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {
  docDialog: MatDialogRef<DocdialogComponent>;
  docDialogEdit: MatDialogRef<DocdialogeditComponent>;
  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  formId: any = {};
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  term_Ref: any;
  formBuildBaseObj: any;
  params: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  resourceId;
  dependentId;
  contractId: any;
  buildData: any
  updatedId: any;
  caseid: any;
  resDataId: any;
  buttonData: any;
  _touched: boolean;
  docData:any=[];
  showFieldsDocs:any=[];
  resRecordId;
  @Input() workFlowData: any;
  ngOnInit() {
    
  }

  constructor(
    private route: ActivatedRoute, 
    private contractService: ContractService,
    public gfService: GlobalFunctionService,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
    private qcs: GlobalformControlService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private el: ElementRef,
    private alert: AlertService,
    private authGuardService: AuthGuardService,
    public config: Constants,
    private service: GlobalformService
  ) {
    this.resRecordId = this.gfService.encryptDecryptFun('atob', this.route.snapshot.params.resDataid);

    this.formBuildBaseObj = this.screenTB.formView('document');
    this.showFieldsDocs = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    this.formBuildBaseObj=this.screenTB.formAdd('document')
    let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": {resId:this.resRecordId}, "languageCode": "en" };
    this.service.getFormData(apiData).subscribe(getFormResp => {
     console.log(getFormResp)
    if(getFormResp.status == 'success')
    this.docData=this.gfService.buildView(getFormResp.data)[0];
    this.docData.sort((a, b) => a.values.fieldOrder - b.values.fieldOrder);
    
    })
   
   }
  
  //  docBuild(data){
   
  //  let docData_value = [];
  //   data.map(key=>{
      
  //      Object.keys(key).map(arrKey=>{
  //        let obj={
  //         fieldKey: arrKey,
  //         values: key[arrKey],
  //        }
  //        docData_value.push(obj);
         
  //      });
  //   });
    
  //   return docData_value;
  //  }


   UploadDocuments(){
 
    this.docDialog = this.dialog.open(DocdialogComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.docDialog.componentInstance.caseid = 'document'; // To get data from json-builder
      this.docDialog.componentInstance.resourceId = this.resRecordId;
      this.docDialog.componentInstance.workFlowData = this.workFlowData;
      this.docDialog.afterClosed().subscribe(resp=>{
        if(resp){
          
          this.docData=this.gfService.buildView(resp.data)[0];
        }
        
      })
   }
   uploadDocsEdit(){
    // console.log(this.docData)
    let dataId = this.docData.find(items => items.fieldKey == 'dataId');
    this.docDialogEdit = this.dialog.open(DocdialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.docDialogEdit.componentInstance.caseid = 'document'; // To get data from json-builder
      this.docDialogEdit.componentInstance.resourceId = this.resRecordId;
      this.docDialogEdit.componentInstance.dialogData = this.docData;
      this.docDialogEdit.componentInstance.dataId = dataId.values;
      this.docDialogEdit.componentInstance.workFlowData = this.workFlowData;
      this.docDialogEdit.afterClosed().subscribe(resp=>{
        if(resp){
         
          this.docData=this.gfService.buildView(resp.data)[0];
        }
        
      })
     
   }

}
