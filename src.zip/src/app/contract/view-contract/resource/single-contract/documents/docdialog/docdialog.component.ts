import { Component, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContractService } from '../../../../../services/contract.service';
import { GlobalFunctionService } from '../../../../../../shared/services/global-function.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TextboxQuestion } from '../../../../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../../../../shared/models/question-base';
import { DropdownQuestion } from '../../../../../../shared/models/question-dropdown';
import { AlertService } from '../../../../../../shared/services/alert-service.service';
import { DatePipe } from '@angular/common';
import { FormBuildBaseService } from '../../../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../../../shared/common/form-build-functions.service';
import { ScreenTemplateJsonBuilder } from '../../../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalformService } from '../../../../../../shared/services/globalform.service';
import { AuthGuardService } from '../../../../../../shared/guard/auth-guard.service';
import { AbstractControl } from '@angular/forms';
import { Constants } from '../../../../../../constants';
import { GlobalformControlService } from '../../../../../../shared/services/globalform-control.service';

@Component({
  selector: 'app-docdialog',
  templateUrl: './docdialog.component.html',
  styleUrls: ['./docdialog.component.scss']
})
export class DocdialogComponent implements OnInit {

  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  formId: any = {};
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  term_Ref: any;
  formBuildBaseObj: any;
  params: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  resourceId;
  dependentId;
  contractId: any;
  buildData: any
  updatedId: any;
  caseid: any;
  resDataId: any;
  buttonData: any;
  cancelButton: any;
  _touched: boolean;
  workFlowData;

  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formAdd('document');
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      
      this.buildData = data.data;
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
          let changed = eventCalls[preBuildEvFn](param);
          this.buildData = changed.formItems;
          this.buttonData = changed.buttonData;
          this.cancelButton = changed.cancelButton;

        }
      }
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
      setTimeout(() => {
        let buildFields = this.qcs.buildFields(this.buildData, this.formBuildBaseObj.showFields);
        this.workFlowData.map(workFlowResp => {
          if (workFlowResp.formFields != null && workFlowResp.formFields.length) {
            this.gfService.fieldManage(workFlowResp.formFields,buildFields);
          }
        })
        
        buildFields.map(resp => {
            if (resp.hasOwnProperty('readonly')) {
                delete resp.readonly;
            } else {
                resp['readonly'] = true;
            }
        })
        this.questions = buildFields;
        let buildData =  this.qcs.buildControls(buildFields);
        this.form = buildData;
        console.log(buildData, this.buildData, this.formBuildBaseObj.showFields);
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
      }, this.config.FORM_LOADING_SEC);
    })
  }

  constructor(
    public dialogRef: MatDialogRef<DocdialogComponent>,
    private route: ActivatedRoute,
    private contractService: ContractService,
    public gfService: GlobalFunctionService,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
    private qcs: GlobalformControlService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private el: ElementRef,
    private alert: AlertService,
    private authGuardService: AuthGuardService,
    public config: Constants,
    private service: GlobalformService
  ) {

  }


  // buildForm(formData) {
  //   questions => [] = [];
  //   this.questions.length = 0;
  //   this.buildData = formData;
  //   let fieldData = [];
  //   let fieldGroupData = [];
  //   let fieldGroupIdData = [];

  //   /////// To Get fieldGroupId ///////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
  //     this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
  //   }

  //   /////// To Get FieldList /////////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     for (var j = 0; j < this.fieldGroupId.length; j++) {
  //       if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
  //         for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
  //           let pushData;
  //           pushData = this.buildData.fieldGroup[i].FieldList[k];
  //           pushData.visible = false;
  //           if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
  //             pushData.visible = true;
  //           }
  //           if (pushData.fieldType === 'shortText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'currencyText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'calcText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'text') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'simpleListMultiSelect') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'singleSelectOption') {
  //             let options = [
  //               { key: 'yes', value: 'Yes' },
  //               { key: 'no', value: 'No' },
  //             ]
  //             pushData.additionalMetaData = options;
  //             fieldData.push(new CheckboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'radio') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceListMulti') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileImage') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileDoc') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'date') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //         }
  //       }
  //     }
  //   }

  //   this.workFlowData.map(workFlowResp => {
  //     if (workFlowResp.formFields != null && workFlowResp.formFields.length) {
  //       this.gfService.fieldManage(workFlowResp.formFields,fieldData);
  //     }
  //   })
    
  //   fieldData.map(resp => {
  //       if (resp.hasOwnProperty('readonly')) {
  //           delete resp.readonly;
  //       } else {
  //           resp['readonly'] = true;
  //       }
  //   })
  //   this.questions = fieldData;
  //   this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
  //   this.form = this.qcs.toFormGroup(this.questions);
  //   let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
  //   if (postBuildEvFn != '') {
  //     const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
  //     if (eventCalls[postBuildEvFn]) {
  //       let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
  //       let changed = eventCalls[postBuildEvFn](param);
  //     }
  //   }

  // }

  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {
    

    let status;
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems, questions: this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        status = changed.status;
      }
    }
    this.form.value['resId'] = this.resourceId;
    
    if (this.form.valid) {
      this.service.putForms(this.form.value, this.formBuildBaseObj.formId).subscribe(resp => {
        //console.log(resp);
        if(resp.status=='success'){
        // this.service.updateFormData(this.form.value, this.formBuildBaseObj.formId, resp.data).subscribe(updateresp => {
        //   if(updateresp.status=='success'){
          let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": {resId:this.resourceId}, "languageCode": "en" };
          this.service.getFormData(apiData).subscribe(getFormResp => {
            this.dialogRef.close(getFormResp);
          })
        // }
        // })

      }
        
        this.alertMsg(resp);
      
      });
    
    } else if(this.form.status == "DISABLED"){
      this.dialogRef.close();
    } else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
      this.alert.error("Please fill required fields.");
    }

  }
  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }


}
