import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';
import { AuthGuardService } from '../../../../../shared/guard/auth-guard.service';
import { Constants } from '../../../../../constants';
import { ScreenTemplateJsonBuilder } from '../../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalFunctionService } from '../../../../../shared/services/global-function.service';
import { MatDialog, MatDialogRef,MatTabChangeEvent } from '@angular/material';
import { DependentdialogComponent } from '../../../../view-contract/resource/single-contract/dependentdialog/dependentdialog.component';
import { DependentdialogeditComponent } from '../dependentdialogedit/dependentdialogedit.component';
import { DeldialogdependentComponent } from '../dependentdialog/deldialogdependent/deldialogdependent.component';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-dependent',
  templateUrl: './dependent.component.html',
  styleUrls: ['./dependent.component.scss']
})
export class DependentComponent implements OnInit {

  @Input()contractId:any;
  @Input()resourceId:any;
  @Input()dependentDetails:any;
  @Output() outputData = new EventEmitter(); 
  @Output() deleteDepDataId = new EventEmitter(); 
  // dProfilePic:any;
  showFieldsListDep:any;
  deldiaglogDepDetails: MatDialogRef<DeldialogdependentComponent>;
  dialogRefDetails: MatDialogRef<DependentdialogComponent>;
  dialogRefDetailsEdit: MatDialogRef<DependentdialogeditComponent>;
  recordId;
  resRecordId;
  userToken;
  
  constructor(
    private authGuardService: AuthGuardService,
    private config: Constants,
    private screenTB: ScreenTemplateJsonBuilder,
    private gfService: GlobalFunctionService,
    private route: ActivatedRoute,

    public dialog: MatDialog,
  ) { 
    this.recordId = this.gfService.encryptDecryptFun('atob', this.route.snapshot.params.id);
    this.resRecordId = this.gfService.encryptDecryptFun('atob', this.route.snapshot.params.resDataid);
  }

  ngOnInit() {
    let imagePath = this.config.M_RESIZE_IMAGE_PATH;
    if(this.authGuardService.getLoginUser()){
      this.userToken = this.authGuardService.getLoginUser().tokenId;
    }
    let formBuildBaseObj = this.screenTB.formView('contractDependent');
    this.showFieldsListDep = Array.from(Object.keys(formBuildBaseObj.showFields));
  }
  selected(status) {
    if (status == "0" && status != undefined) {
      return true;
    }
    else {
      return false;
    }
  }
  editDependent(dependent) {
    let depDataId;
    for (let data of dependent) {
      if (data.fieldKey === "dataId") {
        depDataId = data.values;
      }
    }
    this.dialogRefDetailsEdit = this.dialog.open(DependentdialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefDetailsEdit.componentInstance.caseid = 'Dependent'; // To get data from json-builder
    this.dialogRefDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefDetailsEdit.componentInstance.resourceId = this.resRecordId
    this.dialogRefDetailsEdit.componentInstance.depDataId = depDataId;
    this.dialogRefDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        this.outputData.emit(resp);

      }
    });
  }
  delete(deldata) {
    let depDataId;
    let dFirstName;
    this.deldiaglogDepDetails = this.dialog.open(DeldialogdependentComponent
      , {
        // height: '100px',
        // width: '100px'
      });
    for (let data of deldata) {
      if (data.fieldKey === "dataId") 
        depDataId = data.values;
        if(data.fieldKey === 'dFirstName') {
         dFirstName = data.values.value
        }
    }
        this.deldiaglogDepDetails.componentInstance.depDataId = depDataId;
        this.deldiaglogDepDetails.componentInstance.contractId = this.recordId
        this.deldiaglogDepDetails.componentInstance.caseId = 'Dependent'
      
    
    this.deldiaglogDepDetails.componentInstance.dFirstName = dFirstName;
    //////////// To Populate Resource and Dependent List After Delete  ////////////////////
    this.deldiaglogDepDetails.afterClosed().subscribe(resp => {
      if (resp) {
        this.deleteDepDataId.emit(resp);
      }
    })
  }
}
