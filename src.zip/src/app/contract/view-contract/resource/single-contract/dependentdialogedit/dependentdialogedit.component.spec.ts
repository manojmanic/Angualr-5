import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DependentdialogeditComponent } from './dependentdialogedit.component';

describe('DependentdialogeditComponent', () => {
  let component: DependentdialogeditComponent;
  let fixture: ComponentFixture<DependentdialogeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DependentdialogeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DependentdialogeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
