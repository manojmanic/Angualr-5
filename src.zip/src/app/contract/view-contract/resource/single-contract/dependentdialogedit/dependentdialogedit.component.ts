import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { GlobalformService } from '../../../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import { ContractService } from '../../../../services/contract.service';
import { AlertService } from '../../../../../shared/services/alert-service.service';
import { AbstractControl } from '@angular/forms';
import { Constants } from '../../../../../constants';
@Component({
  selector: 'app-dependentdialogedit',
  templateUrl: './dependentdialogedit.component.html',
  styleUrls: ['./dependentdialogedit.component.scss']
})
export class DependentdialogeditComponent implements OnInit {
  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  formId: any = {};
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  term_Ref: any;
  formBuildBaseObj: any;
  params: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  resourceId;
  dependentId;
  contractId: any;
  buildData: any
  updatedId: any;
  caseid: any;
  depDataId: any;
  buttonData: any;
  cancelButton: any;
  _touched: boolean;

  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formEdit(this.caseid);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {

      this.buildData = data.data;
     
      let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.depDataId } };
      this.service.getFormData(apiData).subscribe(resp => {
        let formGroups = this.buildData.fieldGroup;
        formGroups.filter(formGroupsData => {
          let formFields = formGroupsData.FieldList;
          formFields.filter(getForm => {
            resp.data.map(getFormData => {
              Object.keys(getFormData).map(key => {
                if (typeof getFormData[key] == 'object' && getFormData[key] != null) {
                  if (getFormData[key].fieldId == getForm.fieldId) {
                    getForm.value = getFormData[key].value;
                  }
                }
              })
            })
          })
        })
        let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
            let changed = eventCalls[preBuildEvFn](param);
            this.buildData = changed.formItems;
            this.buttonData = changed.buttonData;
            this.cancelButton = changed.cancelButton;
          }
        }
        setTimeout(() => {
          let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
          this.questions = buildData['fields'];
          this.form = buildData['controls'];
          let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
          if (postBuildEvFn != '') {
            const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[postBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
              let changed = eventCalls[postBuildEvFn](param);
            }
          }
        }, this.config.FORM_LOADING_SEC);
      })
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
    })
  }

  constructor(public dialogRef: MatDialogRef<DependentdialogeditComponent>,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private alert: AlertService,
    private route: ActivatedRoute,
    public cdRef: ChangeDetectorRef,
    private config: Constants,
    private contractservice: ContractService) {

  }

  // buildForm(formData) {
  //   questions => [] = [];
  //   this.questions.length = 0;
  //   this.buildData = formData;
  //   let fieldData = [];
  //   let fieldGroupData = [];
  //   let fieldGroupIdData = [];

  //   /////// To Get fieldGroupId ///////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
  //     this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
  //   }

  //   /////// To Get FieldList /////////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     for (var j = 0; j < this.fieldGroupId.length; j++) {
  //       if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
  //         for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
  //           let pushData;
  //           pushData = this.buildData.fieldGroup[i].FieldList[k];
  //           pushData.visible = false;
  //           if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
  //             pushData.visible = true;
  //           }
  //           if (pushData.fieldType === 'shortText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'currencyText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'calcText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'text') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'simpleListMultiSelect') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'singleSelectOption') {
  //             let options = [
  //               { key: 'yes', value: 'Yes' },
  //               { key: 'no', value: 'No' },
  //             ]
  //             pushData.additionalMetaData = options;
  //             fieldData.push(new CheckboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'radio') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceListMulti') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileImage') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'date') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //         }
  //       }
  //     }
  //   }
  //   let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.depDataId } };
  //   this.service.getFormData(apiData).subscribe(resp => {
  //     resp.data.map(getFormData => {
  //       Object.keys(getFormData).map(key => {
  //         fieldData.map(getForm => {
  //           if (typeof getFormData[key] == 'object' && getFormData[key] != null) {
  //             if (getFormData[key].fieldId == getForm.fieldId) {
  //               getForm.value = getFormData[key].value;
  //             }
  //           }
  //         })
  //       })
  //     })
  //     this.questions = fieldData;
  //     this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
  //     this.form = this.qcs.toFormGroup(this.questions);
  //     this.cdRef.detectChanges();
  //     let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
  //     if (postBuildEvFn != '') {
  //       const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
  //       if (eventCalls[postBuildEvFn]) {
  //         let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
  //         let changed = eventCalls[postBuildEvFn](param);
  //       }
  //     }

  //   })
  // }

  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {

    this.form.patchValue({ resourceId: this.resourceId }); /// dependent
    //this.form.patchValue({ contractId:this.contractId }); /// contractId Patch
    let status;
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems, questions: this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        status = changed.status;

      }
    }
    if (this.form.valid) {
      if (status != "DeActivated") {

        Object.keys(this.form.controls).map(fieldArrData => {
          let fieldKey = fieldArrData;
          let fieldData = this.form.controls[fieldKey]
          for (var question of this.questions) {
            if (question.fieldType === 'date') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            }
          }
          //  if (fieldData['nativeElement'].classList.contains('datePick')) {

          //   var currentDate = new DatePipe('en-us');
          //   let final = currentDate.transform(fieldData.value, 'yyyy-MM-dd')
          //   if (final != null)
          //     this.form.patchValue({ [fieldKey]: final });
          //  }
        });

        this.service.updateFormData(this.form.value, this.formBuildBaseObj.formId, this.depDataId).subscribe(data => {

          this.alertMsg(data);
          let apiData;
          console.log(data);

          if (data.status == 'success') {
            apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.depDataId } };
            this.service.getFormData(apiData).subscribe(resp => {

              if (resp.status == 'success')
                this.dialogRef.close(resp.data);
            })
          }


        })
      }
      else {
        this.alert.error("Please Select Active value.");
      }
    } else if (this.form.status == "DISABLED") {
      this.dialogRef.close();
    } else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
      this.alert.error("Please fill required fields.");
    }

  }
  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

}
