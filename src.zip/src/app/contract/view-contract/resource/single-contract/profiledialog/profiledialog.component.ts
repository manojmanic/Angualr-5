import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { GlobalformService } from '../../../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import { ContractService } from '../../../../services/contract.service';
import { AlertService } from '../../../../../shared/services/alert-service.service';
import { AbstractControl } from '@angular/forms';
import { GlobalFunctionService } from '../../../../../shared/services/global-function.service';
import { Constants } from '../../../../../constants';

@Component({
  selector: 'app-profiledialog',
  templateUrl: './profiledialog.component.html',
  styleUrls: ['./profiledialog.component.scss']
})
export class ProfiledialogComponent implements OnInit {
  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  formId: any = {};
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  term_Ref: any;
  formBuildBaseObj: any;
  params: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  resourceId;
  dependentId;
  contractId: any;
  buildData: any
  updatedId: any;
  caseid: any;
  depDataId: any;
  buttonData: any;
  cancelButton: any;
  dialogData: any = [];
  _touched: boolean;
  workFlowData: any;
  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formAdd(this.caseid);
    // console.log(this.caseid);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      this.buildData = data.data;
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData, additionalData: this.dialogData };
          let changed = eventCalls[preBuildEvFn](param);
          this.buildData = changed.formItems;
          this.buttonData = changed.buttonData;
          this.cancelButton = changed.cancelButton;

        }
      }
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
      setTimeout(() => {
        let buildFields = this.qcs.buildFields(this.buildData, this.formBuildBaseObj.showFields);
        this.workFlowData.map(workFlowResp => {
          if (workFlowResp.formFields != null && workFlowResp.formFields.length) {
            this.gfService.fieldManage(workFlowResp.formFields,buildFields);
          }
        })
        
        buildFields.map(resp => {
            if (resp.hasOwnProperty('readonly')) {
                delete resp.readonly;
            } else {
                resp['readonly'] = true;
            }
        })
        this.questions = buildFields;
        let buildData =  this.qcs.buildControls(buildFields);
        this.form = buildData;
        console.log(buildData, this.buildData, this.formBuildBaseObj.showFields);
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
      }, this.config.FORM_LOADING_SEC);
    })
  }

  constructor(public dialogRef: MatDialogRef<ProfiledialogComponent>,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    public gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private alert: AlertService,
    private route: ActivatedRoute,
    private config: Constants,
    private contractservice: ContractService) {

  }

  

  markAsTouched() {
    this._touched = true;

  }

  onSubmit() {
    this.form.patchValue({ resourceId: this.resourceId });
    this.form.patchValue({ userType: "Resource" });
    this.form.patchValue({ resDepId: this.resourceId });
    this.form.value['resId'] = this.resourceId;
    // this.form.value['userType']="Resource";
    // this.form.value['resDepId']=this.resourceId;
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems, questions: this.questions, additionData: this.dialogData };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
      }
    }
    let fieldData: any = this.questions
    // Object.keys(this.form.controls).map(formRes => {
    //    fieldData.map(resp =>{
    //      if(resp.hasOwnProperty('readonly') || resp.visible == false) {
    //       this.form.controls[resp.fieldColumn].setValidators(null);
    //       this.form.controls[resp.fieldColumn].updateValueAndValidity();
    //       // this.form.get(resp.fieldColumn).reset({ value: null, disabled: true });
    //       this.form.patchValue({[resp.fieldColumn]: null });
    //       // this.form.controls[resp.fieldColumn].value = null;
    //      } 
    //    })
    // })
    // console.log(this.form)
    if (this.form.valid) {
      if (status != "DeActivated") {

        Object.keys(this.form.controls).map(fieldArrData => {
          let fieldKey = fieldArrData;
          let fieldData = this.form.controls[fieldKey]
          for (var question of this.questions) {
            if (question.fieldType === 'date') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            }
          }
          //  if (fieldData['nativeElement'].classList.contains('datePick')) {
          //   console.log(fieldArrData);
          //   var currentDate = new DatePipe('en-us');
          //   let final = currentDate.transform(fieldData.value, 'yyyy-MM-dd')
          //   if (final != null)
          //     this.form.patchValue({ [fieldKey]: final });
          //  }
        });

        Object.keys(this.form.controls).map(fieldArrData => {
          let fieldKey = fieldArrData;
          let fieldData = this.form.controls[fieldKey]
          for (var question of this.questions) {
            if (question.fieldType === 'dateTime') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyy-MM-dd hh:mm:ss')
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            }
          }

        });
        // console.log(this.form);
        this.service.putForms(this.form.value, this.formBuildBaseObj.formId).subscribe(data => {
          this.alertMsg(data);
          if (data.status == 'success') {
            //  var apiData = { "formId": this.formBuildBaseObj.formId, contractId:this.contractId , "languageCode": "en" };
            let apiData;
            if (this.caseid == 'TravelDetails' || this.caseid == 'OnBoardingDetails' || this.caseid == 'Passport') {
              apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId }, "languageCode": "en" };
            } else if (this.caseid == 'PreviousPassport' || this.caseid == 'PreviousCompanyDetails') {
              apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId, dataId: data.data }, "languageCode": "en" };
            } else {
              apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId }, "languageCode": "en" };
            }
            this.service.getFormData(apiData).subscribe(resp => {
              if (resp.status == 'success')
                this.dialogRef.close(resp);
            })
          }
        })
      }
      else {
        this.alert.error("Please Select Active Visa Name");
      }
    } else if (this.form.status == "DISABLED") {
      this.dialogRef.close();
    } else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
      this.alert.error("Please fill required fields.");
    }

  }
  alertMsg(resp) {
    var message;
    if (Object.keys(resp).length == 0) {
      message = 'Something went wrong...'
    } else {
      message = resp.message;
    }

    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

}
