import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfiledialogeditComponent } from './profiledialogedit.component';

describe('ProfiledialogeditComponent', () => {
  let component: ProfiledialogeditComponent;
  let fixture: ComponentFixture<ProfiledialogeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfiledialogeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfiledialogeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
