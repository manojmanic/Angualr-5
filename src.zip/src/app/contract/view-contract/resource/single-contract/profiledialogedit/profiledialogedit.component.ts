import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { GlobalformService } from '../../../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import { ContractService } from '../../../../services/contract.service';
import { AlertService } from '../../../../../shared/services/alert-service.service';
import { AbstractControl } from '@angular/forms';
import { GlobalFunctionService } from '../../../../../shared/services/global-function.service';
import { Constants } from '../../../../../constants';

@Component({
  selector: 'app-profiledialogedit',
  templateUrl: './profiledialogedit.component.html',
  styleUrls: ['./profiledialogedit.component.scss']
})
export class ProfiledialogeditComponent implements OnInit {
  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  formId: any = {};
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  term_Ref: any;
  formBuildBaseObj: any;
  params: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  resourceId;
  dependentId;
  contractId: any;
  buildData: any
  updatedId: any;
  caseid: any;
  depDataId: any;
  buttonData: any;
  cancelButton: any;
  _touched: boolean;
  passDetails: any = [];
  dialogData: any = [];
  workFlowData: any;
  getFormRespData: any = [];
  prePassDataId: any;
  ngOnInit() {
    // console.log(this.caseid);
    this.formBuildBaseObj = this.screenTB.formEdit(this.caseid);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      console.log(data);
      if (data.status == 'success') {
        this.buildData = data.data;

        // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        // subEve.invokeEvent.subscribe((value) => {
        //   this.buildForm(value.some.formItems);
        // });
        // this.buildForm(this.buildData);
        let apiData;
        if (this.caseid == 'TravelDetails' || this.caseid == 'OnBoardingDetails' || this.caseid == 'Passport') {
          apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId }, "languageCode": "en" };
        } else if (this.caseid == 'PreviousPassport' || this.caseid == 'PreviousCompanyDetails') {

          apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId, dataId: this.prePassDataId }, "languageCode": "en" };
        } else {
          apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId }, "languageCode": "en" };
        }
        this.service.getFormData(apiData).subscribe(getFormDataResp => {
          console.log(getFormDataResp)
          if (getFormDataResp.status == 'success') {
            this.getFormRespData = getFormDataResp.data;
            let formGroups = this.buildData.fieldGroup;
            formGroups.filter(formGroupsData => {
              let formFields = formGroupsData.FieldList;
              formFields.map((resp, index) => {
                this.getFormRespData.map((formRespData, dialogIndex) => {
                  let dialogRes: any = formRespData;
                  console.log(dialogRes)
                  ///////////////// Multiple Values Check /////////////////////////
                  if (dialogRes.length) {
                    dialogRes.map((dialogArrResp, index) => {
                      Object.keys(dialogArrResp).map(key => {
                        let obj = {
                          fieldKey: key,
                          values: dialogArrResp[key]
                        }
                        console.log(obj.values)
                        if (typeof obj.values == 'object' && obj.values != null) {
                          if (resp.fieldType === 'rangeDateTime' && (resp.fieldType == obj.values.fieldType)) {
                            resp.value = obj.values.value.split(',');
                          } else if (resp.fieldType === 'fileDoc' && (resp.fieldType == obj.values.fieldType)) {
                            let docJson = {};
                            docJson[resp.fieldColumn] = resp.value;
                            this.service.files = docJson;
                          } else if ((resp.fieldType == obj.values.fieldType) && (resp.fieldColumn == obj.values.fieldColumn)) {
                            resp.value = obj.values.value;
                          }
                        }
                      })
                    })
                  }
                  /////////////////////////////////Single Value Check ////////////////////////////
                  else {
                    Object.keys(dialogRes).map(key => {
                      let obj = {
                        fieldKey: key,
                        values: dialogRes[key]
                      }
                      console.log(obj.values, resp)
                      if (typeof obj.values == 'object' && obj.values != null) {
                        if (resp.fieldType === 'rangeDateTime' && (resp.fieldType == obj.values.fieldType)) {
                          resp.value = obj.values.value.split(',');
                        } else if (resp.fieldType === 'fileDoc' && (resp.fieldType == obj.values.fieldType)) {
                          let docJson = {};
                          docJson[resp.fieldColumn] = resp.value;
                          this.service.files = docJson;
                        } else if ((resp.fieldType == obj.values.fieldType) && (resp.fieldColumn == obj.values.fieldColumn)) {
                          resp.value = obj.values.value;
                        }
                      }
                    })
                  }
                })
              })
            })
            let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData, additionalData: this.dialogData };
                let changed = eventCalls[preBuildEvFn](param);
                this.buildData = changed.formItems;
                this.buttonData = changed.buttonData;
                this.cancelButton = changed.cancelButton;

              }
            }
            setTimeout(() => {
              let buildFields = this.qcs.buildFields(this.buildData, this.formBuildBaseObj.showFields);
              this.workFlowData.map(workFlowResp => {
                if (workFlowResp.formFields != null && workFlowResp.formFields.length) {
                  this.gfService.fieldManage(workFlowResp.formFields,buildFields);
                }
              })
              
              buildFields.map(resp => {
                  if (resp.hasOwnProperty('readonly')) {
                      delete resp.readonly;
                  } else {
                      resp['readonly'] = true;
                  }
              })
              this.questions = buildFields;
              let buildData =  this.qcs.buildControls(buildFields);
              this.form = buildData;
              let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
              if (postBuildEvFn != '') {
                const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
                if (eventCalls[postBuildEvFn]) {
                  let param = { formId: this.formBuildBaseObj.formId, formItems: this.form };
                  let changed = eventCalls[postBuildEvFn](param);
                  // this.questions = changed.rawData;
                }
              }
            }, this.config.FORM_LOADING_SEC);
            // console.log(fieldData)
            //console.log(fieldData, this.workFlowData);
            // this.workFlowData.map(workFlowResp => {
            //   if (workFlowResp.formFields != null && workFlowResp.formFields.length) {
            //     this.gfService.fieldManage(workFlowResp.formFields, fieldData);
            //   }
            // })
            // fieldData.map(resp => {
            //   if (resp.hasOwnProperty('readonly')) {
            //     delete resp.readonly;
            //   } else {
            //     resp['readonly'] = true;
            //   }
            // })
            //      console.log(this.questions)
            // this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
            // this.form = this.qcs.toFormGroup(this.questions);
            // // console.log(this.form);
            // let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            // if (postBuildEvFn != '') {
            //   const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
            //   if (eventCalls[postBuildEvFn]) {
            //     let param = { formId: this.formBuildBaseObj.formId, formItems: this.form };
            //     let changed = eventCalls[postBuildEvFn](param);
            //   }
            // }
          }
        });
      }

    })
  }

  constructor(public dialogRef: MatDialogRef<ProfiledialogeditComponent>,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    public gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private alert: AlertService,
    private route: ActivatedRoute,
    private config: Constants,
    private contractservice: ContractService) {

  }

  // buildForm(formData) {
  //   questions => [] = [];
  //   this.questions.length = 0;
  //   this.buildData = formData;
  //   let fieldData = [];
  //   let fieldGroupData = [];
  //   let fieldGroupIdData = [];

  //   /////// To Get fieldGroupId ///////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
  //     this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
  //   }

  //   /////// To Get FieldList /////////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     for (var j = 0; j < this.fieldGroupId.length; j++) {
  //       if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
  //         for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
  //           let pushData;
  //           pushData = this.buildData.fieldGroup[i].FieldList[k];
  //           pushData.visible = false;
  //           if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
  //             pushData.visible = true;
  //           }
  //           if (pushData.fieldType === 'shortText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'currencyText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'calcText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'text') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'simpleListMultiSelect') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'singleSelectOption') {
  //             let options = [
  //               { key: 'yes', value: 'Yes' },
  //               { key: 'no', value: 'No' },
  //             ]
  //             pushData.additionalMetaData = options;
  //             fieldData.push(new CheckboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'radio') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceListMulti') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileImage') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'date') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'dateTime') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'rangeDateTime') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileDoc') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'internationalPhoneNumber') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //         }
  //       }
  //     }
  //   }

  //   console.log(fieldData)
  //   // let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId }, "languageCode": "en" };
  //   // this.service.getFormData(apiData).subscribe(resp =>{
  //   //   console.log(resp,fieldData)
  //   // })
  //   let apiData;
  //   if (this.caseid == 'TravelDetails' || this.caseid == 'OnBoardingDetails' || this.caseid == 'Passport') {
  //     apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId }, "languageCode": "en" };
  //   } else if (this.caseid == 'PreviousPassport' || this.caseid == 'PreviousCompanyDetails') {

  //     apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId, dataId: this.prePassDataId }, "languageCode": "en" };
  //   } else {
  //     apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId }, "languageCode": "en" };
  //   }
  //   this.service.getFormData(apiData).subscribe(getFormDataResp => {
  //     if (getFormDataResp.status == 'success') {
  //       this.getFormRespData = getFormDataResp.data;
  //       fieldData.map((resp, index) => {
  //         this.getFormRespData.map((formRespData, dialogIndex) => {
  //           let dialogRes: any = formRespData;
  //           /////////////////Multiple Values Check /////////////////////////
  //           if (dialogRes.length) {
  //             dialogRes.map((dialogArrResp, index) => {
  //               Object.keys(dialogArrResp).map(key => {
  //                 let obj = {
  //                   fieldKey: key,
  //                   values: dialogArrResp[key]
  //                 }

  //                 if (typeof obj.values == 'object' && obj.values != null) {
  //                   if (resp.fieldType === 'rangeDateTime' && (resp.fieldType == obj.values.fieldType)) {
  //                     resp.value = obj.values.value.split(',');
  //                   } else if (resp.fieldType === 'fileDoc' && (resp.fieldType == obj.values.fieldType)) {
  //                     let docJson = {};
  //                     docJson[resp.fieldColumn] = resp.value;
  //                     this.service.files = docJson;
  //                   } else if ((resp.fieldType == obj.values.fieldType) && (resp.fieldColumn == obj.values.fieldColumn)) {
  //                     resp.value = obj.values.value;
  //                   }
  //                 }
  //               })
  //             })
  //           }
  //           /////////////////////////////////Single Value Check ////////////////////////////
  //           else {
  //             Object.keys(dialogRes).map(key => {
  //               let obj = {
  //                 fieldKey: key,
  //                 values: dialogRes[key]
  //               }

  //               if (typeof obj.values == 'object' && obj.values != null) {
  //                 if (resp.fieldType === 'rangeDateTime' && (resp.fieldType == obj.values.fieldType)) {
  //                   resp.value = obj.values.value.split(',');
  //                 } else if (resp.fieldType === 'fileDoc' && (resp.fieldType == obj.values.fieldType)) {
  //                   let docJson = {};
  //                   docJson[resp.fieldColumn] = resp.value;
  //                   this.service.files = docJson;
  //                 } else if ((resp.fieldType == obj.values.fieldType) && (resp.fieldColumn == obj.values.fieldColumn)) {
  //                   resp.value = obj.values.value;
  //                 }
  //               }
  //             })
  //           }
  //         })
  //       })

  //       // console.log(fieldData)
  //       //console.log(fieldData, this.workFlowData);
  //       this.workFlowData.map(workFlowResp => {
  //         if (workFlowResp.formFields != null && workFlowResp.formFields.length) {
  //           this.gfService.fieldManage(workFlowResp.formFields, fieldData);
  //         }
  //       })
  //       fieldData.map(resp => {
  //         if (resp.hasOwnProperty('readonly')) {
  //           delete resp.readonly;
  //         } else {
  //           resp['readonly'] = true;
  //         }
  //       })
  //       this.questions = fieldData;
  //       //      console.log(this.questions)
  //       this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
  //       this.form = this.qcs.toFormGroup(this.questions);
  //       // console.log(this.form);
  //       let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
  //       if (postBuildEvFn != '') {
  //         const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
  //         if (eventCalls[postBuildEvFn]) {
  //           let param = { formId: this.formBuildBaseObj.formId, formItems: this.form };
  //           let changed = eventCalls[postBuildEvFn](param);
  //         }
  //       }
  //     }
  //   });
  // }

  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {
    this.form.patchValue({ resourceId: this.resourceId });
    this.form.patchValue({ userType: "Resource" });
    this.form.patchValue({ resDepId: this.resourceId });
    //this.form.patchValue({ contractId:this.contractId }); /// contractId Patch
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems, questions: this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
      }
    }
    if (this.form.valid) {
      if (status != "DeActivated") {

        Object.keys(this.form.controls).map(fieldArrData => {
          let fieldKey = fieldArrData;
          let fieldData = this.form.controls[fieldKey]
          for (var question of this.questions) {
            if (question.fieldType === 'date') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd');
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            } else if (question.fieldType === 'dateTime') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd hh:mm:ss');
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            } else if (question.fieldType === 'rangeDateTime') {
              let currentDate = new DatePipe('en-us');
              let rangeDateArr = this.form.controls[question.fieldColumn].value;
              // rangeDateArr.map(resp => {
              //   currentDate.transform(resp);
              // });
              let final = rangeDateArr;
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            }
          }
        });
        let dataId;
        this.getFormRespData.map(dataIdresp => {
          dataId = dataIdresp.dataId
        });;
        this.service.updateFormData(this.form.value, this.formBuildBaseObj.formId, dataId).subscribe(data => {
          this.alertMsg(data);
          if (data.status == 'success') {
            // var apiData = { "formId": this.formBuildBaseObj.formId, contractId: this.contractId, "languageCode": "en" };
            let apiData;
            if (this.caseid == 'TravelDetails' || this.caseid == 'OnBoardingDetails' || this.caseid == 'Passport') {
              apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId }, "languageCode": "en" };
            } else if (this.caseid == 'PreviousPassport' || this.caseid == 'PreviousCompanyDetails') {

              apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { resId: this.resourceId, dataId: this.prePassDataId }, "languageCode": "en" };
            } else {
              apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId }, "languageCode": "en" };
            }
            this.service.getFormData(apiData).subscribe(resp => {
              if (resp.status == 'success')
                this.dialogRef.close(resp.data);
            })
          }
        })
      }
      else {
        this.alert.error("Please Select Active value");
      }
    } else if (this.form.status == "DISABLED") {
      this.dialogRef.close();
    }
    else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
      this.alert.error("Please fill required fields.");
    }

  }
  alertMsg(resp) {
    let message;
    if (Object.keys(resp).length == 0) {
      message = 'Something went wrong...'
    } else {
      message = resp.message;
    }
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

}
