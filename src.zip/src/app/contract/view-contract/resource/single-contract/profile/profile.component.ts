import { Component, OnInit, ElementRef, Input,Output,EventEmitter,ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContractService } from '../../../../services/contract.service';
import { GlobalFunctionService } from '../../../../../shared/services/global-function.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DependentdialogComponent } from '../../../../view-contract/resource/single-contract/dependentdialog/dependentdialog.component';
import { DependentdialogeditComponent } from '../../../../view-contract/resource/single-contract/dependentdialogedit/dependentdialogedit.component';
import { ProfiledialogComponent } from '../../../../view-contract/resource/single-contract/profiledialog/profiledialog.component';
import { ProfiledialogeditComponent } from '../../../../view-contract/resource/single-contract/profiledialogedit/profiledialogedit.component';
import { FormBuildBaseService } from '../../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../../shared/common/form-build-functions.service';
import { ScreenTemplateJsonBuilder } from '../../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalformService } from '../../../../../shared/services/globalform.service';
import { AuthGuardService } from '../../../../../shared/guard/auth-guard.service';
import { DeldialogdependentComponent } from '../../../../view-contract/resource/single-contract/dependentdialog/deldialogdependent/deldialogdependent.component';
import { Constants } from '../../../../../constants';
import { DialogComponent } from '../../dialog/dialog.component';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  @Input() contractId: any;
  @Input() workFlowData: any;
  @Input() resourceId: any;
  @Input() personalDetails: any;
  @Input() projectDetails: any;
  @Input() mergeContractShowFields: any;
  @Output() outputData = new EventEmitter();
  @Input() hostLocation;
  personalShowFields: any;
  caseid: any;
  userToken;
  objectKeys = Object.keys;
  travelDetails: any = [];
  passportDetails: any = [];
  previousPassportDetails:any = [];
  professionalDetails: any = [];
  PreviousCompanyDetails:any = [];
  visaDetails: any = [];
  onBoardingDetails: any = [];
  reqPreview_value: any = [];
  testData: any = [];
  visaTypeFieldValue: any;
  personalDet_Value: any = [];
  passPreview: any = [];
  ///// button disable /////////
  deptDisabledButton: any;
  passDisabledButton: any;
  travelDisabledButton: any = true;
  professionalDisabledButton: any = true;
  visaDisabledButton: any = true;
  // workFlowData: any;
  formBuildBaseObj: any;
  showFieldsList: any;
  showFieldsListDep: any;
  showFieldsListOnBoarding: any;
  projectDet: any = [];
  ////// ShowFields ////////////
  showFieldsListPassport: any;
  showFieldsListPreviousPassport :any;
  showFieldsListPreviousCompanyDetails :any;
  showFieldsListTravel: any;
  showFieldsListProfessional: any;
  showFieldsListVisa: any;

  profilePic: any;
  deldiaglogDepDetails: MatDialogRef<DeldialogdependentComponent>;
  dialogRefDetails: MatDialogRef<DependentdialogComponent>;
  dialogRefDetailsEdit: MatDialogRef<DependentdialogeditComponent>;
  dialogRefPassportDetails: MatDialogRef<ProfiledialogComponent>;
  dialogRefPassportDetailsEdit: MatDialogRef<ProfiledialogeditComponent>;
  personalDialogEdit: MatDialogRef<DialogComponent>;
  recordId;
  resRecordId;

  constructor(
    private route: ActivatedRoute
    , private contractService: ContractService,
    public gfService: GlobalFunctionService,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private el: ElementRef,
    private authGuardService: AuthGuardService,
    public config: Constants,
    private service: GlobalformService
  ) {

    let formBuildBaseObjPersonal = this.screenTB.formView('personalDetails');
    this.personalShowFields = Array.from(Object.keys(formBuildBaseObjPersonal.showFields));

    this.recordId = this.gfService.encryptDecryptFun('atob', this.route.snapshot.params.id);
    this.resRecordId = this.gfService.encryptDecryptFun('atob', this.route.snapshot.params.resDataid);
    let apiData;
     let formBuildBaseObjPassport = this.screenTB.formView('PassportDetails');
    apiData = { "formId": formBuildBaseObjPassport.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
    this.showFieldsListPassport = Array.from(Object.keys(formBuildBaseObjPassport.showFields));
    this.service.getFormData(apiData).subscribe(resp => {
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjPassport.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjPassport.formId,resp:resp.data  };
            let changed = eventCalls[preBuildEvFn](param);
            this.passportDetails = this.gfService.buildView(changed.resp,'')[0];
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
       
    })

    let formBuildBaseObjPreviousPassport = this.screenTB.formView('PreviousPassport');
    apiData = { "formId": formBuildBaseObjPreviousPassport.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
    this.showFieldsListPreviousPassport = Array.from(Object.keys(formBuildBaseObjPreviousPassport.showFields));
    this.service.getFormData(apiData).subscribe(resp => {
      console.log(resp);
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjPreviousPassport.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjPreviousPassport.formId,resp:resp.data  };
            let changed = eventCalls[preBuildEvFn](param);
            this.previousPassportDetails =this.gfService.buildView(changed.resp,'');
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
       
    })

     let formBuildBaseObjTravel = this.screenTB.formView('TravelDetails');
    this.showFieldsListTravel = Array.from(Object.keys(formBuildBaseObjTravel.showFields));
    apiData = { "formId": formBuildBaseObjTravel.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
    this.service.getFormData(apiData).subscribe(resp => {
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjTravel.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjTravel.formId,resp:resp.data  };
            let changed = eventCalls[preBuildEvFn](param);
            this.travelDetails = this.gfService.buildView(changed.resp,'')[0];
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
        // this.travelDetails = this.getFormrequirementBuild(resp);
    })


    let formBuildBaseObjProfessional = this.screenTB.formView('ProfessionalDetails');
    apiData = { "formId": formBuildBaseObjProfessional.formId, "filterString": { dataId: this.resRecordId }, "languageCode": "en" };
    this.showFieldsListProfessional = Array.from(Object.keys(formBuildBaseObjProfessional.showFields));
    this.service.getFormData(apiData).subscribe(resp => {
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjProfessional.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjProfessional.formId,resp:resp.data  };
            let changed = eventCalls[preBuildEvFn](param);
            this.professionalDetails = this.gfService.buildView(changed.resp,'')[0];
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
    })

    let formBuildBaseObjPreviousCompany = this.screenTB.formView('PreviousCompanyDetails');
    apiData = { "formId": formBuildBaseObjPreviousCompany.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
    this.showFieldsListPreviousCompanyDetails = Array.from(Object.keys(formBuildBaseObjPreviousCompany.showFields));
    this.service.getFormData(apiData).subscribe(resp => {
      console.log(resp);
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjPreviousCompany.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjPreviousCompany.formId,resp:resp.data  };
            let changed = eventCalls[preBuildEvFn](param);
            this.PreviousCompanyDetails = this.gfService.buildView(changed.resp,'');
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
       
    })
   let formBuildBaseObjVisa = this.screenTB.formView('VisaDetails');
    apiData = { "formId": formBuildBaseObjVisa.formId, "filterString": { dataId: this.resRecordId }, "languageCode": "en" };
    this.showFieldsListVisa = Array.from(Object.keys(formBuildBaseObjVisa.showFields));
    this.service.getFormData(apiData).subscribe(resp => {
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjVisa.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjVisa.formId,resp:resp.data, additionalDetails: this.projectDetails  };
            let changed = eventCalls[preBuildEvFn](param);
            this.visaDetails = this.gfService.buildView(changed.resp,'')[0];
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
    })

    let formBuildBaseObjOnBoarding = this.screenTB.formView('OnBoardingDetails');
    apiData = { "formId": formBuildBaseObjOnBoarding.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
    this.showFieldsListOnBoarding = Array.from(Object.keys(formBuildBaseObjOnBoarding.showFields));
    this.service.getFormData(apiData).subscribe(resp => {
      if (resp.status == 'success') {
        let preBuildEvFn = formBuildBaseObjOnBoarding.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: formBuildBaseObjOnBoarding.formId,resp:resp.data  };
            let changed = eventCalls[preBuildEvFn](param);
            this.onBoardingDetails = this.gfService.buildView(changed.resp,'')[0];
            // this.innerTemplate = changed.innerTemplate;
            // this.breadcrumbs = changed.breadcrumbs;
            // this.subTitle = changed.subTitle;
          }
        }
      }
        // this.onBoardingDetails = this.getFormrequirementBuild(resp);
    })
 
    
  }
  personalShowFieldsList:any;
  showFieldsListPersonal:any;
  ngOnInit() {


  }
  ngOnChanges() {

  }

 

  addPassport() {
    this.dialogRefPassportDetails = this.dialog.open(ProfiledialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetails.componentInstance.caseid = 'Passport';
    this.dialogRefPassportDetails.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetails.componentInstance.workFlowData = this.workFlowData;
    // To get data from json-builder
    this.dialogRefPassportDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjPassport = this.screenTB.formView('PassportDetails');
        let apiData = { "formId": formBuildBaseObjPassport.formId, "filterString": { resDepId: this.resRecordId }, "languageCode": "en" };
            let preBuildEvFn = formBuildBaseObjPassport.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjPassport.formId,resp:resp.data  };
                let changed = eventCalls[preBuildEvFn](param);
                this.passportDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
           
        // this.passPreview = this.requirementBuild(resp);
        // let noOfpassPort = this.passPreview.find(item => item.fieldKey == 'passportDetails');
        // if (Object.keys(noOfpassPort.values).length) {
        //   this.passDisabledButton = true;
        // } else {
        //   this.passDisabledButton = false;
        // }

      }
    });
  }

  addPreviousPassport(){
    this.dialogRefPassportDetails = this.dialog.open(ProfiledialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetails.componentInstance.caseid = 'PreviousPassport';
    this.dialogRefPassportDetails.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetails.componentInstance.workFlowData = this.workFlowData;
    // To get data from json-builder
    this.dialogRefPassportDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjPreviousPassport = this.screenTB.formView('PreviousPassport');
        let apiData = { "formId": formBuildBaseObjPreviousPassport.formId, "filterString": { resDepId: this.resRecordId }, "languageCode": "en" };
            let preBuildEvFn = formBuildBaseObjPreviousPassport.eventHandler.preBuild;
            console.log(preBuildEvFn);
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
              console.log(preBuildEvFn);
                let param = { formId: formBuildBaseObjPreviousPassport.formId,resp:resp.data  };
                let changed = eventCalls[preBuildEvFn](param);
                this.previousPassportDetails = this.previousPassportDetails.concat(this.gfService.buildView(changed.resp,''));
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
           
        // this.passPreview = this.requirementBuild(resp);
        // let noOfpassPort = this.passPreview.find(item => item.fieldKey == 'passportDetails');
        // if (Object.keys(noOfpassPort.values).length) {
        //   this.passDisabledButton = true;
        // } else {
        //   this.passDisabledButton = false;
        // }

      }
    });
  }
  addTravel() {
    this.dialogRefPassportDetails = this.dialog.open(ProfiledialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetails.componentInstance.caseid = 'TravelDetails';
    this.dialogRefPassportDetails.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetails.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjTravel = this.screenTB.formView('TravelDetails');
       let apiData = { "formId": formBuildBaseObjTravel.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
            let preBuildEvFn = formBuildBaseObjTravel.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjTravel.formId,resp:resp.data  };
                let changed = eventCalls[preBuildEvFn](param);
                this.travelDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
            // this.travelDetails = this.getFormrequirementBuild(resp);
        
      }
    })
  }
  addProfessional() {
    this.dialogRefPassportDetails = this.dialog.open(ProfiledialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetails.componentInstance.caseid = 'ProfessionalDetails';
    this.dialogRefPassportDetails.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetails.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjProfessional = this.screenTB.formView('ProfessionalDetails');
       let apiData = { "formId": formBuildBaseObjProfessional.formId, "filterString": { dataId: this.resRecordId }, "languageCode": "en" };
            let preBuildEvFn = formBuildBaseObjProfessional.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjProfessional.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.professionalDetails =this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
        
      }
    })
  }
  addPreviousCompany(){
    this.dialogRefPassportDetails = this.dialog.open(ProfiledialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetails.componentInstance.caseid = 'PreviousCompanyDetails';
    this.dialogRefPassportDetails.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetails.componentInstance.workFlowData = this.workFlowData;
    // To get data from json-builder
    this.dialogRefPassportDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjPreviousPassport = this.screenTB.formView('PreviousCompanyDetails');
        let apiData = { "formId": formBuildBaseObjPreviousPassport.formId, "filterString": { resDepId: this.resRecordId }, "languageCode": "en" };
            let preBuildEvFn = formBuildBaseObjPreviousPassport.eventHandler.preBuild;
            console.log(preBuildEvFn);
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
              console.log(preBuildEvFn);
                let param = { formId: formBuildBaseObjPreviousPassport.formId,resp:resp.data  };
                let changed = eventCalls[preBuildEvFn](param);
                this.PreviousCompanyDetails = this.PreviousCompanyDetails.concat(this.gfService.buildView(changed.resp,''));
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
           
        // this.passPreview = this.requirementBuild(resp);
        // let noOfpassPort = this.passPreview.find(item => item.fieldKey == 'passportDetails');
        // if (Object.keys(noOfpassPort.values).length) {
        //   this.passDisabledButton = true;
        // } else {
        //   this.passDisabledButton = false;
        // }

      }
    });
  }
  addVisa() {
    this.dialogRefPassportDetails = this.dialog.open(ProfiledialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetails.componentInstance.caseid = 'VisaDetails';
    this.dialogRefPassportDetails.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetails.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetails.componentInstance.dialogData = this.projectDetails;
    this.dialogRefPassportDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjVisa = this.screenTB.formView('VisaDetails');
       let apiData = { "formId": formBuildBaseObjVisa.formId, "filterString": { dataId: this.resRecordId }, "languageCode": "en" };
            let preBuildEvFn = formBuildBaseObjVisa.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjVisa.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.visaDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            
          }
        
      }
    })
  }
  addOnBoardingDetails() {
    this.dialogRefPassportDetails = this.dialog.open(ProfiledialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetails.componentInstance.caseid = 'OnBoardingDetails';
    this.dialogRefPassportDetails.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetails.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjOnBoarding = this.screenTB.formView('OnBoardingDetails');
        let apiData = { "formId": formBuildBaseObjOnBoarding.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
            let preBuildEvFn = formBuildBaseObjOnBoarding.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjOnBoarding.formId,resp:resp.data  };
                let changed = eventCalls[preBuildEvFn](param);
                this.onBoardingDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
            // this.onBoardingDetails = this.getFormrequirementBuild(resp);
      }
    })
  }

  ////////// Update //////////////
  updateTravel() {
    this.dialogRefPassportDetailsEdit = this.dialog.open(ProfiledialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetailsEdit.componentInstance.caseid = 'TravelDetails'; // To get data from json-builder
    this.dialogRefPassportDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetailsEdit.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetailsEdit.componentInstance.dialogData = this.travelDetails;
    this.dialogRefPassportDetailsEdit.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjTravel = this.screenTB.formView('TravelDetails');
            let preBuildEvFn = formBuildBaseObjTravel.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjTravel.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.travelDetails = this.gfService.buildView(changed.resp,'')[0];
              }
            }
          
            // this.travelDetails = this.getFormrequirementBuild(resp);
        
      }
    })

  }
  updateProfessional() {
    this.dialogRefPassportDetailsEdit = this.dialog.open(ProfiledialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetailsEdit.componentInstance.caseid = 'ProfessionalDetails'; // To get data from json-builder
    this.dialogRefPassportDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetailsEdit.componentInstance.resourceId = this.resRecordId
    this.dialogRefPassportDetailsEdit.componentInstance.dialogData = this.professionalDetails;
    this.dialogRefPassportDetailsEdit.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjProfessional = this.screenTB.formView('ProfessionalDetails');
            let preBuildEvFn = formBuildBaseObjProfessional.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjProfessional.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.professionalDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
      }
    })
  }

  updatepreviousCompany(data){
    console.log(data);
    let dataId = data.find(items => items.fieldKey == 'dataId');
    this.dialogRefPassportDetailsEdit = this.dialog.open(ProfiledialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetailsEdit.componentInstance.caseid = 'PreviousCompanyDetails'; // To get data from json-builder
    this.dialogRefPassportDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetailsEdit.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetailsEdit.componentInstance.prePassDataId = dataId.values;
    this.dialogRefPassportDetailsEdit.componentInstance.dialogData = this.PreviousCompanyDetails;
    this.dialogRefPassportDetailsEdit.componentInstance.workFlowData = this.workFlowData;
    console.log(dataId.values)
    this.dialogRefPassportDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjPreviousPassport = this.screenTB.formView('PreviousCompanyDetails');
            let preBuildEvFn = formBuildBaseObjPreviousPassport.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjPreviousPassport.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.PreviousCompanyDetails = (this.gfService.buildView(changed.resp,{ 'oldData': this.PreviousCompanyDetails, 'operation': 'edit' }));
              }
            }
          
            // this.travelDetails = this.getFormrequirementBuild(resp);
        
      }
    })
  }
  updateVisa() {
    this.dialogRefPassportDetailsEdit = this.dialog.open(ProfiledialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
      console.log(this.hostLocation);
    this.dialogRefPassportDetailsEdit.componentInstance.caseid = 'VisaDetails'; // To get data from json-builder
    this.dialogRefPassportDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetailsEdit.componentInstance.resourceId = this.resRecordId
    this.dialogRefPassportDetailsEdit.componentInstance.dialogData = this.projectDetails;
    this.dialogRefPassportDetailsEdit.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjVisa = this.screenTB.formView('VisaDetails');
            let preBuildEvFn = formBuildBaseObjVisa.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjVisa.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.visaDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
        
      }
    })
  }

  updatePassport() {
    //this.service.depDataIdEdit = dependent;
    // let resDataId;
    // let depDataId;
    // for (let data of loopdata) {
    //   if (data.fieldKey === "resDataId") {
    //     resDataId = data.values;
    //   }
    // }
    // let depDataId;
    // for (let data of dependent) {
    //   if (data.fieldKey === "depDataId") {
    //     depDataId = data.values;
    //   }
    // }
    this.dialogRefPassportDetailsEdit = this.dialog.open(ProfiledialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetailsEdit.componentInstance.caseid = 'Passport'; // To get data from json-builder
    this.dialogRefPassportDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetailsEdit.componentInstance.resourceId = this.resRecordId
    //this.dialogRefDetailsEdit.componentInstance.depDataId =depDataId
    this.dialogRefPassportDetailsEdit.componentInstance.dialogData = this.passportDetails;
    this.dialogRefPassportDetailsEdit.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjPassport = this.screenTB.formView('PassportDetails');
            let preBuildEvFn = formBuildBaseObjPassport.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjPassport.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.passportDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
           
        // this.passPreview = this.requirementBuild(resp);
        // let noOfpassPort = this.passPreview.find(item => item.fieldKey == 'passportDetails');
        // if (Object.keys(noOfpassPort.values).length) {
        //   this.passDisabledButton = true;
        // } else {
        //   this.passDisabledButton = false;
        // }

      }
    });
  }

  updatepreviousPassport(data){
    console.log(data);
    let dataId = data.find(items => items.fieldKey == 'dataId');
    this.dialogRefPassportDetailsEdit = this.dialog.open(ProfiledialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetailsEdit.componentInstance.caseid = 'PreviousPassport'; // To get data from json-builder
    this.dialogRefPassportDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetailsEdit.componentInstance.resourceId = this.resRecordId;
    this.dialogRefPassportDetailsEdit.componentInstance.prePassDataId = dataId.values;
    this.dialogRefPassportDetailsEdit.componentInstance.dialogData = this.previousPassportDetails;
    this.dialogRefPassportDetailsEdit.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjPreviousPassport = this.screenTB.formView('PreviousPassport');
            let preBuildEvFn = formBuildBaseObjPreviousPassport.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjPreviousPassport.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.previousPassportDetails = (this.gfService.buildView(changed.resp,{ 'oldData': this.previousPassportDetails, 'operation': 'edit' }));
              }
            }
          
            // this.travelDetails = this.getFormrequirementBuild(resp);
        
      }
    })
  }
  updateOnBoardingDetails() {
    this.dialogRefPassportDetailsEdit = this.dialog.open(ProfiledialogeditComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefPassportDetailsEdit.componentInstance.caseid = 'OnBoardingDetails'; // To get data from json-builder
    this.dialogRefPassportDetailsEdit.componentInstance.contractId = this.recordId
    this.dialogRefPassportDetailsEdit.componentInstance.resourceId = this.resRecordId
    this.dialogRefPassportDetailsEdit.componentInstance.dialogData = this.onBoardingDetails;
    this.dialogRefPassportDetailsEdit.componentInstance.workFlowData = this.workFlowData;
    this.dialogRefPassportDetailsEdit.afterClosed().subscribe(resp => {
      if (resp) {
        let formBuildBaseObjOnBoarding = this.screenTB.formView('OnBoardingDetails');
            let preBuildEvFn = formBuildBaseObjOnBoarding.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: formBuildBaseObjOnBoarding.formId,resp:resp  };
                let changed = eventCalls[preBuildEvFn](param);
                this.onBoardingDetails = this.gfService.buildView(changed.resp,'')[0];
                // this.innerTemplate = changed.innerTemplate;
                // this.breadcrumbs = changed.breadcrumbs;
                // this.subTitle = changed.subTitle;
              }
            }
          
            // this.onBoardingDetails = this.getFormrequirementBuild(resp);
      }
    })
  }
  personalInfoEdit() {
    this.service.depDataIdEdit = this.personalDet_Value.filter(items => items.fieldKey != 'DependentList' && items.fieldKey != 'passportDetails' && items.fieldKey != 'noOfDependents');
    this.personalDialogEdit = this.dialog.open(DialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.personalDialogEdit.componentInstance.caseid = 'ContractResource'; // To get data from json-builder
    // this.personalDialogEdit.componentInstance.contractId =this.resContractId;
    // this.personalDialogEdit.componentInstance.resDataId =resDataId;
    this.personalDialogEdit.componentInstance.contractId = this.recordId
    this.personalDialogEdit.componentInstance.resourceId = this.resRecordId
    this.personalDialogEdit.componentInstance.workFlowData = this.workFlowData;
    this.personalDialogEdit.afterClosed().subscribe(resp => {
      if (resp) {
        // console.log(resp);
        // this.personalDet_Value = this.requirementBuild(resp);
        this.outputData.emit(resp);
      }
    })
  }
  // newBuildFun(data,arrAlterData) {
  //   let finalData:any = [];
  //    data.map(resp =>{
  //      let innerArr = [];
  //      let reqPreview_value = [];
  //      let innerJson: any = {};
  //      let resourceDependentName;
  //      Object.keys(resp).map(key =>{
  //        let obj = {
  //          fieldKey:key,
  //          values:resp[key]
  //        }
  //        if (obj.fieldKey === 'proflePic' && (obj.values != '' && obj.values != null)) {
  //          if(obj.values.value != null){
  //         let imagePath = this.config.M_RESIZE_IMAGE_PATH;
  
  //         if(this.authGuardService.getLoginUser()){
  //           this.userToken = this.authGuardService.getLoginUser().tokenId;
  //         }
  //         this.profilePic = imagePath + obj.values.value+'?Token='+this.userToken;
  //          }else {
  //           this.profilePic = 'assets/user.jpg';
  //         }
  //       } else if (obj.fieldKey == 'proflePic' && (obj.values == '' || obj.values == null)) {
  //         this.profilePic = './assets/user.jpg';
  //       }
  //        innerArr.push(obj);
  //      })
      
  //      finalData.push(innerArr);
  //    })
  //    let innerFinalData;
  //    if (arrAlterData != '') {
  //     if (arrAlterData.operation == 'edit') {
  //       innerFinalData = arrAlterData.oldData;
  //       finalData.map((finalData) => {
  //         finalData.map(finalDataResp => {
  
  //           innerFinalData.map((alterResp, index) => {
  //             alterResp.map((innerResp) => {
  //               if (finalDataResp.fieldKey == 'dataId' && innerResp.fieldKey == 'dataId') {
  //                 if (finalDataResp.values == innerResp.values) {
  //                   let filterAlterResp = finalData.filter(items => {
  //                     if (typeof items.values == 'object' && items.values != null) {
  //                       return items;
  //                     }
  //                   })
  //                   filterAlterResp.map(resp => {
  
  //                     alterResp.map(innerResp => {
  //                       if (typeof innerResp.values == 'object' && innerResp.values != null) {
  //                         if (resp.fieldKey == innerResp.fieldKey) {
  //                           innerResp.values = resp.values;
  //                         }
  //                       }
  //                     })
  //                   })
  //                   innerFinalData[index] = alterResp;
  //                 }
  //               }
  //             })
  //           })
  //         })
  //       })
  //       finalData = innerFinalData;
  //     } else
  //     if (arrAlterData.operation == 'add') {
  //       // finalData = arrAlterData.oldData.push(finalData[0]);
  //       // arrAlterData.oldData.push(finalData);
  //       // if(arrAlterData.oldData.length > 0)
  //       arrAlterData.oldData.push(finalData[0]);
  //       finalData =  arrAlterData.oldData;
  //     }
  //   } else {
  //     finalData = finalData;
  //   }
  //    return finalData;
  // }

}
