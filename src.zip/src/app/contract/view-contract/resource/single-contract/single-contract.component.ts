import { Component, OnInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContractService } from '../../../services/contract.service';
import { GlobalFunctionService } from '../../../../shared/services/global-function.service';
import { MatDialog, MatDialogRef, MatTabChangeEvent } from '@angular/material';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DependentdialogComponent } from '../../../view-contract/resource/single-contract/dependentdialog/dependentdialog.component';
import { DependentdialogeditComponent } from '../../../view-contract/resource/single-contract/dependentdialogedit/dependentdialogedit.component';
import { ProfiledialogComponent } from '../../../view-contract/resource/single-contract/profiledialog/profiledialog.component';
import { ProfiledialogeditComponent } from '../../../view-contract/resource/single-contract/profiledialogedit/profiledialogedit.component';
import { FormBuildBaseService } from '../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../shared/common/form-build-functions.service';
import { ScreenTemplateJsonBuilder } from '../../../../shared/common/screentemplate-jsonbuilder';
import { GlobalformService } from '../../../../shared/services/globalform.service';
import { AuthGuardService } from '../../../../shared/guard/auth-guard.service';
import { DeldialogdependentComponent } from '../../../view-contract/resource/single-contract/dependentdialog/deldialogdependent/deldialogdependent.component';
import { Constants } from '../../../../constants';
import { DialogComponent } from '../dialog/dialog.component';
import { DatePipe } from '@angular/common';
import { AlertService } from '../../../../shared/services/alert-service.service';

@Component({
  selector: 'app-single-contract',
  templateUrl: './single-contract.component.html',
  styleUrls: ['./single-contract.component.scss']
})
export class SingleContractComponent implements OnInit {

  finalDataa: any = [];
  personalDet_Value: any = [];
  params;
  form_title;
  workFlowState: boolean = true;
  // reqPreview: any = [];
  testData: any = [];
  //projectDet: any = [];
  projectDet_Value: any = [];
  userToken;
  reqPreview_value: any = [];
  hostLocation: any;
  visaTypeFieldValue: any;
  depPreview: any = [];
  passPreview: any = [];
  dProfilePic: any;
  caseid: any;
  objectKeys = Object.keys;
  travelDetails: any = [];
  passportDetails: any = [];
  professionalDetails: any = [];
  visaDetails: any = [];
  onBoardingDetails: any = [];
  recordId: any;
  ///// button disable /////////
  deptDisabledButton: any;
  passDisabledButton: any;
  travelDisabledButton: any = true;
  professionalDisabledButton: any = true;
  visaDisabledButton: any = true;
  workFlowData: any = [];
  formBuildBaseObj: any;
  showFieldsList: any;
  showFieldsListDep: any;
  showFieldsListOnBoarding: any;
  projectDet: any = [];
  ////// ShowFields ////////////
  showFieldsListPassport: any;
  showFieldsListTravel: any;
  showFieldsListProfessional: any;
  showFieldsListVisa: any;

  profilePic: any;
  mergeContractDetails: any = [];
  personalDetails: any = [];
  deldiaglogDepDetails: MatDialogRef<DeldialogdependentComponent>;
  dialogRefDetails: MatDialogRef<DependentdialogComponent>;
  dialogRefDetailsEdit: MatDialogRef<DependentdialogeditComponent>;
  dialogRefPassportDetails: MatDialogRef<ProfiledialogComponent>;
  dialogRefPassportDetailsEdit: MatDialogRef<ProfiledialogeditComponent>;
  personalDialogEdit: MatDialogRef<DialogComponent>;
  resRecordId: any;
  resRecordNo: any;
  resourceArr: any = [];
  noOfDependents: any;
  dependentProfile: any;
  mergeContractShowFields: any;
  constructor(private route: ActivatedRoute,
    private contractService: ContractService,
    public gfService: GlobalFunctionService,
    public dialog: MatDialog,
    private alert: AlertService,
    private _formBuilder: FormBuilder,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private el: ElementRef,
    private authGuardService: AuthGuardService,
    public config: Constants,
    private service: GlobalformService) {
    this.recordId = this.gfService.encryptDecryptFun('atob', this.route.snapshot.params.id);
    this.resRecordId = this.gfService.encryptDecryptFun('atob', this.route.snapshot.params.resDataid);
    let contractShowFields: any;
    this.formBuildBaseObj = this.screenTB.formView('singleResource');
    this.showFieldsList = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    let formBuildBaseObj = this.screenTB.formView('contractResource');
    contractShowFields = Array.from(Object.keys(formBuildBaseObj.showFields));
    if(this.authGuardService.getLoginUser()){
      this.userToken = this.authGuardService.getLoginUser().tokenId;
    }
    let apiData = { "formId": formBuildBaseObj.formId, "filterString": { dataId: this.resRecordId } };
    this.service.getFormData(apiData).subscribe(resp => {
      console.log(resp,apiData)
      let finalArr = [];
      // this.finalArr = (this.getFormRequirementBuild(resp.data,''));
      if (resp.status == 'success')
        resp.data.map(data => {
          let resourceArr = data;

          
          this.resRecordNo = resourceArr.resourceNo;
          this.getWorkFlow(this.resRecordNo);


          let formBuildBaseObj = this.screenTB.formView('personalDetails');
          let personalShowFields = Array.from(Object.keys(formBuildBaseObj.showFields));
          this.mergeContractShowFields = personalShowFields.concat(contractShowFields);
          let apiData = { "formId": formBuildBaseObj.formId, "filterString": { dataId: data.dataId } };
          this.service.getFormData(apiData).subscribe(personalResp => {
            if (personalResp.status == 'success') {
              // this.personalDetails = this.getFormRequirementBuild(personalResp.data, '')[0];
              personalResp.data.map(resp => {
                Object.keys(resourceArr).map(resResp => {
                  if (typeof resourceArr[resResp] != 'object') {
                    Object.keys(resp).map(perResp => {
                      if (resResp == perResp) {
                        resourceArr[resResp] = resp[perResp];
                      } else {
                        //  resourceArr[resResp] = resourceArr[resResp]
                      }
                    })
                  } else {
                    resourceArr[resResp] = resourceArr[resResp]
                  }
                })
              })
              this.resourceArr.push(resourceArr);
              let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
              if (preBuildEvFn != '') {
                const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
                if (eventCalls[preBuildEvFn]) {
                  let param = { formId: this.formBuildBaseObj.formId,resp:this.resourceArr  };
                  let changed = eventCalls[preBuildEvFn](param);
                  let profileVal = changed.profilePic;
                  this.noOfDependents = changed.noOfDependents;
                  this.mergeContractDetails = (this.gfService.buildView(changed.resp, ''))[0];
                  console.log(this.mergeContractDetails,changed,this.resourceArr)
                  this.mergeContractDetails['changeIndicator'] = 0;
                  // let profilePic = this.mergeContractDetails.find(items => items.fieldKey == 'proflePic');
                  // if(profilePic.values.value != null) {
                  //   let loginData = this.authGuardService.getLoginUser();
                  //   if (loginData != null) {
                  //     if (loginData.hasOwnProperty('globalConfiguration')) {
                  //       let imagePath = (loginData.globalConfiguration.imagePath);
                  //       this.profilePic = this.config.API_URL + '/' + imagePath + profilePic.values.value;
                  //     }
                  //   }
                   
                  // } else if(profilePic.values.value == null) {
                  //   this.profilePic = 'assets/user.jpg';
                  // }
                    if (profileVal != null && profileVal != undefined && profileVal != '') {
                        let imagePath = this.config.M_RESIZE_IMAGE_PATH;
                        if(this.authGuardService.getLoginUser()){
                          this.userToken = this.authGuardService.getLoginUser().tokenId;
                        }
                        this.profilePic = imagePath + profileVal+'?Token='+this.userToken;
                    } else {
                      this.profilePic = 'assets/user.jpg';
                    }
      
                
                }
              }
              // let noOfDependents = this.mergeContractDetails.find(items => items.fieldKey == 'noOfDependents');
              // this.noOfDependents = noOfDependents.values;
              // console.log(this.noOfDependents,this.mergeContractDetails);
            }
          })

        })
      
    })
    
    let Obj = this.screenTB.formView('contractDependent');
    this.showFieldsListDep = Array.from(Object.keys(Obj.showFields));
    // this.contractId = this.route.snapshot.params.id;
    // this.resourceId = this.route.snapshot.params.resDataid
    
    if (this.projectDetails.length == 0) {
      let formBuildBaseObj = this.screenTB.formView('singleResource');
      let apiData = { "formId": formBuildBaseObj.formId, "filterString": { dataId: this.recordId } };
      this.service.getFormData(apiData).subscribe(resp => {
        if (resp.status == 'success') {
          let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              // this.finalArr = (this.newBuildFun(changed.resp,''));
              this.projectDetails = this.gfService.buildView(resp.data, '')[0];
              // this.innerTemplate = changed.innerTemplate;
              // this.breadcrumbs = changed.breadcrumbs;
              // this.subTitle = changed.subTitle;
            }
          }
        }

      })
    }

    // this.workFlowData = [{
    //   "workflowId": "1",
    //   "doctranref": "FFI/C/20182722",
    //   "routeStageNum": "1",
    //   "formFields":{
    //       formId: "18",
    //       fieldList: [
    //         {
    //           "fieldType": "shortText",
    //           "fieldColumn": "firstName",
    //           "fieldId": 101,
    //           "mandatory": true,
    //           "hidden": false
    //         },
    //         {
    //           "fieldType": "shortText",
    //           "fieldColumn": "emailId",
    //           "fieldId": 106,
    //           "mandatory": true,
    //           "hidden": false
    //         },
    //         {
    //           "fieldType": "termsReferenceList",
    //           "fieldColumn": "bloodGroup",
    //           "fieldId": 107,
    //           "mandatory": true,
    //           "hidden": false
    //         },
    //         {
    //           "fieldType": "shortText",
    //           "fieldColumn": "emergencyContact",
    //           "fieldId": 109,
    //           "mandatory": false,
    //           "hidden": false
    //         },
    //         {
    //           "fieldType": "shortText",
    //           "fieldColumn": "gender",
    //           "fieldId": 105,
    //           "mandatory": true,
    //           "hidden": false
    //         },
    //         {
    //           "fieldType": "shortText",
    //           "fieldColumn": "mobileNo",
    //           "fieldId": 108,
    //           "mandatory": true,
    //           "hidden": false
    //         }
    //       ]
    //     },
    //   "workFlowStageId": "",
    //   "actionId": "",
    //   "stageChangeAction": "Manual",
    //   "stageName": "Pending", //completed - for completed quotaion
    //   "tranRole": "Manual",
    //   "actionInstruction": {
    //     "Action": "",
    //     "InstructionText": "Please fill personal details."
    //   }
    // }];
  }

  ngOnInit() {

  }


  /////////////////////////////// 
  updateRequirementBuild(data) {
    let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, resp: data };
        let changed = eventCalls[preBuildEvFn](param);
        let arrData = Array.of(this.mergeContractDetails);
        let profileVal = changed.profilePic;
        this.noOfDependents = changed.noOfDependents;
        this.mergeContractDetails = this.gfService.buildView(changed.resp, { 'oldData': arrData, 'operation': 'edit' })[0];
        console.log(this.mergeContractDetails,changed)
        this.mergeContractDetails['changeIndicator'] =  this.mergeContractDetails['changeIndicator'] + 1;

        let profilePic = this.mergeContractDetails.find(items => items.fieldKey == 'proflePic');
          if(profileVal != null){
              let imagePath = this.config.M_RESIZE_IMAGE_PATH;
              if(this.authGuardService.getLoginUser()){
                this.userToken = this.authGuardService.getLoginUser().tokenId;
              }
              this.profilePic = imagePath + profileVal+'?Token='+this.userToken;
        } else {
          this.profilePic = 'assets/user.jpg';
        }
      
      }
    }

  }

  ////////////////////////////Dependent Edit////////////////////////////////
  dependentArrayReBuild(data) {
    let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, resp: data };
        let changed = eventCalls[preBuildEvFn](param);
        this.dependentDetails = this.gfService.buildView(changed.resp, { 'oldData': this.dependentDetails, 'operation': 'edit' });
      }
    }

  }

  ///////////////////////////Dependent Delete////////////////////////////////
  deleteDepFun(depDataId) {
    this.dependentDetails.map((resp, index) => {
      resp.map(innerResp => {
        if (innerResp.fieldKey == 'dataId') {
          if (innerResp.values == depDataId) {
            this.dependentDetails.splice(index, 1);
          }
        }
      })
    })
  }


  onChange(event) {

  }

  ///////////////////////////////////Depnedent Add////////////////////////////////
  addDependent() {
    this.dialogRefDetails = this.dialog.open(DependentdialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.dialogRefDetails.componentInstance.caseid = 'Dependent';
    this.dialogRefDetails.componentInstance.resourceId = this.resRecordId;
    this.dialogRefDetails.afterClosed().subscribe(resp => {
      if (resp) {
        let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, resp: resp };
            let changed = eventCalls[preBuildEvFn](param);
            this.dependentDetails = (this.gfService.buildView(changed.resp, { 'oldData': this.dependentDetails, 'operation': 'add' }));
          }
        }

      }
    });
  }

  selectedIndex: any;
  navigateTo() {
    this.selectedIndex = 2;
  }
  selected(status) {
    if (status == "0" && status != undefined) {
      return true;
    }
    else {
      return false;
    }
  }

  ///////////////////////////////Tab Click Event/////////////////////////////////////
  projectDetails: any = [];
  dependentDetails: any = [];
  tabClick(event: MatTabChangeEvent) {
    this.selectedIndex = event.index;
    if (event.index == 1 && this.projectDetails.length == 0) {
      let formBuildBaseObj = this.screenTB.formView('singleResource');
      let apiData = { "formId": formBuildBaseObj.formId, "filterString": { dataId: this.recordId } };
      this.service.getFormData(apiData).subscribe(resp => {
        if (resp.status == 'success') {
          let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              // this.finalArr = (this.newBuildFun(changed.resp,''));
              this.projectDetails = this.gfService.buildView(resp.data, '')[0];
              // this.innerTemplate = changed.innerTemplate;
              // this.breadcrumbs = changed.breadcrumbs;
              // this.subTitle = changed.subTitle;
            }
          }
        }

      })
    }
    if (event.index == 3 && this.dependentDetails.length == 0) {
      let formBuildBaseObj = this.screenTB.formView('contractDependent');
      let apiData = { "formId": formBuildBaseObj.formId, "filterString": { resourceId: this.resRecordId } };
      this.service.getFormData(apiData).subscribe(resp => {
        if (resp.status == 'success') {
          let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              // this.finalArr = (this.newBuildFun(changed.resp,''));
              this.dependentDetails = (this.gfService.buildView(resp.data, ''));
              // this.innerTemplate = changed.innerTemplate;
              // this.breadcrumbs = changed.breadcrumbs;
              // this.subTitle = changed.subTitle;
            }
          }
        }


      })
    }
  }
  /////////////////////Array Build////////////////////////////////////////////////
  // newBuildFun(data, arrAlterData) {
  //   console.log(JSON.parse(JSON.stringify(data)));
  //   let finalData: any = [];
  //   data.map(resp => {
  //     let innerArr = [];
  //     let reqPreview_value = [];
  //     let innerJson: any = {};
  //     let resourceDependentName;
  //     Object.keys(resp).map(key => {
  //         if (key === 'country') {
  //           this.hostLocation = resp[key].value;
  //         }
  //         let obj = {
  //           fieldKey: key,
  //           values: resp[key]
  //         }
  //         innerArr.push(obj);
  //     })
  //     innerArr.map(req => {
  //       // if (req.fieldKey === 'proflePic') {
  //       //   resourceDependentName = 'resourceName'
  //       // }
  //       if (req.fieldKey === 'dProflePic') {
  //         // resourceDependentName = 'dependentName'
  //       }
  //       if ((req.fieldKey === 'firstName' && req.values != null) || (req.fieldKey === 'dFirstName' && req.values != null)) {
  //         if(req.values.value != null){
  //           innerJson['resName'] = req.values.value; 
  //         } else {
  //             innerJson['resCount'] = 'resCount';
  //           }
  //       } else if ((req.fieldKey === 'firstName' && req.values == null) || (req.fieldKey === 'dFirstName' && req.values == null)) {
  //         innerJson['resCount'] = 'resCount';
  //       }
  //       if ((req.fieldKey === 'proflePic' && req.values != null) || (req.fieldKey === 'dProflePic' && req.values != null)) {
  //         if(req.values.value != null){
  //           let imagePath = this.config.M_RESIZE_IMAGE_PATH;
  //           if(this.authGuardService.getLoginUser()){
  //             this.userToken = this.authGuardService.getLoginUser().tokenId;
  //           }
  //           innerJson['logo'] = imagePath + req.values.value+'?Token='+this.userToken;
  //         } else {
  //           innerJson['logo'] = 'assets/user.jpg';
  //         }
  //       } else if ((req.fieldKey == 'proflePic' && req.values == null) || (req.fieldKey == 'dProflePic' && req.values == null)) {
  //         innerJson['logo'] = 'assets/user.jpg';
  //       }
  //     })
  //     innerArr.push({
  //       fieldKey: 'dependentName',
  //       values: innerJson
  //     })
  //     finalData.push(innerArr);
  //   })
  //   let innerFinalData;
  //   if (arrAlterData != '') {
  //     if (arrAlterData.operation == 'edit') {
  //       innerFinalData = arrAlterData.oldData;
  //       finalData.map((finalData) => {
  //         finalData.map(finalDataResp => {

  //           innerFinalData.map((alterResp, index) => {
  //             alterResp.map((innerResp) => {
  //               if (finalDataResp.fieldKey == 'dataId' && innerResp.fieldKey == 'dataId') {
  //                 if (finalDataResp.values == innerResp.values) {
  //                   let filterAlterResp = finalData.filter(items => {
  //                     if (typeof items.values == 'object' && items.values != null) {
  //                       return items;
  //                     }
  //                   })
  //                   filterAlterResp.map(resp => {

  //                     alterResp.map(innerResp => {
  //                       if (typeof innerResp.values == 'object') {
  //                         if (resp.fieldKey == innerResp.fieldKey) {
  //                           innerResp.values = resp.values;
  //                         }
  //                       }
  //                     })
  //                   })
  //                   innerFinalData[index] = alterResp;
  //                 }
  //               }
  //             })
  //           })
  //         })
  //       })
  //       finalData = innerFinalData;
  //     } else
  //       if (arrAlterData.operation == 'add') {
  //         // finalData = arrAlterData.oldData.push(finalData[0]);
  //         // arrAlterData.oldData.push(finalData);
  //         // if(arrAlterData.oldData.length > 0)
  //         arrAlterData.oldData.push(finalData[0]);
  //         finalData = arrAlterData.oldData;
  //       }
  //   } else {
  //     finalData = finalData;
  //   }
  //   return finalData;
  // }

  //////////////// Work Flow Complete //////////////////
  workflowSubmit(workFlowData) {
    this.workFlowState = true;
    // workFlowData.map(workFlowResp => {






      // workFlowResp.formFields.map(formFieldsResp => {
      //   let apiData;
      //   if (formFieldsResp.formId == 15 || formFieldsResp.formId == 24 || formFieldsResp.formId == 14){
      //     apiData = { "formId": formFieldsResp.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
      //   }else{
      //     apiData = { "formId": formFieldsResp.formId, "filterString": { dataId: this.resRecordId }, "languageCode": "en" };
      //   }
      //   console.log(this.resRecordId);
      //   this.service.getFormData(apiData).subscribe(resp => {
      //     if(resp.status == 'success'){
      //       let respFields = resp.data[0];
      //       if (formFieldsResp.fieldList.length) {
      //         formFieldsResp.fieldList.map(fieldResp => {
      //           if(respFields[fieldResp.fieldColumn].fieldId == fieldResp.fieldId && fieldResp.mandatory){
      //             if (respFields[fieldResp.fieldColumn].value == '' || respFields[fieldResp.fieldColumn].value == null) {
      //               this.workFlowState = false;
      //             }
      //           }
      //         });
      //       }

      //     } else {
      //       this.workFlowState = false;
      //       // this.alert.error(resp.message);
      //     }
      //     console.log(workFlowData, this.workFlowState, resp);
      //   });
      // });
      this.iterator(0, (workFlowData.formFields != null && workFlowData.formFields.length) ? workFlowData.formFields.length : 0, workFlowData.formFields);








    // });





  }

  protected getWorkFlow(docTranRef){
    let workFlowApiData = {"docTranRef": docTranRef};
    console.log(workFlowApiData);
    this.service.getWorkFlowRecordDetail(workFlowApiData).subscribe(resp => {
      console.log(resp);
      if(resp.status == 'success'){
        this.workFlowData = resp.data;
      }
    })
  }

  iterator(i, len,formFieldsData) {
    if (i >= len) {
        //if condition
        //API call
       if(this.workFlowState){
        let initiatorApprover = 0;
        if(this.workFlowData[0].tranRole == 'InitiatorApprover'){
          initiatorApprover = 1;
        }
        let workFlowApiData = {
          "routeId": this.workFlowData[0].routeId,
          "workflowId": this.workFlowData[0].workflowId,
          "routeStageNum": this.workFlowData[0].routeStageNum,
          "initiatorApprover": initiatorApprover
        }
        this.service.createWorkflowTransaction(workFlowApiData).subscribe(resp => {
          console.log(resp);
          if(resp.status == 'success'){
            this.workFlowData.map((workflow,index) => {
              if(workflow.workflowId == this.workFlowData[index].workflowId){
                this.workFlowData.pop(workflow);
              }
            });
            this.getWorkFlow(this.resRecordNo);
            this.alert.success(resp.message);
          } else {
            this.alert.error(resp.message);
          }
        });
         this.alert.success("To-Do completed.");
       } else {
         this.alert.error("To-Do not yet completed.");
       }
      } else {
        let formFieldsResp = formFieldsData[i];
        //getFormData API call
        let apiData;
        if (formFieldsResp.formId == 15 || formFieldsResp.formId == 24 || formFieldsResp.formId == 25 || formFieldsResp.formId == 14 || formFieldsResp.formId == 27 || formFieldsResp.formId == 28){
          apiData = { "formId": formFieldsResp.formId, "filterString": { resId: this.resRecordId }, "languageCode": "en" };
        }else{
          apiData = { "formId": formFieldsResp.formId, "filterString": { dataId: this.resRecordId }, "languageCode": "en" };
        }
        console.log(this.resRecordId);
        this.service.getFormData(apiData).subscribe(resp => {
          if(resp.status == 'success'){
            let respFields = resp.data[0];
            if (formFieldsResp.fieldList.length) {
              formFieldsResp.fieldList.map(fieldResp => {
                if(typeof respFields[fieldResp.fieldColumn] == 'object' && respFields[fieldResp.fieldColumn] != null){
                  if(respFields[fieldResp.fieldColumn].fieldId == fieldResp.fieldId && fieldResp.mandatory){
                    if (respFields[fieldResp.fieldColumn].value == '' || respFields[fieldResp.fieldColumn].value == null) {
                      this.workFlowState = false;
                    }
                  }
                }
              });
            }

          } else {
            if(apiData.formId == formFieldsResp.formId){
              if (formFieldsResp.fieldList.length) {
                formFieldsResp.fieldList.map(fieldResp => {
                  if(fieldResp.mandatory){
                    this.workFlowState = false;
                  }
                });
              }
            }
            // this.workFlowState = false;
            // this.alert.error(resp.message);
          }
          console.log(this.workFlowState,i,apiData,formFieldsData,resp);
          this.iterator(i + 1, len,formFieldsData);
        });
        
      }
   }
}
