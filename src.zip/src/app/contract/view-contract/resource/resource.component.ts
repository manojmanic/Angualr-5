import { Component, OnInit, Input ,EventEmitter,Output} from '@angular/core';
import { ContractService } from '../../services/contract.service';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { DialogComponent } from './dialog/dialog.component';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { SingleContractComponent } from '../../view-contract/resource/single-contract/single-contract.component';
import { Constants } from '../../../constants';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';

@Component({
  selector: 'app-resource',
  templateUrl: './resource.component.html',
  styleUrls: ['./resource.component.scss']
})
export class ResourceComponent implements OnInit {

  @Input() resContractId;
  @Input() finalData:any;
  @Output() respEdit = new EventEmitter();
  dialogRefEdit: MatDialogRef<DialogComponent>;
  formBuildBaseObj: any;
  showFieldsList: any;
  personalShowFieldsList:any;
  constructor(private contractService: ContractService,
    private router:Router,
    private dialog: MatDialog,
    public gfService: GlobalFunctionService,
    private activatedRoute:ActivatedRoute,
    public config: Constants,
    private screenTB: ScreenTemplateJsonBuilder,
    private service: GlobalformService) {
    this.formBuildBaseObj = this.screenTB.formView('contractResource');
    this.showFieldsList = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    this.formBuildBaseObj = this.screenTB.formView('personalDetails');
    this.personalShowFieldsList = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    this.showFieldsList = this.showFieldsList.concat(this.personalShowFieldsList);
  }

  ngOnInit() {
  }


  ///////// Expansion Panel Configuration ////////////////
  expansionPanel(event) {
    let el = event.target;
    let elcl = event.target.closest('.boxedCard');
    let elClassList = ((elcl).querySelector('.slider')).classList;
    let panel = ((elcl).querySelector('.slider'));
    if (panel.style.maxHeight) {
      el.style = "transform: rotate(0deg); transition: all 0.5s ease-out;"
      panel.style = "max-height:null;"
    } else {
      el.style = "transform: rotate(180deg); transition: all 0.5s ease-out;"
      panel.style = "max-height:" + panel.scrollHeight + "px";
    }
  }
  updateResourceDetails(loopdata){
    let resDataId
    this.service.depDataIdEdit = loopdata.filter(resp => resp.fieldKey != "DependentList")
      for (let data of loopdata) {
      if (data.fieldKey === "dataId") {
        resDataId = data.values;
      }
    }
    this.dialogRefEdit = this.dialog.open(DialogComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.dialogRefEdit.componentInstance.caseid = 'ContractResource'; // To get data from json-builder
      this.dialogRefEdit.componentInstance.contractId =this.resContractId;
      this.dialogRefEdit.componentInstance.resourceId =resDataId;
      this.dialogRefEdit.afterClosed().subscribe(resp=>{
        if(resp)
        this.respEdit.emit(resp);
      })
  }

  updateDependentDetails(dependent,loopdata){
    this.service.depDataIdEdit = dependent;
    // let resDataId;
    // let depDataId;
    // for (let data of loopdata) {
    //   if (data.fieldKey === "resDataId") {
    //     resDataId = data.values;
    //   }
    // }
    // for (let data of dependent) {
    //   if (data.fieldKey === "depDataId") {
    //     depDataId = data.values;
    //   }
    // }
    this.dialogRefEdit = this.dialog.open(DialogComponent
      , {
        height: '80%',
        width: '80%'
      });
      this.dialogRefEdit.componentInstance.caseid = 'ContractDependent'; // To get data from json-builder
      this.dialogRefEdit.componentInstance.contractId =this.resContractId;
   
  }

  isNumber(val) { return typeof val === 'number'; } // To Remove empty chips

  selected(status) {
    if(status == "0" && status != undefined) {
      return true;
    }
    else {
      return false;
    }
  }
  singleViewContract(loopdata){
    console.log(loopdata);
    let resDataId = loopdata.filter(items=> items.fieldKey == 'dataId');
   this.router.navigate(['contract/single-contract', this.gfService.encryptDecryptFun('btoa', this.resContractId), this.gfService.encryptDecryptFun('btoa', loopdata.find(items=> items.fieldKey == 'dataId').values)]);
  }

}
