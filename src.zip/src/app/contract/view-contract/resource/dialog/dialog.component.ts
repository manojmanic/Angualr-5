import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { GlobalformService } from '../../../../shared/services/globalform.service';
import { GlobalformControlService } from '../../../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../../../shared/models/question-checkbox';
import { QuestionBase } from '../../../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { DropdownQuestion } from '../../../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import { ContractService } from '../../../services/contract.service';
import { AlertService } from '../../../../shared/services/alert-service.service';
import { AbstractControl } from '@angular/forms';
import { GlobalFunctionService } from '../../../../shared/services/global-function.service';
import { Constants } from '../../../../constants';
@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {

  questions: QuestionBase<any>[] = [];
  form: FormGroup;
  formId: any = {};
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  form_title: string;
  term_Ref: any;
  formBuildBaseObj: any;
  params: any;
  formObject: any;
  menuItems: any;
  finalDataEditReq: any;
  depDataIdEdit: any;
  resourceId;
  dependentId;
  contractId: any;
  buildData: any
  updatedId: any;
  caseid: any;
  resDataId: any;
  buttonData: any;
  cancelButton: any;
  _touched: boolean;
  workFlowData:any;
  ngOnInit() {
    // this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formEdit(this.caseid);
    this.form_title = this.formBuildBaseObj.title;
    this.menuItems = this.screenTB.siteMenu()
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      // console.log(data);
      this.buildData = data.data;
  
      let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId }};
      this.service.getFormData(apiData).subscribe(resp =>{
        console.log(resp,apiData);
        let formGroups = this.buildData.fieldGroup;
        formGroups.filter(formGroupsData => {
          let formFields = formGroupsData.FieldList;
          formFields.filter(fromResp => {
            resp.data.map(formDataResp =>{
              Object.keys(formDataResp).map(key =>{
                if(typeof formDataResp[key] == 'object' && formDataResp[key] != null && formDataResp[key] != undefined) {
                  // // console.log(formDataResp[key])
                  if(formDataResp[key].fieldId == fromResp.fieldId) {
                    fromResp.value = formDataResp[key].value;
                  }
                  if (fromResp.fieldType === 'fileImage') {
                    // // console.log(fieldData[i]);
                    this.service.files = fromResp.value;
                  }
                  if(fromResp.fieldType === 'internationalPhoneNumber'){
                  if(fromResp.value != undefined) {
                    let some = JSON.parse(fromResp.value);
                    console.log(some.value);
                    if(some.value != undefined ){
                    
                    // fromResp['field']= some.value;
                    // fromResp['flag']= some.iso2;
                    fromResp.value = some.value;
                    this.service.internationalPhoneData[fromResp.fieldColumn] =some.iso2;
                    }
                  }
                  

                }
                }
              })
            })
        })
      })   
      let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
          let changed = eventCalls[preBuildEvFn](param);
          this.buildData = changed.formItems;
          this.buttonData = changed.buttonData;
          this.cancelButton = changed.cancelButton;

        }
      }
      setTimeout(() => {
        let buildFields = this.qcs.buildFields(this.buildData, this.formBuildBaseObj.showFields);
        this.workFlowData.map(workFlowResp => {
          if (workFlowResp.formFields != null && workFlowResp.formFields.length) {
            this.gfService.fieldManage(workFlowResp.formFields,buildFields);
          }
        })
        
        buildFields.map(resp => {
            if (resp.hasOwnProperty('readonly')) {
                delete resp.readonly;
            } else {
                resp['readonly'] = true;
            }
        })
        this.questions = buildFields;
        let buildData =  this.qcs.buildControls(buildFields);
        this.form = buildData;
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
      }, this.config.FORM_LOADING_SEC);
  
      })
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
    })
  }
  constructor(public dialogRef: MatDialogRef<DialogComponent>,
    private http: Http,
    private router: Router,
    public snackBar: MatSnackBar,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    public gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private alert: AlertService,
    private route: ActivatedRoute,
    public cdRef:ChangeDetectorRef,
    private config: Constants,
    private contractservice: ContractService) {

  }

  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {
    console.log(this.form);
    this.form.patchValue({ resourceId: this.resourceId }); /// dependent
    this.form.patchValue({ contractId: this.contractId }); /// contractId Patch
    let status;
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, route: this.route, menuItems: this.menuItems, questions: this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        status = changed.status;
      }
    }
    if (this.form.valid) {

      // let workFlowFieldList = [];
      // this.workFlowData.map(resp => {
      //   if(resp.formFields.length){
      //     resp.formFields.map(fieldResp => {
      //       workFlowFieldList.push(fieldResp);
      //     });
      //   }
      // });
      if (status != "DeActivated") {

        Object.keys(this.form.controls).map(fieldArrData => {
          let fieldKey = fieldArrData;
          let fieldData = this.form.controls[fieldKey];
          // workFlowFieldList.map(workFlowFieldResp => {
          //   if(!workFlowFieldResp.hidden && workFlowFieldResp.fieldColumn == fieldKey){
          //     workFlowFieldResp.value = this.form.controls[fieldKey].value;
          //   }
          // });
          for (var question of this.questions) {
            if (question.fieldType === 'date') {
              var currentDate = new DatePipe('en-us');
              let final = currentDate.transform(this.form.controls[question.fieldColumn].value, 'yyyy-MM-dd')
              if (final != null)
                this.form.value[question.fieldColumn] = final;
            }
            /////////////////////////////International PhoneNumber/////////////////
          if(question.fieldType === 'internationalPhoneNumber'){
            let finalIntelNumber = {value:this.form.controls[question.fieldColumn].value,iso2:this.service.internationalPhoneData[question.fieldColumn]}
            // console.log(finalIntelNumber);
            this.form.value[question.fieldColumn] = JSON.stringify(finalIntelNumber);
          }
          }
          //  if (fieldData['nativeElement'].classList.contains('datePick')) {
          //   console.log(fieldArrData);
          //   var currentDate = new DatePipe('en-us');
          //   let final = currentDate.transform(fieldData.value, 'yyyy-MM-dd')
          //   if (final != null)
          //     this.form.patchValue({ [fieldKey]: final });
          //  }
        });
        // console.log(this.form);
        let apiValues = this.form.value;
        Object.keys(apiValues).map(resp => {
          if (apiValues[resp] == "" || apiValues[resp] == null) {
            apiValues[resp] = null;
          }
        });
        // console.log(apiValues)
        this.service.updateFormData(apiValues, this.formBuildBaseObj.formId, this.resourceId).subscribe(data => {
          // console.log(data);
          // console.log(this.contractId);
          this.alertMsg(data)
          if (data.status == 'success') {
            let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId }};
            this.service.getFormData(apiData).subscribe(resp => {
              console.log(resp);
              this.dialogRef.close(resp.data);
            })
          }
        })
      }
      else {
        this.alert.error("Please Select Active values");
      }
    } else if(this.form.status == "DISABLED"){
      this.dialogRef.close();
    } else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
      this.alert.error("Please fill required fields.");
    }

  }
  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

}
