import { Component, OnInit, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ContractService } from '../services/contract.service';
import { GlobalformService } from '../../shared/services/globalform.service';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalFunctionService } from '../../shared/services/global-function.service';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { Constants } from '../../constants';
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { AlertService } from '../../shared/services/alert-service.service';
import { MatTabChangeEvent } from '@angular/material';

@Component({
  selector: 'app-view-contract',
  templateUrl: './view-contract.component.html',
  styleUrls: ['./view-contract.component.scss']
})
export class ViewContractComponent implements OnInit {
  projectDet: any = [];
  projectDet_Value: any = [];
  recordId: any;
  recordNo: any;
  formBuildBaseObj: any;
  showFieldsList: any;
  caseid: any;
  finalData: any = [];
  form_title: any;
  breadcrumbs: any;
  innerTemplate: any;
  subTitle: any;
  alertMsg= false;
  cntNumber: any;
  workFlowData: any = [];
  ChildWorkFlowData: any = [];
  contractDetails: any = [];
  todoDetails: any = [];
  userToken;
  selectedIndex;
  buildData: any;

  constructor(private contractService: ContractService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private authGuardService: AuthGuardService,
    public gfService: GlobalFunctionService,
    public config: Constants,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private screenTB: ScreenTemplateJsonBuilder,
    private service: GlobalformService,
    private alert:AlertService) {
    let apiData;
    this.formBuildBaseObj = this.screenTB.formView('viewContract');
    this.showFieldsList = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    this.form_title = this.formBuildBaseObj.title;
    this.recordId = this.gfService.encryptDecryptFun('atob', this.activatedRoute.snapshot.params.id);
    apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.recordId } };
    this.service.getFormData(apiData).subscribe(resp => {
      if (resp.status == 'success') {
        this.recordNo = resp.data[0].contractNo;
        let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, cntNumber: this.recordNo, resp: resp.data };
            let changed = eventCalls[preBuildEvFn](param);
            this.innerTemplate = changed.innerTemplate;
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
            this.buildData = changed.resp;
          }
        }
        this.contractDetails = this.gfService.buildView(this.buildData, '')[0];
        this.getWorkFlow(this.recordNo);
      }
    })
    let formBuildBaseObj = this.screenTB.formView('contractResource');
    apiData = { "formId": formBuildBaseObj.formId, "filterString": { contractId: this.recordId } };
    this.service.getFormData(apiData).subscribe(resp => {
      let finalArr = [];
      if (resp.status == 'success')
        resp.data.map(data => {
          let resourceArr = data;
          let formBuildBaseObj = this.screenTB.formView('personalDetails');
          let apiData = { "formId": formBuildBaseObj.formId, "filterString": { dataId: data.dataId } };
          this.service.getFormData(apiData).subscribe(personalResp => {
            if (personalResp.status == 'success')
              personalResp.data.map(resp => {
                Object.keys(resourceArr).map(resResp => {
                  if (typeof resourceArr[resResp] != 'object') {
                    Object.keys(resp).map(perResp => {
                      if (resResp == perResp) {
                        resourceArr[resResp] = resp[perResp];
                      } else {
                        //  resourceArr[resResp] = resourceArr[resResp]
                      }
                    })
                  } else {
                    resourceArr[resResp] = resourceArr[resResp]
                  }
                })
              })
            this.resourceArr.push(resourceArr);
            let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
            if (preBuildEvFn != '') {
              const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[preBuildEvFn]) {
                let param = { formId: this.formBuildBaseObj.formId, resp: this.resourceArr };
                let changed = eventCalls[preBuildEvFn](param);
                this.finalArr = (this.gfService.buildView(changed.resp, ''));
              }
            }

          })
        })
    });
  }

  protected getWorkFlow(docTranRef){
    let workFlowApiData = {"docTranRef": docTranRef};
    this.service.getWorkFlowRecordDetail(workFlowApiData).subscribe(resp => {
      if(resp.status == 'success'){
        this.workFlowData = resp.data;
        console.log(this.workFlowData);
        this.workFlowData.map(workFlowResp => {
          let workFlowChildApiData = {"workflowId": workFlowResp.workflowId};
          this.service.getChildWorkflowStagedetails(workFlowChildApiData).subscribe(childWorkflowResp => {
            console.log(childWorkflowResp);
            if(childWorkflowResp.status == 'success'){
              this.ChildWorkFlowData = childWorkflowResp.data;
            }
          });
        });
      }
    })
  }

  resourceArr: any = [];
  finalArr: any = [];
  respEditData(data) {
    // let resourceArr = data;
    let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, resp: data };
        let changed = eventCalls[preBuildEvFn](param);
        this.finalArr = (this.gfService.buildView(changed.resp, { 'oldData': this.finalArr, 'operation': 'edit'}));
      }
    }

  }

  tabClick(event) {
    console.log(event);
    this.selectedIndex = event.index;
    // this.finalArr = [];
    if (event.index == 2 && this.finalArr.length == 0) {
      // let finalArr: any = [];
      // let resourceArr: any = [];
      // let formBuildBaseObj = this.screenTB.formView('contractResource');
      // let apiData = { "formId": formBuildBaseObj.formId, "filterString": { contractId: this.activatedRoute.snapshot.params.id } };
      // this.service.getFormData(apiData).subscribe(resp => {
      //   let finalArr = [];
      //   // this.finalArr = (this.getFormRequirementBuild(resp.data,''));
      //   if(resp.status == 'success')
      //   resp.data.map(data => {
      //     let resourceArr = data;
      //     let formBuildBaseObj = this.screenTB.formView('personalDetails');
      //     let apiData = { "formId": formBuildBaseObj.formId, "filterString": { dataId: data.dataId } };
      //     this.service.getFormData(apiData).subscribe(personalResp => {
      //       if(personalResp.status == 'success')
      //       personalResp.data.map(resp => {
      //         Object.keys(resourceArr).map(resResp => {
      //           if (typeof resourceArr[resResp] != 'object') {
      //             Object.keys(resp).map(perResp => {
      //               if (resResp == perResp) {
      //                 resourceArr[resResp] = resp[perResp];
      //               } else {
      //                 //  resourceArr[resResp] = resourceArr[resResp]
      //               }
      //             })
      //           }else {
      //             resourceArr[resResp] = resourceArr[resResp]
      //          }
      //         })
      //       })
      //       this.resourceArr.push(resourceArr);
      //       let formBuildBaseObj = this.screenTB.formView('personalDetails');
      //       let preBuildEvFn = formBuildBaseObj.eventHandler.preBuild;
      //       if (preBuildEvFn != '') {
      //         const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      //         if (eventCalls[preBuildEvFn]) {
      //           let param = { formId: formBuildBaseObj.formId,resp:this.resourceArr  };
      //           let changed = eventCalls[preBuildEvFn](param);
      //           this.finalArr = (this.gfService.buildView(changed.resp,''));
      //           // this.innerTemplate = changed.innerTemplate;
      //           // this.breadcrumbs = changed.breadcrumbs;
      //           // this.subTitle = changed.subTitle;
      //         }
      //       }

      //     })
      //   })
      // })
    }
  }
  


  onChange(event) {

  }

  ngOnInit() {

    let refEl = document.querySelector('#res_0');
    console.log(refEl);
  }
  selected(status) {
    if (status == "0" && status != undefined) {
      return true;
    }
    else {
      return false;
    }
  }

  isNumber(val) { return typeof val === 'number'; } // To Remove empty chips

  //////////////// Work Flow Complete //////////////////
  workflowSubmit(workFlowData) {
    console.log(workFlowData);
    let initiatorApprover = 0;
    if(workFlowData.tranRole == 'InitiatorApprover'){
      initiatorApprover = 1;
    }
    let workFlowApiData = {
      "routeId": 3,
      "workflowId": workFlowData.workflowId,
      "routeStageNum": workFlowData.routeStageNum,
      "initiatorApprover": initiatorApprover
    }
    this.alertMsg = true;
    this.service.createWorkflowTransaction(workFlowApiData).subscribe(resp => {
      console.log(resp,workFlowApiData);
      if(resp.status == 'success'){
        if(workFlowData.routeStageNum == 1){
          let resourceWorkFlowApiData = {
            "workflowId": workFlowData.workflowId,
            "contractNo": this.recordNo
          }
          this.service.generateResourceWorkflow(resourceWorkFlowApiData).subscribe(resourceWorkflowResp => {
            if(resourceWorkflowResp.status == 'success'){

            }
          });
        }
        this.workFlowData.map(workflow => {
          if(workflow.workflowId == workFlowData.workflowId){
            this.workFlowData.pop(workflow);
          }
        });
        this.getWorkFlow(this.recordNo);
        this.alert.success(resp.message);
      } else {
        this.alert.error(resp.message);
      }
    });
  }

  navigateTo(event){
    console.log(this.finalArr,event.tabClick);
    let matTab: MatTabChangeEvent;
    console.log(matTab);
    if(![undefined, null].includes(event)){
      if(event.hasOwnProperty('tabLink')){
        this.selectedIndex = event.tabLink;
      }
      // box-shadow: 0px 0px 5px 1px #1b85f0;
      if(event.hasOwnProperty('referrence')){
        let refEl = document.querySelector('#res_0');
        console.log(refEl);
      }
    }
    console.log(event);
  }

  navigateFocus(event){
    console.log(event);
  }

}