import { Component } from '@angular/core';
import { Router, NavigationStart, NavigationEnd, NavigationError, NavigationCancel, RoutesRecognized } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  constructor(
    private router: Router){
    // router.events.forEach((event) => {
    //     if(event instanceof NavigationStart) {
    //         this.navActive(event.url);
    //     }

    //     if(event instanceof NavigationEnd) {
    //         this.navActive(event.url);
    //     }

    //     if(event instanceof NavigationCancel) {
    //         this.navActive(event.url);
    //     }

    //     if(event instanceof NavigationError) {
    //         this.navActive(event.url);
    //     }
    // });
  }



}
