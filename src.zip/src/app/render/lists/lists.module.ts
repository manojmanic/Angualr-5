import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonlistComponent } from './commonlist/commonlist.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PipeModule } from '../../shared/pipes/pipe.module';

import {
  MatInputModule,
  MatFormFieldModule,
  MatButtonModule,
  MatCardModule,
  MatTabsModule,
  MatIconModule,
  MatGridListModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatSelectModule,
  MatRadioModule,
  MatTooltipModule,
  MatSnackBarModule,
  MatDialogModule,
  MatChipsModule,
  MatExpansionModule,
  MatSlideToggleModule,
  MatPaginatorModule,
  MatProgressSpinnerModule
} from '@angular/material';
import { HflistComponent } from './hflist/hflist.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PaginationComponent } from './pagination/pagination.component';

@NgModule({
  imports: [
    CommonModule,
    PipeModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatTabsModule,
    MatIconModule,
    MatGridListModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatDialogModule,
    MatChipsModule,
    MatExpansionModule,
    MatSlideToggleModule,
    MatPaginatorModule,
    FormsModule,
    ReactiveFormsModule,
    MatProgressSpinnerModule
  ],
  declarations: [
    CommonlistComponent,
    HflistComponent,
    PaginationComponent
  ],
  exports: [
    CommonlistComponent,
    HflistComponent,
    PaginationComponent
  ]
})
export class ListsModule { }
