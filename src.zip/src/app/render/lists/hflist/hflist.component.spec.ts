import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HflistComponent } from './hflist.component';

describe('HflistComponent', () => {
  let component: HflistComponent;
  let fixture: ComponentFixture<HflistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HflistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HflistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
