import { Component, OnInit, Input, Output, EventEmitter,ViewChild,ElementRef,ChangeDetectorRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/interval';
import { Constants } from '../../../constants';
@Component({
  selector: 'app-hflist',
  templateUrl: './hflist.component.html',
  styleUrls: ['./hflist.component.scss']
})
export class HflistComponent implements OnInit {

  @Input() renderFields;
  @Input() headerShowFields;
  @Input() footerShowFields;
  @Input() batchState;
  search = '';
  loader: boolean = false;
  protected callSearch;

  constructor(public cdRef:ChangeDetectorRef, private config: Constants) { }

  @ViewChild('input1') inputEl: ElementRef;
  ngOnInit() {

  }

  @Output() recordDetail = new EventEmitter<boolean>();
  recordDetailFunc(record) {
    this.recordDetail.emit(record);
  }

  @Output() recordEdit = new EventEmitter<boolean>();
  recordEditFunc(record) {
    this.recordEdit.emit(record);
  }

  @Output() recordDelete = new EventEmitter<boolean>();
  recordDeleteFunc(record) {
    this.recordDelete.emit(record);
  }
  @Output() pageEventData = new EventEmitter();
  pageEventEmit(data) {
    // console.log(data)
    this.loader = true;

    setTimeout (() => {
      this.pageEventData.emit(data);
      this.loader = false;
    }, this.config.PG_LOADING_SEC)
  }
  @Output() searchData = new EventEmitter();
  searchFunction(event, data) {
    // console.log(data);
    // this.searchData.emit(event.target.value)
    // this.searchData.emit(data)
    if (event.key == 'Enter') {
      // this.loader = true;
      // if(data.length > 1) {
      // setTimeout(()=>  this.searchData.emit(data),500);
      // }
    } else {
      if (data == '') {
        // console.log(data);
        // this.loader = true;
        // if(data.length > 1) {
        // setTimeout(()=>  this.searchData.emit(data),500);
      }
    }
    this.loader = true;
    // setTimeout(()=>  this.searchData.emit(event.target.value),2000);

    if(this.callSearch)
      clearTimeout(this.callSearch);

    this.callSearch = setTimeout (() => {
      this.searchData.emit(event.target.value);
      this.loader = false;
    }, this.config.SEARCH_LOADING_SEC);
  //   if(event.target.value != '') {
  //  Observable.interval(1000).subscribe(resp =>{
  //    this.loader = false;
  //   this.searchData.emit(event.target.value)
  //  })
   
  //   }else if(event.target.value == '') {
  //     Observable.interval(1000).subscribe(resp =>{
  //       this.loader = false;
  //      this.searchData.emit(event.target.value)
  //     })
  //   }
    // this.loader = true;
    // Observable.fromEvent(event.target, 'keyup').debounceTime(1000).subscribe(value => {
    //   console.log(event.target.value);
    //   this.loader = false;
    //   this.searchData.emit(event.target.value)
    // })

  }

}