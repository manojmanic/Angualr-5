import { Component, OnInit, Input, EventEmitter, Output,ViewChild } from '@angular/core';
import { PageEvent } from '@angular/material';
import { Constants } from '../../../constants';
import { GlobalformService } from '../../../shared/services/globalform.service';
import {MatPaginator,} from '@angular/material';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit {

  @Input() paginationData: any = {};
  @Output() pageEventData: any = new EventEmitter<PageEvent>();
  length;
  pageSize: any;
  pageSizeOptions: any;
  pageEvent: PageEvent;
  constructor(private config: Constants,
    private service: GlobalformService
  ) {
    // this.paginator = this.pageEventInput;
   }


  @ViewChild(MatPaginator) paginator: MatPaginator;
  
  // MatPaginator Inputs
 
  ngOnChanges() {
    // console.log(this.paginationData);
    this.paginator._pageIndex = 0;
    // this.length = 21;
    this.length = this.paginationData.PGlength;
  }
  ngOnInit() {
    this.pageSizeOptions = this.config.PG_LIMIT_OPTIONS;
    this.pageSize = this.config.PG_LIMIT_DEFAULT;
  }
  pageEventFunction(data) {
    this.pageEventData.emit(data);
  }
}
