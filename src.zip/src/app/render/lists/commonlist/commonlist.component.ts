import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/throttleTime';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/interval';
import { Constants } from '../../../constants';
@Component({
  selector: 'app-commonlist',
  templateUrl: './commonlist.component.html',
  styleUrls: ['./commonlist.component.scss']
})
export class CommonlistComponent implements OnInit {

  @Input() renderFields;
  @Input() showFields;
  constructor(public cdRef: ChangeDetectorRef, private config: Constants) { }
  search: any = '';
  // autofocus = true;
  loader: boolean = false;
  callSearch: any;
  @ViewChild('input1') inputEl: ElementRef;
  
  ngOnInit() {
    // console.log(this.renderFields);
  }



  @Output() recordDetail = new EventEmitter<boolean>();
  recordDetailFunc(record) {
    this.recordDetail.emit(record);
  }

  @Output() recordEdit = new EventEmitter<boolean>();
  recordEditFunc(record) {
    this.recordEdit.emit(record);
  }

  @Output() recordDelete = new EventEmitter<boolean>();
  recordDeleteFunc(record) {
    this.recordDelete.emit(record);
  }

  // @Output() recordAddPartnerRate = new EventEmitter<boolean>();
  // recordAddPartnerRatefFunc(record) {
  //   this.recordAddPartnerRate.emit(record);
  // }

  @Output() pageEventData = new EventEmitter();
  pageEventEmit(data) {
    this.loader = true;
    setTimeout(() => {
      this.pageEventData.emit({
        pageData:data,
        formId:this.renderFields.formId
      });
      this.loader = false;
    }, this.config.PG_LOADING_SEC)
  }
  @Output() searchData = new EventEmitter();
  searchFunction(event, data) {
    this.loader = true;
    
    if(this.callSearch)
      clearTimeout(this.callSearch);

    this.callSearch = setTimeout(() => {
      let emitData = {
        searchData:event.target.value,
        formId:this.renderFields.formId
      }
      this.searchData.emit(emitData);
      this.loader = false;
    }, this.config.SEARCH_LOADING_SEC);
  }

}
