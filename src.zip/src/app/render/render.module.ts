import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormModule } from './form/form.module';
import { ListsModule } from './lists/lists.module';
import { ViewsModule } from './views/views.module';

@NgModule({
    imports: [
      CommonModule,
      FormModule,
      ListsModule,
      ViewsModule
    ],
    exports: [
        FormModule,
        ListsModule,
        ViewsModule
    ],
    declarations: []
})
export class RenderModule { }