import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonviewComponent } from './commonview/commonview.component';

import { PipeModule } from '../../shared/pipes/pipe.module';
import { DirectiveModule } from '../../shared/directives/directive.module'

import {
  MatToolbarModule,
  MatCardModule,
  MatTabsModule,
  MatIconModule,
  MatGridListModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatTooltipModule,
  MatDialogModule,
  MatChipsModule,
  MatExpansionModule,
  MatStepperModule,
  MatSliderModule,
  MatSlideToggleModule
} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CalcviewComponent } from './calcview/calcview.component';

@NgModule({
  imports: [
    CommonModule,
    PipeModule,
    DirectiveModule,
    FlexLayoutModule,
    MatToolbarModule,
    MatCardModule,
    MatTabsModule,
    MatIconModule,
    MatGridListModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    MatTooltipModule,
    MatDialogModule,
    MatChipsModule,
    MatExpansionModule,
    MatStepperModule,
    MatSliderModule,
    MatSlideToggleModule
  ],
  declarations: [
    CommonviewComponent,
    CalcviewComponent
  ],
  exports: [
    CommonviewComponent,
    CalcviewComponent
  ]
})
export class ViewsModule { }
