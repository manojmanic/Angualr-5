import { Component, OnInit, Input } from '@angular/core';
import { Constants } from '../../../constants';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';
import * as FileSaver from 'file-saver';
import { DownloadService } from '../../../shared/services/download.service';
import { GlobalformService } from '../../../shared/services/globalform.service';
@Component({
  selector: 'app-commonview',
  templateUrl: './commonview.component.html',
  styleUrls: ['./commonview.component.scss']
})
export class CommonviewComponent implements OnInit {

  @Input() viewDetails: any;
  imagePath: any;
  docPath: any;
  userToken;
  constructor(private config: Constants,
    private api: DownloadService,
    private service:GlobalformService,
    private authGuardService: AuthGuardService) {
   }

  ngOnInit() {
    this.imagePath = this.config.M_RESIZE_IMAGE_PATH;
    this.docPath = this.config.FILE_PATH;
    if(this.authGuardService.getLoginUser()){
      this.userToken = this.authGuardService.getLoginUser().tokenId;
    }   
  }

  downloadImage(value,name){
    value = value +'?Token='+this.userToken
    // console.log(value);
    this.api.getFile(value)
      .subscribe(fileData => FileSaver.saveAs(fileData,name));
  }

  downloadFile(value,name){
    value = value +'?Token='+this.userToken
    // console.log(value);
    this.api.getFile(value)
    .subscribe(fileData => FileSaver.saveAs(fileData,name));
  }

  fileTypeIcon(fileName){
    let ext = fileName.substring(fileName.lastIndexOf('.')+1);
    if(ext == 'pdf'){
      return'picture_as_pdf';
    }else if(ext == 'docx'){
      return 'description';
    } 
    return '';
  }

}
