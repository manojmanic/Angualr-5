import { Component, OnInit, Input } from '@angular/core';
import { Constants } from '../../../constants';

@Component({
  selector: 'app-calcview',
  templateUrl: './calcview.component.html',
  styleUrls: ['./calcview.component.scss']
})
export class CalcviewComponent implements OnInit {

  @Input() viewDetails: any;
  imagePath;
  docPath:any;
  constructor(private config: Constants) { }

  ngOnInit() {
      this.imagePath = this.config.M_RESIZE_IMAGE_PATH;
      this.docPath = this.config.FILE_PATH;    
  }

}
