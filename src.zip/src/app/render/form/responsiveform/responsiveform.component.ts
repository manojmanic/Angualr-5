import { Component, OnInit, Input, ElementRef, Output, EventEmitter, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { QuestionBase } from '../../../shared/models/question-base';
import { GlobalformService } from '../../../shared/services/globalform.service';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { DatePipe } from '@angular/common';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';
import { Constants } from '../../../constants';
import { LimitToPipe } from '../../../shared/pipes/limit-to/limit-to.pipe';
import { MatSnackBar } from '@angular/material';
// import * as $ from 'jquery';
import 'intl-tel-input';
import 'intl-tel-input/build/js/utils';

@Component({
  selector: 'app-responsiveform',
  templateUrl: './responsiveform.component.html',
  styleUrls: ['./responsiveform.component.scss']
})
export class ResponsiveformComponent implements OnInit {

  @Input('renderFields') renderFields: QuestionBase<any>[] = [];
  @Input() form: FormGroup;
  @Output() finalAddons = new EventEmitter()
  @ViewChild("fileInput") fileInput;
  ////////////////////////////International PhoneNumber///////////////////
  @Input('ng2TelInputOptions') ng2TelInputOptions: any;
  @Output('hasError') hasError: EventEmitter<boolean> = new EventEmitter();
  @Output('ng2TelOutput') ng2TelOutput: EventEmitter<any> = new EventEmitter();
  @Output('countryChange') countryChange: EventEmitter<any> = new EventEmitter();
  @Output('intlTelInputObject') intlTelInputObject: EventEmitter<any> = new EventEmitter();
  loginData: any;
  imagePath: any;
  docPath:any;
  objectKeys = Object.keys;
  selectedAddonArr = {};
  limitPipe = new LimitToPipe();
  minDate;
  fileTypeIconPdf:any;
  fileTypeIconDocx:any;
  extension:any;
  userToken;

  constructor(
    private service: GlobalformService,
    public gfService: GlobalFunctionService,
    private authGuardService: AuthGuardService,
    public config: Constants,
    private snackBar: MatSnackBar,
    private el: ElementRef
  ) {
        this.imagePath = this.config.M_RESIZE_IMAGE_PATH;
        this.docPath = this.config.FILE_PATH;
        if(this.authGuardService.getLoginUser()){
          this.userToken = this.authGuardService.getLoginUser().tokenId;
        }
    
  }
  intelNumber: any = {};
  onCountryChange(event,fieldColumn){                                   
     console.log(event,fieldColumn);
     this.intelNumber[fieldColumn] = event;
     this.service.internationalPhoneData[fieldColumn] = this.intelNumber[fieldColumn].iso2;
     console.log(this.service.internationalPhoneData);
  }
  boo:boolean;
  onChanges(event){
    // let target = event.target;
    // let targetId = <HTMLInputElement>target.getAttribute('id');
    // let fieldColumn: any = <HTMLInputElement>target.getAttribute('');
    // console.log(fieldColumn);
    this.boo = event;
    if(this.boo){
    }
    else{
    this.openSnackBar("Please Enter a Valid Phone Number.", "");
    }
  }
  ngOnInit() {
    //this.finalAddons.next(this.selectedAddonArr);
  }
  files: any;
  onChange(event) {
    let fileList: FileList = event.target.files;
    let file: File = fileList[0];
    let labelSpan = <HTMLLabelElement>this.el.nativeElement.querySelector('.files');
    if (typeof file != 'undefined') {
      let formData: FormData = new FormData();
      labelSpan.classList.remove('error');
      labelSpan.classList.add('added');
      labelSpan.children[1].innerHTML = this.limitPipe.transform(file.name, '20');
      formData.append('file', file);
      this.service.uploadFile(formData).subscribe(data => {
        this.files = data.SavedFileName;
        this.service.files = this.files;
      })
    } else {
      labelSpan.children[1].innerHTML = '';
      labelSpan.classList.remove('added');
      if (event.target.required)
        labelSpan.classList.add('error');
    }
  }
  docFiles: any = {};
  // docOnChange(event) {
  //   let fileList: FileList = event.target.files;
  //   let file: File = fileList[0];
  //   this.service.files=file.name
  //   let labelSpan = <HTMLLabelElement>this.elin.nativeElement.querySelector('.files');
  //   if(typeof file != 'undefined'){
  //     let formData: FormData = new FormData();
  //    labelSpan.classList.remove('error');
  //    labelSpan.classList.add('added');
  //    labelSpan.children[1].innerHTML = file.name;
  //     formData.append('file', file);
  //     this.service.uploadFileDocs(formData).subscribe(data => {
  
  //       this.files = data.SavedFileName;
  //      // this.service.files=this.files;
  //     })
  //   } else {
  //     labelSpan.children[1].innerHTML = '';
  //     labelSpan.classList.remove('added');
  //     if(event.target.required)
  //       labelSpan.classList.add('error');
  //   }
  // }

  telInputObject(obj,fieldColumn) {
   obj.intlTelInput('setCountry', this.service.internationalPhoneData[fieldColumn]);
  }

  addFile(event) {
    let target = event.target;
    let fileList: FileList = target.files;
    let file: File = fileList[0];
    
    let targetId = <HTMLInputElement>target.getAttribute('id');
    let fieldColumn:any = <HTMLInputElement>target.getAttribute('data-column');
    
    let labelSpan = <HTMLLabelElement>this.el.nativeElement.querySelector('.'+targetId);
    if (typeof file != 'undefined') {
      let formData: FormData = new FormData();
      labelSpan.classList.remove('error');
      labelSpan.classList.add('added');
      labelSpan.children[1].innerHTML = this.limitPipe.transform(file.name, '20');
      formData.append('file', file);
      this.service.uploadFileDocs(formData).subscribe(data => {
        
        this.docFiles[fieldColumn] = data.SavedFileName;
        this.service.files = this.docFiles;
        // console.log(this.docFiles[fieldColumn]);
        //  this.extension = this.docFiles[fieldColumn].substring(this.docFiles[fieldColumn].lastIndexOf('.')+1);
        // console.log(this.extension);
        //  if(this.extension.toLowerCase() == 'pdf'){
        //    console.log('pdf');
        //    this.fileTypeIconPdf = 'picture_as_pdf';
        //  }else if(this.extension.toLowerCase()== 'docx'){
        //    console.log('docx');
        //    this.fileTypeIconDocx = 'add';
        //  }else{
        //  }
      })
      
    } else {
      labelSpan.children[1].innerHTML = '';
      labelSpan.classList.remove('added');
      if (event.target.required)
        labelSpan.classList.add('error');
    }
  }
  dateFormat(date, event: MatDatepickerInputEvent<Date>) {
    var currentDate = new DatePipe('en-us')
    let final = currentDate.transform(event.value, 'dd/MM/yyyy')
  }

  fileTypeIcon(fileName){
    let ext = fileName.substring(fileName.lastIndexOf('.')+1);
    if(ext == 'pdf'){
      return'picture_as_pdf';
    }else if(ext == 'docx'){
      return 'description';
    } 
    return'';
  }


  selectedAddons(data, event) {
    let target = event.target;
    let closestAddonsBody = target.closest('.addonsBody').childNodes;
    closestAddonsBody.forEach((element, index) => {
      if (this.gfService.typeOf(element.classList) != 'undefined') {
        element.classList.remove('selected');
        let crtBodyMatIcon = element.querySelector('mat-icon');
        
        crtBodyMatIcon.innerHTML = 'radio_button_unchecked';
      }
    });

    let crtMatIcon = target.closest('.addonsList').querySelector('mat-icon');
    crtMatIcon.innerHTML = 'radio_button_checked';
    target.closest('.addonsList').classList.add('selected');

    this.finalAddons.next(this.selectedAddonArr);
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
      extraClasses: ['error']
    });
  }
}
