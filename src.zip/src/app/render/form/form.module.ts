import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonformComponent } from './commonform/commonform.component';
import { CalcformComponent } from './calcform/calcform.component';
import { ResponsiveformComponent } from './responsiveform/responsiveform.component';
import { PipeModule } from '../../shared/pipes/pipe.module';
import { FlexLayoutModule } from '@angular/flex-layout';

import { DirectiveModule } from '../../shared/directives/directive.module'
import {
  MatButtonModule,
  MatCheckboxModule,
  MatCardModule,
  MatInputModule,
  MatIconModule,
  MatFormFieldModule,
  MatSelectModule,
  MatRadioModule,
  MatAutocompleteModule,
  MatTooltipModule,
  MatDialogModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatChipsModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatProgressSpinnerModule
} from '@angular/material';
import { OwlDateTimeModule, OwlNativeDateTimeModule, OWL_DATE_TIME_FORMATS} from 'ng-pick-datetime';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {Ng2TelInputModule} from 'ng2-tel-input';

@NgModule({
  imports: [
    CommonModule,
    PipeModule,
    FlexLayoutModule,
    MatButtonModule,
    MatCheckboxModule,
    MatCardModule,
    MatInputModule,
    MatIconModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatDialogModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatProgressSpinnerModule,
    DirectiveModule,
    FormsModule,
    ReactiveFormsModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    Ng2TelInputModule
  ],
  declarations: [
    CommonformComponent,
    CalcformComponent,
    ResponsiveformComponent
  ],
  exports: [
    CommonformComponent,
    CalcformComponent,
    ResponsiveformComponent
  ]
})
export class FormModule { }
