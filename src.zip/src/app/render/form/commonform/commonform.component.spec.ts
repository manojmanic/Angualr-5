import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonformComponent } from './commonform.component';

describe('CommonComponent', () => {
  let component: CommonformComponent;
  let fixture: ComponentFixture<CommonformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommonformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
