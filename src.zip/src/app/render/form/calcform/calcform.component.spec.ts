import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalcformComponent } from './calcform.component';

describe('CalcformComponent', () => {
  let component: CalcformComponent;
  let fixture: ComponentFixture<CalcformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalcformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalcformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
