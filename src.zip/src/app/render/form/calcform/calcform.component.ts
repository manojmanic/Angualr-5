import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { QuestionBase } from '../../../shared/models/question-base';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';

@Component({
  selector: 'app-calcform',
  templateUrl: './calcform.component.html',
  styleUrls: ['./calcform.component.scss']
})
export class CalcformComponent implements OnInit {
  currency:any;
  @Input('renderFields') renderFields: QuestionBase<any>[] = [];
  @Input() form: FormGroup;

  constructor(private authGuardService: AuthGuardService) { 
    if(this.authGuardService.getLoginUser()){
      this.currency = this.authGuardService.getLoginUser().globalConfiguration.prefferdCurrency;
      console.log(this.currency);
    }
  }

  ngOnInit() {
  }

}
