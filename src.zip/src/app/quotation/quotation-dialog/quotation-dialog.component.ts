import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material';
import { GlobalformService } from '../../shared/services/globalform.service';
import { GlobalformControlService } from '../../shared/services/globalform-control.service';
import { TextboxQuestion } from '../../shared/models/question-textbox';
import { CheckboxQuestion } from '../../shared/models/question-checkbox';
import { QuestionBase } from '../../shared/models/question-base';
import { DropdownQuestion } from '../../shared/models/question-dropdown';
import { MatSnackBar } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { Http, Headers, Response } from "@angular/http";
import { DatePipe } from '@angular/common';
import { AlertService } from '../../shared/services/alert-service.service';
import { QuotationService } from '../service/quotation.service';
import { FormControl, FormGroup, Validators, FormArray } from '@angular/forms';
import { GlobalFunctionService } from '../../shared/services/global-function.service';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { Constants } from '../../constants';

@Component({
  selector: 'app-quotation-dialog',
  templateUrl: './quotation-dialog.component.html',
  styleUrls: ['./quotation-dialog.component.scss']
})
export class QuotationDialogComponent implements OnInit {

  formBuildBaseObj;
  form_title;
  params;
  caseid;
  dialogData: any
  formFields: QuestionBase<any>[] = [];
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  cancelButton: any;
  buildData: any;
  formLoopData: any = [];
  pageData: any;
  buttonData: any;
  quotationNo: any
  loopData: any = [];
  formDataApiData = {};
  finalData: any = [];
  resourceId: any;
  recordId: any;
  loginData: any;

  constructor(
    private config: Constants,
    private router: Router,
    private gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private activateRoute: ActivatedRoute,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private fbbService: FormBuildBaseService,
    private quotationService: QuotationService,
    private alert: AlertService,
    public dialogRef: MatDialogRef<QuotationDialogComponent>,
    private authGuardService: AuthGuardService) {

    this.loginData = authGuardService.getLoginUser();
    // this.params = this.activateRoute.params['value'].id;
    this.formDataApiData = { "quoteNo": this.quotationNo, "languageCode": "en" };
    this.formBuildBaseObj = this.screenTB.formEdit('Quotation');
    this.form_title = this.formBuildBaseObj.title;


    this.service.getForms(this.formBuildBaseObj.formId).subscribe(resp => {
      console.log(resp);
      this.buildData = resp.data;
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
        let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData, resp: resp.data };
            let changed = eventCalls[preBuildEvFn](param);
            this.buttonData = changed.buttonData;
            this.buildData = changed.formItems;
            this.cancelButton = changed.cancelButton;

          }
        }
        

      // console.log(this.buildData);
      this.buildForm(this.buildData);

    });
  }

  buildForm(formData) {
    questions => [] = [];
    this.formFields.length = 0;
    this.buildData = formData;
    let fieldData = [];

    fieldData = this.qcs.buildFields(formData, this.formBuildBaseObj.showFields);

    let addonGroup: any = {};
    let quotationGroup: any = {};
    this.formDataApiData = { "quoteNo": this.quotationNo, "languageCode": "en", 'filterString': "AND q.resourceId = " + this.resourceId };
    this.quotationService.getQuotation(this.formDataApiData).subscribe(resp => {
      console.log(resp, this.resourceId);
      let quotationData: any = [];
      // quotationData = resp.data.filter(items => items.dataId == this.resourceId);
      quotationData = resp.data;
      console.log(quotationData);
      quotationData.map(respData => {
        //  let addonCntrl:any = {};
        let addonGrp: any = {};
        let finalGrp: any = {};
        let addonArr: any = [];
        let finalData: any = [];
        Object.keys(respData).map(splitVal => {
          // console.log(splitVal);
          if (splitVal == "addons") {
            // console.log(respData[splitVal]);
            respData[splitVal].map(addonData => {
              // console.log(addonData);
              let innerAddonArr: any[] = [];
              let addonCntrl = {};
              Object.keys(addonData).map(addonSplit => {
                addonData['formGroupName'] = 'addonId_' + addonData.addonDataId['value'];
                if (typeof addonData[addonSplit] == "object") {
                  // console.log(addonData[addonSplit])

                  //console.log(addonData[addonSplit].value)
                  addonData[addonSplit].fieldColumn = addonSplit;
                  addonData[addonSplit].addonName = addonData.addonName;
                  if (addonData[addonSplit].fieldColumn == 'addonId') {
                    addonData[addonSplit].fieldColumn = 'dataId';
                  }
                  addonData[addonSplit].addonGroupName = 'addonId_' + addonData.addonDataId['value']
                  addonCntrl[addonData[addonSplit].fieldColumn] = new FormControl(addonData[addonSplit].value, Validators.required);
                  // console.log(addonCntrl);
                  if (this.formBuildBaseObj.showFields.hasOwnProperty(addonSplit)) {
                    addonData[addonSplit].visible = true;
                  }
                  innerAddonArr.push(addonData[addonSplit]);
                  // console.log(addonData[addonSplit])
                  //  innerAddonArr['fieldColumn'] =  addonSplit;
                  //  innerAddonArr.push(addonData.addonName)
                }
              })
              //  console.log(innerAddonArr);
              //  innerAddonArr.push({
              //    addonName:addonData.addonName,
              //    addonGroupName:'addonId_' + addonData.addonDataId['value']
              //  })
              addonArr.push(innerAddonArr)
              addonGrp[addonData['formGroupName']] = new FormGroup(addonCntrl);

            })
            finalGrp = new FormGroup(addonGrp);
            addonGroup = finalGrp;
            // console.log(finalGrp, addonArr, fieldData);
            let jsonData = {
              "fieldCaption": "Addon Services",
              "fieldColumn": "addonServices",
              // "isRequired": "0",
              // "isHidden": 0,
              "fieldOrder": 6,
              "fieldType": "tableAddon",
              // "validationRegex": "",
              // "fieldHelpText": "",
              // "fieldHelpTextLong": "",
              // "additionalMetaData": null,
              // "validationMessage": "",
              "visible": true,
              'addonServices': addonArr
            };
            fieldData[fieldData.length] = jsonData
            finalData.push(jsonData);
          } else {
            let contrl: any = {};
            let formGrop: any = {};
            if (typeof respData[splitVal] == 'object') {
              finalData.push(respData[splitVal])
              fieldData.map(fieldRes => {

                if ((fieldRes.fieldType == respData[splitVal].fieldType) && (fieldRes.fieldColumn == splitVal)) {
                  // console.log(fieldRes, respData[splitVal]);
                  fieldRes.value = respData[splitVal].value;
                  if (fieldRes.fieldType == 'calcText') {
                    fieldRes.fieldOrder = 10;
                    if (fieldRes.fieldColumn == 'taxAmount') {
                      if (this.loginData != null) {
                        if (this.loginData.hasOwnProperty('globalConfiguration'))
                          if (Number(this.loginData.globalConfiguration.tax) != NaN)
                            fieldRes.fieldCaption = fieldRes.fieldCaption + ' (' + Number(this.loginData.globalConfiguration.tax) + '%)';
                      }
                    }
                  }

                }
                // if (fieldRes.isRequired === '1') {
                //   contrl[fieldRes.fieldColumn] = new FormControl(fieldRes.value, Validators.required);
                // } else if (fieldRes.isRequired === '0') {
                //   contrl[fieldRes.fieldColumn] = new FormControl(fieldRes.value, Validators.required);
                // }
              })
              // quotationGroup = new FormGroup(contrl);
              quotationGroup = this.qcs.buildControls(fieldData);
            }
          }

        })
        this.finalData.push(finalData)
      })

      //  console.log(fieldData);

      // this.pageData = { ...resp.data };
      // if (this.pageData.workflow.length > 0) {
      //   let crtRoleId;
      //   if (this.authGuardService.getLoginUser().hasOwnProperty('roleDetails'))
      //     crtRoleId = this.authGuardService.getLoginUser().roleDetails.roleId;

      //   this.pageData.workflow = this.pageData.workflow.filter(resp => resp.roles.includes(crtRoleId))
      // }
      // let respData = resp.data;
      // fieldData.map((resp, index) => {
      //   if (respData.hasOwnProperty(resp.key))
      //     resp.value = (respData[resp.key]['value']).toString();
      // });

      this.formFields = fieldData;
      // quotationGroup.controls['addonGroup'] = addonGroup;
      this.formFields.sort((a, b) => a.fieldOrder - b.fieldOrder);
      this.form = quotationGroup;
      this.form.controls['addonGroup'] = addonGroup;
      console.log(quotationGroup, this.formFields)
      let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
      if (postBuildEvFn != '') {
        const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[postBuildEvFn]) {
          let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.formFields };
          let changed = eventCalls[postBuildEvFn](param);
        }
      }
    })


  }

  onSubmit() {
    // console.log(this.form.valid, this.form.controls.addonGroup.valid);

    this.form.controls['quoteNo'].reset({ value: '', disabled: true });
    // this.form.controls.addonGroup = this.form.controls.addonGroup;
    let addonArr = [];
    let quotArr = [];
    let quotJson: any = {};
    if (this.form.valid) {
      // console.log(this.form.value);
      Object.keys(this.form.controls.addonGroup.value).map(resp => {
        // console.log(this.form.controls.addonGroup.value[resp]);
        addonArr.push(this.form.controls.addonGroup.value[resp]);
      })
      let addonApiData = {
        formData: addonArr
      }

      Object.keys(this.form.value).map(key => {
        if (key != 'addonGroup' && key != 'quoteNo') {
          // console.log(key);
          quotArr = [];
          quotJson[key] = this.form.value[key];
          quotArr.push(quotJson);
        }
      })
      //  console.log(addonArr, quotArr);
      //  quotArr[quotArr.length] = {
      //   'addonData':addonArr
      // }
      // console.log(quotArr);
      // this.dialogRef.close(quotArr);
      this.quotationService.submitAddonData(addonApiData).subscribe(addonResp => {
        // console.log(addonResp);
        if (addonResp.status == 'success') {
          this.service.updateFormData(quotJson, this.formBuildBaseObj.formId, this.recordId).subscribe(quotRes => {
            console.log(quotRes);
            this.alertMsg(quotRes);
            if (quotRes.status == 'success') {
              this.formDataApiData = { "quoteNo": this.quotationNo, "languageCode": "en", 'filterString': "AND q.resourceId = " + this.resourceId };
              this.quotationService.getQuotation(this.formDataApiData).subscribe(resp => {
                this.dialogRef.close(resp.data);
              })
              // quotArr[quotArr.length] = {
              //   'addonData':addonArr
              // }
              // console.log(quotArr);
              // this.dialogRef.close(quotArr);
            }
          })
        }
      })
    } else if (this.form.status == "DISABLED") {
      this.dialogRef.close();
    } else {
      this.alert.error("Please fill required fields.");
    }


  }
  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

  ngOnInit() {
  }







}
