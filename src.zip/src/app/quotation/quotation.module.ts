import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Constants } from '../constants';

import {
  MatButtonModule,
  MatCheckboxModule,
  MatToolbarModule,
  MatCardModule,
  MatTabsModule,
  MatInputModule,
  MatIconModule,
  MatGridListModule,
  MatSidenavModule,
  MatListModule,
  MatTableModule,
  MatMenuModule,
  MatFormFieldModule,
  MatSelectModule,
  MatRadioModule,
  MatAutocompleteModule,
  MatTooltipModule,
  MatSnackBarModule,
  MatDialogModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatChipsModule,
  MatExpansionModule,
  MatStepperModule,
  MatSliderModule,
  MatSlideToggleModule
} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ScreenTemplateJsonBuilder } from '../shared/common/screentemplate-jsonbuilder';
import { FormBuildFunctionsService } from '../shared/common/form-build-functions.service';


import { QuotationRoutingModule } from './quotation-routing.module';
import { QuotationComponent } from './quotation.component';
import { ViewQuotationComponent } from './view-quotation/view-quotation.component';
import { QuotationService } from './service/quotation.service';
import { PipeModule } from '../shared/pipes/pipe.module';
import { QuotationDialogComponent } from './quotation-dialog/quotation-dialog.component';
import { AlertModule } from '../alert/alert.module';
import { QuotationDetailComponent } from './view-quotation/quotation-detail/quotation-detail.component';
import { RenderModule } from '../render/render.module';
import { TncComponent } from './view-quotation/tnc/tnc.component';
import { TodoModule } from '../todo/todo.module';
import { QuotationCommonDialogComponent } from './quotation-common-dialog/quotation-common-dialog.component';

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    MatButtonModule,
    MatCheckboxModule,
    MatToolbarModule,
    MatCardModule,
    MatTabsModule,
    MatInputModule,
    MatIconModule,
    MatGridListModule,
    MatSidenavModule,
    MatListModule,
    MatTableModule,
    MatMenuModule,
    MatFormFieldModule,
    MatSelectModule,
    MatRadioModule,
    MatAutocompleteModule,
    MatTooltipModule,
    MatSnackBarModule,
    MatDialogModule,
    MatStepperModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatChipsModule,
    MatExpansionModule,
    MatSliderModule,
    MatSlideToggleModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    QuotationRoutingModule,
    PipeModule,
    AlertModule,
    RenderModule,
    TodoModule
  ],
  declarations: [
    QuotationComponent,
    ViewQuotationComponent,
    QuotationDialogComponent,
    QuotationDetailComponent,
    TncComponent,
    QuotationCommonDialogComponent
  ],
  entryComponents: [QuotationDialogComponent,QuotationCommonDialogComponent],
  providers: [
    Constants,
    QuotationService,
    ScreenTemplateJsonBuilder,
    FormBuildFunctionsService,
  ]
})
export class QuotationModule { }
