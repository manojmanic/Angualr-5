import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../../constants';
import { Observable } from 'rxjs/Observable';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';

@Injectable()
export class QuotationService {

  quotationNo = 'QUOTE120';

  constructor(
    private http: HttpClient,
    private config: Constants,
    private authGuardService: AuthGuardService
  ) {
  }

  getQuotation(apiData): Observable<any> {
    let data = { ...apiData };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new HttpHeaders({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let postUrl = this.config.API_URL + '/api/get_quotation_data';
    return this.http.post(postUrl, data, { headers: head });
  }

  getForm(data): Observable<any> {
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new HttpHeaders({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let postUrl = this.config.API_URL + '/api/get_form';
    return this.http.post(postUrl, data, { headers: head });
  }

  postQuotation(apiData): Observable<any> {
    let data = { ...apiData };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new HttpHeaders({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    let postUrl = this.config.API_URL + '/api/update_form_data';
    return this.http.post(postUrl, data, { headers: head });
  }

  getQuotationList(): Observable<any> {
    let data = {};
    let currentUser = this.authGuardService.getLoginUser();
    let head = new HttpHeaders({
      'Content-Type': 'application/json',
      'Token': currentUser.tokenId
    });
    let postUrl = this.config.API_URL + '/api/get_quotation_data';
    return this.http.post(postUrl, data, { headers: head });
  }

  submitAddonData(apiData): Observable<any> {
    let data = { ...apiData };
    let currentUser = this.authGuardService.getLoginUser();
    let tokenId = this.config.TEMP_TOKEN;
    if (currentUser != null) {
      tokenId = currentUser.tokenId;
    }
    let head = new HttpHeaders({
      'Content-Type': 'application/json',
      'Token': tokenId
    });
    if (localStorage.getItem('selected_language') != null) {
      data['languageCode'] = localStorage.getItem('selected_language');
    }
    let postUrl = this.config.API_URL + '/api/submit_addon_data';
    return this.http.post(postUrl, data, { headers: head });
  }

}
