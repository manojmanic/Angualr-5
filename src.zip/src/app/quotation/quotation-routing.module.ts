import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewQuotationComponent } from './view-quotation/view-quotation.component';
import { QuotationComponent } from './quotation.component';

const routes: Routes = [
    {
        path: '',
        component: QuotationComponent,
        children: [
            // { path: '', redirectTo: 'view/:id' },
            { path: 'view/:id', component: ViewQuotationComponent },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class QuotationRoutingModule {}
