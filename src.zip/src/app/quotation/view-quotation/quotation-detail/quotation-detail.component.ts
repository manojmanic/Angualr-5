import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AuthGuardService } from '../../../shared/guard/auth-guard.service';
import { ActivatedRoute,Router } from '@angular/router';
import { GlobalformService } from '../../../shared/services/globalform.service';
import { MatDialogRef, MatDialog } from '@angular/material';
import { QuotationDialogComponent } from '../../quotation-dialog/quotation-dialog.component';
import { GlobalFunctionService } from '../../../shared/services/global-function.service';
import { QuotationCommonDialogComponent } from '../../quotation-common-dialog/quotation-common-dialog.component';
import { Location } from '@angular/common';

@Component({
  selector: 'app-quotation-detail',
  templateUrl: './quotation-detail.component.html',
  styleUrls: ['./quotation-detail.component.scss']
})
export class QuotationDetailComponent implements OnInit {

  @Input() quotationsDetail: any;
  @Input() workFlowData: any;
  @Input() calcViewShoFields: any;
  @Input() commonViewShoFields: any;
  @Output() quotationReload = new EventEmitter();


  currentUser: any;
  quotationDialog: MatDialogRef<QuotationDialogComponent>;
  quotationCommonDialog: MatDialogRef<QuotationCommonDialogComponent>;

  constructor(private authGuardService: AuthGuardService,
    private activateRoute: ActivatedRoute,
    private service: GlobalformService,
    private gfService: GlobalFunctionService,
    private router: Router,
    private dialog: MatDialog,
    private location: Location) { 
    this.currentUser = this.authGuardService.getLoginUser();
  }

  ngOnInit() {
    this.buildData();
  }

  buildData(){

  }

  ngOnChanges() {
    if (this.workFlowData !== undefined) {
      if (this.workFlowData.length) {
        this.workFlowData.map(resp => {
          
          this.workFlowData = resp;
        })
      }
    }
  }

  goEditRess(loopdata) {
    let resourceId;
    let recordId;
    resourceId = loopdata.find(items => items.fieldKey == 'resourceId');
    recordId = loopdata.find(items => items.fieldKey == 'dataId')
    console.log(loopdata);
    let dialogLoopData = { ...loopdata };
    delete dialogLoopData['DependentList'];
    let dialogData = dialogLoopData;
    this.quotationDialog = this.dialog.open(QuotationDialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.quotationDialog.componentInstance.caseid = 'QuotationResource'; // To get data from json-builder
    this.quotationDialog.componentInstance.dialogData = dialogData; // Pass ResourceId to resourceEdit Component
    this.quotationDialog.componentInstance.resourceId = resourceId.values.value;
    this.quotationDialog.componentInstance.recordId = recordId.values;
    this.quotationDialog.componentInstance.quotationNo = this.gfService.encryptDecryptFun('atob', this.activateRoute.params['value'].id)
    /////////////////// To Populate Resource Details After Edit Resource ////////////////
    this.quotationDialog.afterClosed().subscribe(dialogResp => {
      if(dialogResp) {
        console.log(dialogResp,this.quotationsDetail)
        console.log(this.gfService.buildView(dialogResp, { 'oldData': this.quotationsDetail, 'operation': 'edit' }))
        this.quotationsDetail = this.newBuildFun(dialogResp, { 'oldData': this.quotationsDetail, 'operation': 'edit' });
      }
      // if (dialogResp) {
      //   console.log(this.quotationsDetail, dialogResp, resourceId);
      //   // loopdata.find(items => resourceId = items.dataId)
      //   this.quotationsDetail.map(finalDataRes => {
      //     console.log(finalDataRes);
      //     finalDataRes.map(innerData => {
      //       if (innerData.fieldKey == 'resourceId' && innerData.values.value == resourceId.values.value) {
      //       console.log(innerData, finalDataRes);
      //         dialogResp.map(splitRes => {
                
      //           if (splitRes.addonData) {
      //             splitRes.addonData.map(dialogAddon => {
      //               finalDataRes.map(splitfinalRes => {
      //                 if (splitfinalRes.fieldType == 'tableAddon') {
      //                   splitfinalRes.addonServices.map(addonRes => {
      //                     addonRes.map(innerAddonRes => {
                            
      //                       if (innerAddonRes.dataId == dialogAddon.dataId) {
      //                         innerAddonRes.value = dialogAddon.rate;
      //                       }
      //                     })
      //                   })
      //                 }
      //               })
      //             })
      //           }
      //           else {
      //             Object.keys(splitRes).map(key => {
      //               finalDataRes.map(splitfinalRes => {
      //                 if (key == splitfinalRes.fieldColumn) {
      //                   splitfinalRes.value = splitRes[key]
      //                 }
      //               })
      //             })
      //           }
      //         })
      //       }
      //     })
      //   })

      // }
    });
  }

  updateVisaInfo(loopdata) {
    let resourceId;
    let recordId;
    let quoteNo;
    resourceId = loopdata.find(items => items.fieldKey == 'resourceId');
    quoteNo = loopdata.find(items => items.fieldKey == 'quoteNo');
    recordId = loopdata.find(items => items.fieldKey == 'dataId')
    console.log(loopdata, resourceId, recordId);
    let dialogLoopData = { ...loopdata };
    delete dialogLoopData['DependentList'];
    let dialogData = loopdata;
    this.quotationCommonDialog = this.dialog.open(QuotationCommonDialogComponent
      , {
        height: '80%',
        width: '80%'
      });
    this.quotationCommonDialog.componentInstance.caseId = 'QuotationResourceVisaInfo'; // To get data from json-builder
    this.quotationCommonDialog.componentInstance.dialogData = dialogData; // Pass ResourceId to resourceEdit Component
    this.quotationCommonDialog.componentInstance.resourceId = resourceId.values.value;
    this.quotationCommonDialog.componentInstance.recordId = recordId.values;
    // this.quotationCommonDialog.componentInstance.quotationNo = this.gfService.encryptDecryptFun('atob', this.activateRoute.params['value'].id)
    /////////////////// To Populate Resource Details After Edit Resource ////////////////
    this.quotationCommonDialog.afterClosed().subscribe(dialogResp => {
      if(dialogResp) {
        // console.log(dialogResp,this.quotationsDetail, quoteNo, this.gfService.encryptDecryptFun('btoa',quoteNo.values.value))
        this.quotationReload.emit();
        // location.reload();
        // this.router.navigated = false;
        // this.router.navigate([this.router.url]);
        // this.router.navigate(['quotation/view', this.gfService.encryptDecryptFun('btoa',quoteNo.values.value)]);
        // this.quotationsDetail = this.newBuildFun(dialogResp, { 'oldData': this.quotationsDetail, 'operation': 'edit' });
      }
      // if (dialogResp) {
      //   console.log(this.quotationsDetail, dialogResp, resourceId);
      //   // loopdata.find(items => resourceId = items.dataId)
      //   this.quotationsDetail.map(finalDataRes => {
      //     console.log(finalDataRes);
      //     finalDataRes.map(innerData => {
      //       if (innerData.fieldKey == 'resourceId' && innerData.values.value == resourceId.values.value) {
      //       console.log(innerData, finalDataRes);
      //         dialogResp.map(splitRes => {
                
      //           if (splitRes.addonData) {
      //             splitRes.addonData.map(dialogAddon => {
      //               finalDataRes.map(splitfinalRes => {
      //                 if (splitfinalRes.fieldType == 'tableAddon') {
      //                   splitfinalRes.addonServices.map(addonRes => {
      //                     addonRes.map(innerAddonRes => {
                            
      //                       if (innerAddonRes.dataId == dialogAddon.dataId) {
      //                         innerAddonRes.value = dialogAddon.rate;
      //                       }
      //                     })
      //                   })
      //                 }
      //               })
      //             })
      //           }
      //           else {
      //             Object.keys(splitRes).map(key => {
      //               finalDataRes.map(splitfinalRes => {
      //                 if (key == splitfinalRes.fieldColumn) {
      //                   splitfinalRes.value = splitRes[key]
      //                 }
      //               })
      //             })
      //           }
      //         })
      //       }
      //     })
      //   })

      // }
    });
  }
  newBuildFun(data, arrAlterData) {
    console.log(JSON.parse(JSON.stringify(data)));
    let finalData: any = [];
    data.map(resp => {
      let innerArr = [];
      let reqPreview_value = [];
      let innerJson: any = {};
      let resourceDependentName;
      Object.keys(resp).map(key => {
          let obj = {
            fieldKey: key,
            values: resp[key]
          }
          innerArr.push(obj);
      })
      finalData.push(innerArr);
    })
    let innerFinalData;
    if (arrAlterData != '') {
      if (arrAlterData.operation == 'edit') {
        console.log(arrAlterData.oldData, finalData)
        innerFinalData = arrAlterData.oldData;
        finalData.map((finalData) => {
          finalData.map(finalDataResp => {

            innerFinalData.map((alterResp, index) => {
              alterResp.map((innerResp) => {
                if (finalDataResp.fieldKey == 'dataId' && innerResp.fieldKey == 'dataId') {
                  if (finalDataResp.values == innerResp.values.value) {
                    let filterAlterResp = finalData.filter(items => {
                      if (typeof items.values == 'object' && items.values != null) {
                        return items;
                      }
                    })
                    filterAlterResp.map(resp => {

                      alterResp.map(innerResp => {
                        if (typeof innerResp.values == 'object') {
                          if (resp.values.fieldId == innerResp.values.fieldId) {
                            innerResp.values = resp.values;
                          }
                        }
                      })
                    })
                    innerFinalData[index] = alterResp;
                  }
                }
              })
            })
          })
        })
        finalData = innerFinalData;
      } else
        if (arrAlterData.operation == 'add') {
          // finalData = arrAlterData.oldData.push(finalData[0]);
          // arrAlterData.oldData.push(finalData);
          // if(arrAlterData.oldData.length > 0)
          arrAlterData.oldData.push(finalData[0]);
          finalData = arrAlterData.oldData;
        }
    } else {
      finalData = finalData;
    }
    console.log(finalData);
    return finalData;
  }

  paynow() {
    let reqId;
    this.quotationsDetail.map(resp =>{
      reqId = resp.find(items => items.fieldKey == 'reqId');
    })
    
    console.log(reqId.values.value);
    this.router.navigate(['/payment',reqId.values.value]);

  }

}
