import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { QuotationService } from '../service/quotation.service';
import { QuestionBase } from '../../shared/models/question-base';
import { FormControl, FormGroup, Validators, FormArray } from '@angular/forms';
import { TextboxQuestion } from '../../shared/models/question-textbox';
import { DropdownQuestion } from '../../shared/models/question-dropdown';
import { CheckboxQuestion } from '../../shared/models/question-checkbox';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { GlobalformControlService } from '../../shared/services/globalform-control.service';
import { GlobalformService } from '../../shared/services/globalform.service';
import { MatDialog, MatDialogRef } from '@angular/material';
import { QuotationDialogComponent } from '../quotation-dialog/quotation-dialog.component';
import { GlobalFunctionService } from '../../shared/services/global-function.service';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { Constants } from '../../constants';
import { AlertService } from '../../shared/services/alert-service.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-view-quotation',
  templateUrl: './view-quotation.component.html',
  styleUrls: ['./view-quotation.component.scss']
})
export class ViewQuotationComponent implements OnInit {

  formBuildBaseObj;
  form_title;
  params;
  formFields: QuestionBase<any>[] = [];
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  buildData: any;
  formLoopData: any = [];
  pageData: any;
  buttonData: any;
  quotationDialog: MatDialogRef<QuotationDialogComponent>;
  loopData: any = [];
  recordId: any;
  formDataApiData;
  finalData: any = [];
  breadcrumbs: any;
  subTitle: string;
  workFlowData;
  projectDet: any = [];
  projectDet_Value: any = [];
  showFieldsList: any;
  showFieldsListResourceCal: any;
  showFieldsListResource: any;
  currentUser: any;
  alertMsg = false;
  remarks: any = '';

  constructor(
    private router: Router,
    public config: Constants,
    private dialog: MatDialog,
    private gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private activateRoute: ActivatedRoute,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private fbbService: FormBuildBaseService,
    private quotationService: QuotationService,
    private authGuardService: AuthGuardService,
    private location: Location,
    private alert: AlertService) {
    this.currentUser = this.authGuardService.getLoginUser();
    this.quotationDetails();
  }

  quotationDetails() {
    this.recordId = this.gfService.encryptDecryptFun('atob', this.activateRoute.params['value'].id);
    this.formDataApiData = { "quoteNo": this.recordId, "languageCode": "en" }
    //  this.params = this.activateRoute.params['value'].id;
    this.formBuildBaseObj = this.screenTB.formView('viewQuotation');
    let formBuildBaseObjResourceCal = this.screenTB.formView('viewQuotationResource');
    let formBuildBaseObjResource = this.screenTB.formView('viewQuotationResourceVisa');
    this.form_title = this.formBuildBaseObj.title;
    this.showFieldsList = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    this.showFieldsListResourceCal = Array.from(Object.keys(formBuildBaseObjResourceCal.showFields));
    this.showFieldsListResource = Array.from(Object.keys(formBuildBaseObjResource.showFields));
    this.quotationService.getQuotation(this.formDataApiData).subscribe(resp => {
      if (resp.status == 'success') {
        this.projectDet.push(resp.data);

        let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, resp: resp.data };
            let changed = eventCalls[preBuildEvFn](param);
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
          }
        }

        let preBuildEvFnResourceCal = formBuildBaseObjResourceCal.eventHandler.preBuild;
        if (preBuildEvFnResourceCal != '') {
          const eventCalls = (this.fbbService[preBuildEvFnResourceCal]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFnResourceCal]) {
            let param = { formId: formBuildBaseObjResourceCal.formId, resp: resp.data };
            let changed = eventCalls[preBuildEvFnResourceCal](param);
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
          }
        }

        let preBuildEvFnResource = formBuildBaseObjResource.eventHandler.preBuild;
        if (preBuildEvFnResource != '') {
          const eventCalls = (this.fbbService[preBuildEvFnResource]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFnResource]) {
            let param = { formId: formBuildBaseObjResource.formId, resp: resp.data };
            let changed = eventCalls[preBuildEvFnResource](param);
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
          }
        }

        // console.log(this.gfService.valueConversion(resp.data), resp.data);
        // this.finalData = this.quotationBuild(resp);
        setTimeout(() => {

          this.finalData = this.gfService.valueConversion(resp.data);

          let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
          if (postBuildEvFn != '') {
            const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[postBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, rawData: this.finalData };
              let changed = eventCalls[postBuildEvFn](param);
            }
          }

          let postBuildEvFnResourceCal = formBuildBaseObjResourceCal.eventHandler.postBuild;
          if (postBuildEvFnResourceCal != '') {
            const eventCalls = (this.fbbService[postBuildEvFnResourceCal]) ? this.fbbService : this.fbfService;
            if (eventCalls[postBuildEvFnResourceCal]) {
              let param = { formId: formBuildBaseObjResourceCal.formId, rawData: this.finalData };
              let changed = eventCalls[postBuildEvFnResourceCal](param);
            }
          }

          let postBuildEvFnResource = formBuildBaseObjResource.eventHandler.postBuild;
          if (postBuildEvFnResource != '') {
            const eventCalls = (this.fbbService[postBuildEvFnResource]) ? this.fbbService : this.fbfService;
            if (eventCalls[postBuildEvFnResource]) {
              let param = { formId: formBuildBaseObjResource.formId, rawData: this.finalData };
              let changed = eventCalls[postBuildEvFnResource](param);
            }
          }
          let workFlowApiData = { "docTranRef": this.recordId };
          this.service.getWorkFlowRecordDetail(workFlowApiData).subscribe(resp => {
            if (resp.status == 'success') {
              this.workFlowData = resp.data;
            }
          })
        }, this.config.FORM_LOADING_SEC);

        ///////////////////////To Get Project Details Values /////////////////////////
        // for (let i = 0; i < this.projectDet.length; i++) {
        //   this.projectDet_Value = [];
        //   for (var key in this.projectDet[i]) {
        //     if (key != null && key != '' && this.projectDet[i][key] != null && key != "reqDataId" && key != "resourceDetails") {
        //       let obj = {
        //         fieldKey: key,
        //         values: this.projectDet[i][key],
        //       }
        //       this.projectDet_Value.push(obj);
        //     }
        //   }
        // }

      }
    })
  }

  ngOnInit() {
  }


  // goEditDep(loopdata, resId) {
  //   let dialogLoopData = { ...loopdata };
  //   let dialogData = dialogLoopData;
  //   this.quotationDialog = this.dialog.open(QuotationDialogComponent
  //     , {
  //       height: '500px',
  //       width: '500px'
  //     });

  //   this.quotationDialog.componentInstance.caseid = 'QuotationDependent'; // To get data from json-builder
  //   this.quotationDialog.componentInstance.dialogData = dialogData;
  //   this.quotationDialog.componentInstance.resId = resId;

  //   //////////// To Populate Dependent List After Edit Dependent ////////////////////
  //   this.quotationDialog.afterClosed().subscribe(dialogResp => {
  //     if (dialogResp) {
  //       let resJson = this.pageData.resourceDetails.find(resValue => resValue.dataId == dialogResp.resId);
  //       resJson.DependentList.map((resp, index) => {
  //         if (resp.dataId == dialogResp.dataId) {
  //           Object.keys(dialogResp).map(items => {
  //             if (typeof resp[items] != 'undefined' && resp[items].hasOwnProperty('value'))
  //               resp[items].value = dialogResp[items];
  //           })
  //         }
  //       });
  //     }
  //     this.calculation();
  //   });
  // }



  workFlowForward(workFlowData) {
    let initiatorApprover = 0;
    if (workFlowData.tranRole == 'InitiatorApprover') {
      initiatorApprover = 1;
    }
    let workFlowApiData = {
      "routeId": this.config.ROUTE_ID_QUOTATION,
      "workflowId": workFlowData.workflowId,
      "routeStageNum": workFlowData.routeStageNum,
      "initiatorApprover": initiatorApprover
    }
    this.alertMsg = true;
    this.service.createWorkflowTransaction(workFlowApiData).subscribe(resp => {

      if (resp.status == 'success') {
        this.workFlowData.map(workflow => {
          if (workflow.workflowId == workFlowData.workflowId) {
            this.workFlowData.pop(workflow);
          }
        });
        this.alert.success(resp.message);
      } else {
        this.alert.error(resp.message);
      }
    });
  }

  workFlowApproveReject(workFlowData, state) {
    let initiatorApprover = 0;
    this.alertMsg = true;
    if (workFlowData.tranRole == 'InitiatorApprover') {
      initiatorApprover = 1;
    }
    let workFlowApiData = {
      "routeId": this.config.ROUTE_ID_QUOTATION,
      "workflowStageId": workFlowData.workFlowStageId,
      "actionId": workFlowData.actionId,
      "workflowId": workFlowData.workflowId,
      "routeStageNum": workFlowData.routeStageNum,
      "initiatorApprover": initiatorApprover,
      "status": state,
      "remarks": this.remarks
    }

    this.service.processWorkflowAction(workFlowApiData).subscribe(resp => {

      if (resp.status == 'success') {
        if (state == 'Approved') {
          let workFlowMailApiData = { "quoteNo": workFlowData.docTranRef, "quotationUrl": document.location.origin + '/#' + this.location.path() }
          this.service.workFlowMail(workFlowMailApiData).subscribe(mailResp => {

          });
        }
        this.workFlowData.map(workflow => {
          if (workflow.workflowId == workFlowData.workflowId) {
            this.workFlowData.pop(workflow);
          }
        });
        this.alert.success(resp.message);
      } else {
        this.alert.error(resp.message);
      }
    });
  }

}
