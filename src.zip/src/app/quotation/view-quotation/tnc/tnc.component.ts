import { Component, OnInit } from '@angular/core';
import { ScreenTemplateJsonBuilder } from '../../../shared/common/screentemplate-jsonbuilder';
import { FormBuildBaseService } from '../../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../../shared/common/form-build-functions.service';

@Component({
  selector: 'app-tnc',
  templateUrl: './tnc.component.html',
  styleUrls: ['./tnc.component.scss']
})
export class TncComponent implements OnInit {

  tncData: string;
  clientName;
  subTitle;
  breadcrumbs;
  formBuildBaseObj;
  finalData;
  formatData = {};
  
  constructor(
    private fbbService: FormBuildBaseService,
    private fbfService: FormBuildFunctionsService,
    private screenTB: ScreenTemplateJsonBuilder) {
    this.formBuildBaseObj = this.screenTB.formView('tnc');

    this.clientName = 'BabuGuru';

    // this.tncData = `<dl>
    //   <dt>a. The Quote is Valid for 7 working days</dt>
    //   <dt>b. Tickets will be on actual + 15% Service Charge in case it is selected by {{Client}}</dt>
    //   <dt>c. Leave Salary & End of Service benefit - will be on actual + 15% Service Charge</dt>
    //   <dt>d. Payment should be transferred before 22nd of every month along with the break up of the payment of individual candidate so that the Salary can be processed to candidate by month end.</dt>
    //   <dt>e. Any change in Govt related policies will have implications on the Cost.</dt>
    //   <dt>f. Attestation of documents like PCC (police Clearance Certificate) / Good Conduct Certificate, MOFA should be submitted on time, otherwise there will be implication on Visa Processing</dt>
    //   <dt>g. Month on month cost to transferred till the VISA is active.</dt>
    //   <dt>h. Timeline to be mentioned here which should be configurable on case to case basis.</dt>
    //   <dt>i. In case Travel (add-on) is not selected by {{Client}}, Travel related process has to be taken care by {{Client}} (name to be mentioned here)</dt>
    //   <dt>j. In case of any dependents, the cost will be charged on actuals + 15%</dt>
    //   <dt>k. Visa Processing will be done only on receiving payment on one-time charges.</dt>
    //   <dt>l. Any bank transfer other than salary will invite adtitional 7% charge </dt>
    //   <dt>m. All personal (Annual tickets) should be taken care by Candidate/Client</dt>
    //   <dt>n. Accommodation should be taken care by {{Candidate}}/Client</dt>
    //   <dt>o. Any Medical Tests in Home Country has to be taken care by {{Client}}</dt>
    //   <dt>p. All payments should be transferred in USD or AED</dt>
    //   <dt>q. In case of Local Income Tax applicable, the amount will be deducted from the monthly salary of the candidate.</dt>
    //   <dt>r. One time components Renewals wherever apllicable (Eg: Medical insurance) will be charged seperately. </dt>
    //   <dt>s. Additional charges will be applicable for any incidental situations.</dt>
    //   <dt>t. All Visa related documents should be provided within the time frame to ensure Visa processing on time.</dt>
    //   <dt>u. Original passport should be handed over to FFI as applicable</dt>
    //   <dt>v. Attestation for candiates who reside outside India will have adtitional charges</dt>  
    //   <dt>w. Attestation of other nationalties should be taken care by self.</dt>
    //   <dt>x. Dispute Clause - Any matter or issues arising hereunder or any dispute hereunder shall be subject to the exclusive jurisdiction of the courts of law situated at XY</dt>
    // </dl>`;
    this.tncData = `a. The Quote is Valid for 7 working days
    b. Tickets will be on actual + 15% Service Charge in case it is selected by {{Client}}.
    c. Leave Salary & End of Service benefit - will be on actual + 15% Service Charge.
    d. Payment should be transferred before 22nd of every month along with the break up of the payment of individual candidate so that the Salary can be processed to candidate by month end.
    e. Any change in Govt related policies will have implications on the Cost.
    f. Attestation of documents like PCC (police Clearance Certificate) / Good Conduct Certificate, MOFA should be submitted on time, otherwise there will be implication on Visa Processing.
    g. Month on month cost to transferred till the VISA is active.
    h. Timeline to be mentioned here which should be configurable on case to case basis.
    i. In case Travel (add-on) is not selected by {{Client}}, Travel related process has to be taken care by {{Client}} (name to be mentioned here).
    j. In case of any dependents, the cost will be charged on actuals + 15%.
    k. Visa Processing will be done only on receiving payment on one-time charges.
    l. Any bank transfer other than salary will invite adtitional 7% charge.
    m. All personal (Annual tickets) should be taken care by Candidate/Client.
    n. Accommodation should be taken care by {{Candidate}}/Client.
    o. Any Medical Tests in Home Country has to be taken care by {{Client}}.
    p. All payments should be transferred in USD or AED.
    q. In case of Local Income Tax applicable, the amount will be deducted from the monthly salary of the candidate.
    r. One time components Renewals wherever apllicable (Eg: Medical insurance) will be charged seperately.
    s. Additional charges will be applicable for any incidental situations.
    t. All Visa related documents should be provided within the time frame to ensure Visa processing on time.
    u. Original passport should be handed over to FFI as applicable
    v. Attestation for candiates who reside outside India will have adtitional charges
    w. Attestation of other nationalties should be taken care by self
    x. Dispute Clause - Any matter or issues arising hereunder or any dispute hereunder shall be subject to the exclusive jurisdiction of the courts of law situated at XY
    `;

    let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, rawData: this.tncData };
            let changed = eventCalls[preBuildEvFn](param);
            this.breadcrumbs = changed.breadcrumbs;
            this.subTitle = changed.subTitle;
            this.formatData = changed.stringFormatData;
          }
        }

        this.finalData = this.tncData;

        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, rawData: this.finalData };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
  }

  ngOnInit() {
    // this.formatData = { Client: this.clientName };
  }

}
