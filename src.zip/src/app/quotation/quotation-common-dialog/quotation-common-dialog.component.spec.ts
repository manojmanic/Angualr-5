import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotationCommonDialogComponent } from './quotation-common-dialog.component';

describe('QuotationCommonDialogComponent', () => {
  let component: QuotationCommonDialogComponent;
  let fixture: ComponentFixture<QuotationCommonDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuotationCommonDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuotationCommonDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
