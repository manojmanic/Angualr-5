import { Component, OnInit } from '@angular/core';
import { QuestionBase } from '../../shared/models/question-base';
import { FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { GlobalFunctionService } from '../../shared/services/global-function.service';
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { GlobalformService } from '../../shared/services/globalform.service';
import { GlobalformControlService } from '../../shared/services/globalform-control.service';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { QuotationService } from '../service/quotation.service';
import { AlertService } from '../../shared/services/alert-service.service';
import { MatDialogRef } from '@angular/material';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { TextboxQuestion } from '../../shared/models/question-textbox';
import { DropdownQuestion } from '../../shared/models/question-dropdown';
import { CheckboxQuestion } from '../../shared/models/question-checkbox';
import { Constants } from '../../constants';

@Component({
  selector: 'app-quotation-common-dialog',
  templateUrl: './quotation-common-dialog.component.html',
  styleUrls: ['./quotation-common-dialog.component.scss']
})
export class QuotationCommonDialogComponent implements OnInit {

  caseId: any;
  projectDetails: any = [];
  formBuildBaseObj: any;
  form_title: any;
  questions: QuestionBase<any>[] = [];
  buildData: any;
  buttonData: any;
  cancelButton: any;
  form: FormGroup;
  fieldGroupId: number[] = [];
  FieldGroupName: any[] = [];
  _touched: boolean;
  recordId: any;
  resourceId: any;
  dialogData: any;

  constructor(
    private router: Router,
    private gfService: GlobalFunctionService,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private activateRoute: ActivatedRoute,
    private service: GlobalformService,
    private qcs: GlobalformControlService,
    private fbbService: FormBuildBaseService,
    private quotationService: QuotationService,
    private alert: AlertService,
    private config: Constants,
    public dialogRef: MatDialogRef<QuotationCommonDialogComponent>,
    private authGuardService: AuthGuardService) { }

  ngOnInit() {
    // this.route.params.subscribe(params => this.params = params);
    this.formBuildBaseObj = this.screenTB.formEdit(this.caseId);
    this.form_title = this.formBuildBaseObj.title;
    this.service.getForms(this.formBuildBaseObj.formId).subscribe(data => {
      this.buildData = data.data;
      console.log(data);
      
      let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.recordId } };
      this.service.getFormData(apiData).subscribe(resp => {
        let formGroups = this.buildData.fieldGroup;
        formGroups.filter(formGroupsData => {
          let formFields = formGroupsData.FieldList;
          formFields.filter(getForm => {
            resp.data.map(getFormData => {
              Object.keys(getFormData).map(key => {
                if (typeof getFormData[key] == 'object' && getFormData[key] != null) {
                  if (getFormData[key].fieldId == getForm.fieldId) {
                    getForm.value = getFormData[key].value;
                  }
                }
              })
            })
          })
        })
        let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
        if (preBuildEvFn != '') {
          const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[preBuildEvFn]) {
            let param = { formId: this.formBuildBaseObj.formId, formItems: this.buildData };
            let changed = eventCalls[preBuildEvFn](param);
            this.buttonData = changed.buttonData;
            this.buildData = changed.formItems;
            this.cancelButton = changed.cancelButton;
          }
        }
        setTimeout(() => {
          let buildData = this.qcs.buildForm(this.buildData, this.formBuildBaseObj.showFields);
          this.questions = buildData['fields'];
          this.form = buildData['controls'];
          let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
          if (postBuildEvFn != '') {
            const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[postBuildEvFn]) {
              let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions, getFormData: resp.data, dialogData: this.dialogData };
              let changed = eventCalls[postBuildEvFn](param);
              this.questions = changed.rawData;
            }
          }
        }, this.config.FORM_LOADING_SEC);
      // const subEve = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
      // subEve.invokeEvent.subscribe((value) => {
      //   this.buildForm(value.some.formItems);
      // });
      // this.buildForm(this.buildData);
    })
  })
  }
  // buildForm(formData) {

  //   questions => [] = [];
  //   this.questions.length = 0;
  //   this.buildData = formData;
  //   let fieldData = [];
  //   let fieldGroupData = [];
  //   let fieldGroupIdData = [];

  //   /////// To Get fieldGroupId ///////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     this.FieldGroupName.push(this.buildData.fieldGroup[i].FieldGroupName);
  //     this.fieldGroupId.push(this.buildData.fieldGroup[i].fieldGroupId);
  //   }

  //   /////// To Get FieldList /////////////////////
  //   for (var i = 0; i < this.buildData.fieldGroup.length; i++) {
  //     for (var j = 0; j < this.fieldGroupId.length; j++) {
  //       if (this.buildData.fieldGroup[i].fieldGroupId === this.fieldGroupId[j]) {
  //         for (var k = 0; k < this.buildData.fieldGroup[i].FieldList.length; k++) {
  //           let pushData;
  //           pushData = this.buildData.fieldGroup[i].FieldList[k];
  //           pushData.visible = false;
  //           if (this.formBuildBaseObj.showFields.hasOwnProperty(pushData.fieldColumn)) {
  //             pushData.visible = true;
  //           }
  //           if (pushData.fieldType === 'shortText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'currencyText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'calcText') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'text') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'customListAdditionalDetail') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'simpleListMultiSelect') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'singleSelectOption') {
  //             let options = [
  //               { key: 'yes', value: 'Yes' },
  //               { key: 'no', value: 'No' },
  //             ]
  //             pushData.additionalMetaData = options;
  //             fieldData.push(new CheckboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'radio') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceList') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'termsReferenceListMulti') {
  //             fieldData.push(new DropdownQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'fileImage') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //           if (pushData.fieldType === 'date') {
  //             fieldData.push(new TextboxQuestion(pushData));
  //           }
  //         }
  //       }
  //     }
  //   }


  //   /////////////// Final Update ////////////////
  //   //  console.log(this.projectDetails,fieldData);
  //   console.log(this.recordId);
  //   let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.recordId } };
  //   this.service.getFormData(apiData).subscribe(resp => {
  //     resp.data.map(innerResp => {
  //       Object.keys(innerResp).map(key => {
  //         fieldData.map(fieldResp => {
  //           if (innerResp[key] != null && typeof innerResp[key] == 'object') {
  //             if (innerResp[key].fieldType == fieldResp.fieldType) {
  //               if (innerResp[key].fieldId == fieldResp.fieldId) {
  //                 console.log(resp);
  //                 fieldResp.value = innerResp[key].value;
  //               }
  //             }
  //           }
  //         })
  //       })
  //     })


  //     console.log(fieldData)
  //     this.questions = fieldData;
  //     this.questions.sort((a, b) => a.fieldOrder - b.fieldOrder);
  //     this.form = this.qcs.toFormGroup(this.questions);
  //     let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
  //     if (postBuildEvFn != '') {
  //       const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
  //       if (eventCalls[postBuildEvFn]) {
  //         let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions, getFormData: resp.data, dialogData: this.dialogData };
  //         let changed = eventCalls[postBuildEvFn](param);

  //         this.questions = changed.rawData;
  //       }
  //     }
  //   })
  // }


  markAsTouched() {
    this._touched = true;
  }

  onSubmit() {
    let preSubmitEvFn = this.formBuildBaseObj.eventHandler.preSubmit;
    let status;
    if (preSubmitEvFn != '') {
      const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
      if (eventCalls[preSubmitEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId, formItems: this.form, rawData: this.questions };
        let changed = eventCalls[preSubmitEvFn](param);
        this.form = changed.formItems;
        status = changed.status;
      }
    }
    console.log(this.form, this.recordId, this.resourceId);
    if (this.form.valid) {
      if (status != "DeActivated") {

        this.service.updateFormData(this.form.value, this.formBuildBaseObj.formId, this.resourceId).subscribe(resp => {
          console.log(resp);
          this.alertMsg(resp);
          let apiData = { "formId": this.formBuildBaseObj.formId, "filterString": { dataId: this.resourceId } };
          this.service.getFormData(apiData).subscribe(resp => {
            console.log(resp);
            this.dialogRef.close(resp.data);
          })
        });
      }
      else {
        this.alert.error("Please fill Active fields.");
      }
    } else if (this.form.status == "DISABLED") {
      this.dialogRef.close();
    } else {
      this.questions.map(resp => {
        if (this.form.controls[resp.fieldColumn].touched == false && this.form.controls[resp.fieldColumn].status == "INVALID") {

          this.form.controls[resp.fieldColumn].markAsTouched();

        }
      })
      this.alert.error("Please fill required fields.");
    }
  }

  alertMsg(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.alert.success(message);
    }
    else {
      this.alert.error(message);
    }
  }

}
