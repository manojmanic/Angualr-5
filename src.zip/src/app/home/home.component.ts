import { Component } from '@angular/core';

import {AlertService} from '../shared/services/alert-service.service';

@Component({
    moduleId: module.id,
    templateUrl: 'home.component.html',
    styleUrls: ['home.component.scss']
})

export class HomeComponent {

    id = 'chart1';
    width = 600;
    height = 400;
    type = 'column2d';
    dataFormat = 'json';
    dataSource:any;
    title = 'Reqruit DashBoard';

    constructor() {
        this.dataSource = {
            "chart": {
                "caption": "Reqruit Contract",
                "subCaption": "Top 5 Contract city in last month by revenue",
                "numberprefix": "$",
                "theme": "green"
            },
            "data": [
                {
                    "label": "UAE",
                    "value": "880000"
                },
                {
                    "label": "QATAR",
                    "value": "730000"
                },
                {
                    "label": "BAHRIN",
                    "value": "590000"
                },
                {
                    "label": "DUBAI",
                    "value": "520000"
                },
                {
                    "label": "ABU-DHABI",
                    "value": "330000"
                }
            ]
        }
    }
}

    
