import { Component, OnInit, Input } from '@angular/core';
import { GlobalformService } from '../../shared/services/globalform.service';
import { ActivatedRoute } from '@angular/router';
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { MatDatepickerInputEvent } from '@angular/material';
import { DatePipe } from '@angular/common';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { GlobalFunctionService } from '../../shared/services/global-function.service';
import { Router } from '@angular/router';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { FormControl,FormGroup } from '@angular/forms';
import { Constants } from '../../constants';
import { QuestionBase } from '../../shared/models/question-base';
import { GlobalformControlService } from '../../shared/services/globalform-control.service';

@Component({
  selector: 'app-quotation',
  templateUrl: './quotation.component.html',
  styleUrls: ['./quotation.component.scss']
})
export class QuotationComponent implements OnInit {
  @Input() caseId: any;
  group:any = {};
  form:any;
  formBuildBaseObj: any;
  quotationList: any = [];
  breadcrumbs: any;
  fieldList: QuestionBase<any>[] = [];
  buildData: any;
  filterFields: any = [];
  subTitle: any;
  headerData: any;
  footerData: any;
  currentUser: any;
  cusData: any = [];
  sortData:any;
  searchDataArr:any;
  apiData: any;
  searchString:any = {};
  pageSize:any;
  constructor(
    private service: GlobalformService,
    private route: ActivatedRoute,
    private screenTB: ScreenTemplateJsonBuilder,
    private authGuardService: AuthGuardService,
    private gfService: GlobalFunctionService,
    public qcs: GlobalformControlService,
    private router: Router,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private config: Constants
  ) { 
    // let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
    // this.service.getCustomList(data).subscribe(resp => {
    //   Object.keys(resp.data).map(key => {
    //     this.cusData.push({ key, value: resp.data[key] });
    //   });
    // });
  }

  onChange(data) {
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    for (let obj of this.formBuildBaseObj.forms) {
      //apiData = { "formId": obj.formId, "filterString": { filterBy:"AND r.country ="  + data.value,"userId": this.currentUser.id } , "languageCode": "en" };
      let preSubmitEvFn = obj.eventHandler.preSubmit;
      let form = this.form;
      if (preSubmitEvFn != '') {
        const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preSubmitEvFn]) {
          let param = { formId: obj.formId, formItems: form, route: this.route,data:data,apiData:this.apiData};
          let changed = eventCalls[preSubmitEvFn](param);
          form = changed.formItems;
          this.apiData = changed.apiData
          this.apiData['pageNumber'] = 1;
          this.apiData['limit'] = this.pageSize;
          // console.log( changed.apiData);
          if(Object.keys(this.searchString).length) {
           this.apiData.filterString['searchString'] = this.searchString.searchString;
          }
        }
      }
      this.service.getQuotationList(this.apiData).subscribe(resp => {
        console.log(resp,this.apiData);
        if(resp.status == "success"){
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.quotationList = [];
          this.quotationBuild(resp);

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.quotationList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
          // this.quotationList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });
        }else if(resp.status == "success"){
          this.quotationList.records = [];
        }
      });
    }
  }

  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    this.currentUser = this.authGuardService.getLoginUser();
    this.pageSize = this.config.PG_LIMIT_DEFAULT;
    for (let obj of this.formBuildBaseObj.forms) {
      console.log(obj)
      this.apiData = {"pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT,"filterString": {}};
      this.service.getQuotationList(this.apiData).subscribe(resp => {
        // console.log(resp,this.apiData)
        let quotationList;
        if (resp.status == 'success') {
          quotationList = resp.data;
          this.quotationBuild(resp);
          // this.quotationList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
              this.filterFields = changed.filterFields;
              this.searchDataArr = changed.searchData;
              // this.requirementList = changed.requirementData;
              // contractListArr = changed.contractData;
            }
          }

          setTimeout(() => {
            this.buildData = {
              'fieldGroup': [{ 'FieldList': this.filterFields}]
            }
            console.log(this.buildData);
            let buildData = this.qcs.buildForm(this.buildData);
            this.fieldList = buildData['fields'];
            this.form = buildData['controls'];
            console.log(buildData, this.buildData, this.formBuildBaseObj.showFields);
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.quotationList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
         

        }
      })
    }

  }

  quotationBuild(resp){
    let result = [];
    let quotationRecords = [];
    let groups = Object.create(null);
    let subTotal = 0;
    let visaAmount = 0;
    let totalAmount = 0;
    let taxAmount = 0;
    let passportStampingCost = 0;
    let groupData = resp.data;
    let quoteList = [];
    let quotationListArr = [];
    groupData.map((quotation, index) => {
      quoteList.push(quotation.quoteNo.value);
    });
    quoteList = this.gfService.removeDuplicateArr(quoteList);
    quoteList.map((quotation, index) => {

      let innerArr = [];
      // requirementListArr = [];
      // requirement.showFields = obj.showFields;
      // requirement.operations = obj.operations;
      // requirement.title = obj.title;
      // quotation.map((item, index) => {
      // if (!groups[groupData[index].quoteNo.value]) {
      //   groups[groupData[index].quoteNo.value] = [];
      // }
      let jsonObj = {};
      let particularQuote = resp.data.filter(items => items.quoteNo.value == quotation);

      subTotal = 0;
      visaAmount = 0;
      totalAmount = 0;
      taxAmount = 0;
      passportStampingCost = 0;
      // noOfResource = 0;
      particularQuote.map(respQuote => {
        subTotal += respQuote.subTotal.value;
        visaAmount += respQuote.visaAmount.value;
        totalAmount = (totalAmount + respQuote.totalAmount.value);
        taxAmount += respQuote.taxAmount.value;
        passportStampingCost += respQuote.passportStampingCost.value;
      });


      groupData.map((resp, i) => {
        if(resp.quoteNo.value == quotation){

          resp['subTotal'].value = subTotal;
          resp['visaAmount'].value = visaAmount;
          resp['totalAmount'].value = totalAmount;
          resp['taxAmount'].value = taxAmount;
          resp['passportStampingCost'].value = passportStampingCost;
          groups[resp.quoteNo.value] = resp;
        }
      });
      // });

    });
    Object.keys(groups).map(resp => {
      result.push(groups[resp]);
    });
    
    this.quotationList = ({ records: this.gfService.buildView(result), totalRecordsCount: resp.totalCount });
  }
  details(loopdata) {
    this.router.navigate(['quotation/view', this.gfService.encryptDecryptFun('btoa', loopdata.find(items => items.fieldKey == 'quoteNo').values.value)]);
  }
  pageEventInput:any;
  searchData:any = '';
  isNumber(val) { return typeof val === 'number'; } // To Remove empty chips
  paginationFunction(pageEvent) {
    // console.log(pageEvent)
    this.pageSize =  pageEvent.pageSize;
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    // console.log(this.apiData);
    for (let obj of this.formBuildBaseObj.forms) {
      // console.log(obj) 
      let queryBuild = '';
      this.searchDataArr.map((showField, index) => {
        // console.log(index, obj.showFields.length)
        if (index == (this.searchDataArr.length - 1)) {
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData + '%"');
        }
        else
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData + '%"') + ' OR ';
      })
      // let showFields = this.headerData.concat(this.footerData);
      if (this.apiData != undefined) {
      //  if(this.apiData)
        // console.log(queryBuild);
        this.apiData.pageNumber =  pageEvent.pageIndex + 1;
        this.apiData.limit =  pageEvent.pageSize;
          // apiData = {
          //   "formId": obj.formId,
          //   "filterString": { "searchString": queryBuild, userId: this.currentUser.id },
          //   "pageNumber": pageEvent.pageIndex + 1, "limit": pageEvent.pageSize
          // }
      } else {
          this.apiData = { "formId": obj.formId, "filterString": {}, "pageNumber": pageEvent.pageIndex + 1, "limit": pageEvent.pageSize };
      }
      // console.log(this.apiData);
      this.service.getQuotationList(this.apiData).subscribe(resp => {
        // console.log(JSON.parse(JSON.stringify(resp)), this.apiData);
        if (resp.status == 'success') {
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.quotationList = [];
          this.quotationBuild(resp);

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.quotationList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
          // this.visaListParent = [];
          // this.formListBulid(resp, obj);
          // console.log(pageEvent._pageIndex);

        }
      })

    }
  }
  searchFunction(data) {
    // console.log(data)
    this.searchData = data;
    // this.formBuildBaseObj = this.screenTB.formList(this.params.id);
    for (let obj of this.formBuildBaseObj.forms) {
      let queryBuild = '';
      this.searchDataArr.map((showField, index) => {
        // console.log(index, obj.showFields.length)
        if (index == (this.searchDataArr.length - 1)) {
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data + '%"');
        }
        else
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data + '%"') + ' OR ';
      })
      // let showFields = this.headerData.concat(this.footerData);
      if (data != '' && data != undefined) {
        if (this.apiData != undefined) {
     
          // if (this.currentUser.userType == 'CLIENT') {
            this.apiData['filterString']['searchString'] = ' AND ('+queryBuild+')';
            this.searchString['searchString'] = ' AND ('+queryBuild +')';
          // } 

          // apiData = {
          //   "formId": obj.formId,
          //   "filterString": { "searchString": queryBuild ,userId: this.currentUser.id},
          //   "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          // }
          // apiData = {
          //   "formId": obj.formId,
          //   "filterString": { "searchString": queryBuild},
          //   "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          // }

        } else {
          this.apiData = {
            "formId": obj.formId,
            "filterString": { "searchString": queryBuild},
            "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          }
          this.searchString['searchString'] = queryBuild;
          this.apiData = {
            "formId": obj.formId,
            "filterString": { "searchString": queryBuild },
            "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          }
          this.searchString['searchString'] = queryBuild;
          console.log(this.apiData)
        }
      }
      else {
        console.log(this.apiData)

        if (this.apiData != undefined) {
          if(this.apiData.filterString.searchString) {
            delete this.apiData.filterString.searchString;
            this.searchString = {};
          }
         } else {
            this.apiData = { "formId": obj.formId, "filterString": {}, "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT };
        }
      }
      this.service.getQuotationList(this.apiData).subscribe(resp => {
        console.log(resp, this.apiData);
        if (resp.status == 'success') {
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.quotationList = [];
          this.quotationBuild(resp);

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.quotationList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
          // this.formListBulid(resp, obj);
          // this.searchData = data;
        } else {
          this.quotationList.records = [];
          // this.visaListParent[0] = [];
          // this.visaListParent.map(resp =>{
          //  console.log(resp);
          //  resp = [];
          // })
        }
      })
    }
  }

}
