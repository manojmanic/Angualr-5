import { Component, OnInit, Input } from '@angular/core';
import { GlobalformService } from '../../shared/services/globalform.service';
import { ActivatedRoute, Router } from "@angular/router";
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import { MatDatepickerInputEvent } from '@angular/material/datepicker';
import { DatePipe } from '@angular/common';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { FormControl, FormGroup } from '@angular/forms';
import { Constants } from '../../constants';
import { GlobalFunctionService } from '../../shared/services/global-function.service';
import { QuestionBase } from '../../shared/models/question-base';
import { GlobalformControlService } from '../../shared/services/globalform-control.service';


@Component({
  selector: 'app-contract',
  templateUrl: './contract.component.html',
  styleUrls: ['./contract.component.scss']
})
export class ContractComponent implements OnInit {
  @Input() caseId; any;
  group: any = {};
  form: any;
  formBuildBaseObj: any;
  contractList: any = [];
  fieldList: QuestionBase<any>[] = [];
  buildData: any;
  filterFields: any = [];
  breadcrumbs: any;
  subTitle: any;
  headerData: any;
  footerData: any;
  currentUser: any;
  cusData: any = [];
  sortData: any;
  searchDataArr: any = [];
  pageSize: any;
  apiData: any;
  searchString: any = {};
  constructor(
    private service: GlobalformService,
    private route: ActivatedRoute,
    private screenTB: ScreenTemplateJsonBuilder,
    private router: Router,
    private gfService: GlobalFunctionService,
    public qcs: GlobalformControlService,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private authGuardService: AuthGuardService,
    private config: Constants
  ) {
    // let data = { "tableName": "Location", "keyValue": "dataId, countryName" }
    // this.service.getCustomList(data).subscribe(resp => {
    //   Object.keys(resp.data).map(key => {
    //     this.cusData.push({ key, value: resp.data[key] });
    //   });
    // });
  }

  onChange(data) {
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    for (let obj of this.formBuildBaseObj.forms) {
      let preSubmitEvFn = obj.eventHandler.preSubmit;
      let form = this.form;
      if (preSubmitEvFn != '') {
        const eventCalls = (this.fbbService[preSubmitEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preSubmitEvFn]) {
          let param = { formId: obj.formId, formItems: form, route: this.route, data: data, apiData: this.apiData };
          let changed = eventCalls[preSubmitEvFn](param);
          form = changed.formItems;
          this.apiData = changed.apiData
          this.apiData['pageNumber'] = 1;
          this.apiData['limit'] = this.pageSize;
          console.log(changed.apiData);
          if (Object.keys(this.searchString).length) {
            this.apiData.filterString['searchString'] = this.searchString.searchString;
          }
        }
      }
      this.service.getFormData(this.apiData).subscribe(resp => {
        // console.log(resp,this.apiData);
        if (resp.status == "success") {
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.contractList = [];
          this.contractList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.contractList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);

        } else if (resp.status == "error") {
          this.contractList.records = [];
        }
      });
    }
  }

  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    this.pageSize = this.config.PG_LIMIT_DEFAULT;
    this.currentUser = this.authGuardService.getLoginUser();
    for (let obj of this.formBuildBaseObj.forms) {
      this.apiData = { "formId": obj.formId, "filterString": {}, "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT, "languageCode": "en" };
      this.service.getFormData(this.apiData).subscribe(resp => {
        let contractList;
        if (resp.status == 'success') {
          contractList = resp.data;
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
              this.filterFields = changed.filterFields;
              this.searchDataArr = changed.searchData;
            }
          }

          this.contractList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });

          setTimeout(() => {
            this.buildData = {
              'fieldGroup': [{ 'FieldList': this.filterFields }]
            }
            console.log(this.buildData);
            let buildData = this.qcs.buildForm(this.buildData);
            this.fieldList = buildData['fields'];
            this.form = buildData['controls'];
            console.log(buildData, this.buildData, this.formBuildBaseObj.showFields);
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.contractList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
        }
      })
    }
  }

  details(loopdata) {
    this.router.navigate(['contract/view-contract', this.gfService.encryptDecryptFun('btoa', loopdata.find(items => items.fieldKey == 'dataId').values)]);
  }
  searchData: any = '';
  paginationFunction(pageEvent) {
    // console.log(pageEvent)
    this.pageSize = pageEvent.pageSize;
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    // console.log(this.apiData);
    for (let obj of this.formBuildBaseObj.forms) {
      // console.log(obj) 
      let queryBuild = '';
      this.searchDataArr.map((showField, index) => {
        // console.log(index, obj.showFields.length)
        if (index == (this.searchDataArr.length - 1)) {
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData + '%"');
        }
        else
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData + '%"') + ' OR ';
      })
      // let showFields = this.headerData.concat(this.footerData);
      if (this.apiData != undefined) {
        //  if(this.apiData)
        // console.log(queryBuild);
        this.apiData.pageNumber = pageEvent.pageIndex + 1;
        this.apiData.limit = pageEvent.pageSize;
        // apiData = {
        //   "formId": obj.formId,
        //   "filterString": { "searchString": queryBuild, userId: this.currentUser.id },
        //   "pageNumber": pageEvent.pageIndex + 1, "limit": pageEvent.pageSize
        // }
      } else {
        this.apiData = { "formId": obj.formId, "filterString": {}, "pageNumber": pageEvent.pageIndex + 1, "limit": pageEvent.pageSize };
      }
      // console.log(this.apiData);
      this.service.getFormData(this.apiData).subscribe(resp => {
        // console.log(JSON.parse(JSON.stringify(resp)), this.apiData);
        if (resp.status == 'success') {
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.contractList = [];
          this.contractList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.contractList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
          // this.visaListParent = [];
          // this.formListBulid(resp, obj);
          // console.log(pageEvent._pageIndex);

        }
      })

    }
  }
  searchFunction(data) {
    // console.log(data)
    this.searchData = data;
    // this.formBuildBaseObj = this.screenTB.formList(this.params.id);
    for (let obj of this.formBuildBaseObj.forms) {
      let queryBuild = '';
      this.searchDataArr.map((showField, index) => {
        // console.log(index, obj.showFields.length)
        if (index == (this.searchDataArr.length - 1)) {
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data + '%"');
        }
        else
          queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data + '%"') + ' OR ';
      })
      // let showFields = this.headerData.concat(this.footerData);
      if (data != '' && data != undefined) {
        if (this.apiData != undefined) {

          // if (this.currentUser.userType == 'CLIENT') {
          this.apiData.filterString['searchString'] = queryBuild;
          this.searchString['searchString'] = queryBuild;
          // }
          // apiData = {
          //   "formId": obj.formId,
          //   "filterString": { "searchString": queryBuild ,userId: this.currentUser.id},
          //   "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          // }
          // apiData = {
          //   "formId": obj.formId,
          //   "filterString": { "searchString": queryBuild},
          //   "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          // }

        } else {
          this.apiData = {
            "formId": obj.formId,
            "filterString": { "searchString": queryBuild },
            "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          }
          this.searchString['searchString'] = queryBuild;
          this.apiData = {
            "formId": obj.formId,
            "filterString": { "searchString": queryBuild },
            "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
          }
          this.searchString['searchString'] = queryBuild;
        }
      }
      else {
        if (this.apiData != undefined) {
          if (this.apiData.filterString.searchString) {
            delete this.apiData.filterString.searchString;
            this.searchString = {};
          }
        } else {
          this.apiData = { "formId": obj.formId, "filterString": {}, "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT };
        }
      }
      // console.log(this.apiData)
      this.service.getFormData(this.apiData).subscribe(resp => {
        console.log(resp, this.apiData);
        if (resp.status == 'success') {
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.contractList = [];
          this.contractList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, formItems: this.form, rawData: this.contractList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
          // this.formListBulid(resp, obj);
          // this.searchData = data;
        } else {
          this.contractList.records = [];
          // this.visaListParent[0] = [];
          // this.visaListParent.map(resp =>{
          //  console.log(resp);
          //  resp = [];
          // })
        }
      })
    }
  }
}
