import { Component, OnInit } from '@angular/core';
import { GlobalformService } from '../shared/services/globalform.service';
import { ActivatedRoute } from "@angular/router";
import { ScreenTemplateJsonBuilder } from '../shared/common/screentemplate-jsonbuilder';
import { AuthGuardService } from '../shared/guard/auth-guard.service';
import { FormBuildFunctionsService } from '../shared/common/form-build-functions.service';
import { FormBuildBaseService } from '../forms/formbuilds/form-build-base.service';

@Component({
  selector: 'app-totallist',
  templateUrl: './totallist.component.html',
  styleUrls: ['./totallist.component.scss']
})
export class TotallistComponent implements OnInit {
  
  formBuildBaseObj: any;
  showFieldsList: any;
  form_title:any;
  breadcrumbs:any;
  innerTemplate:any;
  subTitle:any;
  userType:any;
  constructor(
    private authGuardService: AuthGuardService,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private screenTB: ScreenTemplateJsonBuilder

  ) {
    if(authGuardService.getLoginUser() !=null) {
      this.userType = authGuardService.getLoginUser().userType;
    }
    this.formBuildBaseObj = this.screenTB.formView('secondmentList');
    this.showFieldsList = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    
    this.form_title = this.formBuildBaseObj.title;
    let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId };
        let changed = eventCalls[preBuildEvFn](param);
        this.innerTemplate = changed.innerTemplate;
        this.breadcrumbs = changed.breadcrumbs;
        this.subTitle = changed.subTitle;
      }
    }
  }

  ngOnInit() {
  }
  quotation() {
    
  }
}
