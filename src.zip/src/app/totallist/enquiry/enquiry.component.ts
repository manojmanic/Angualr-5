import { Component, OnInit,Input } from '@angular/core';
import { GlobalformService } from '../../shared/services/globalform.service';
import { ActivatedRoute } from "@angular/router";
import { ScreenTemplateJsonBuilder } from '../../shared/common/screentemplate-jsonbuilder';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import { DatePipe } from '@angular/common';
import { FormBuildFunctionsService } from '../../shared/common/form-build-functions.service';
import { FormBuildBaseService } from '../../forms/formbuilds/form-build-base.service';
import { AuthGuardService } from '../../shared/guard/auth-guard.service';
import { Constants } from '../../constants';
import { GlobalFunctionService } from '../../shared/services/global-function.service';
@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.scss']
})
export class EnquiryComponent implements OnInit {
  @Input()caseId:any;

  formBuildBaseObj:any;
  enquiryList:any = [];
  breadcrumbs:any;
  subTitle:any;
  headerData: any;
  footerData: any;
  currentUser:any;
  searchDataArr:any = [];
  // fieldList: QuestionBase<any>[] = [];
  buildData: any;
  // filterFields: any = [];
  constructor(
    private service:GlobalformService,
    private route: ActivatedRoute,
    private screenTB: ScreenTemplateJsonBuilder,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private gfService: GlobalFunctionService,
    private authGuardService: AuthGuardService,
    private config: Constants
  ) { }

  ngOnInit() {
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    
    this.currentUser = this.authGuardService.getLoginUser();
    for (let obj of this.formBuildBaseObj.forms) {
      let apiData
      apiData = { "formId":obj.formId, "filterString": { },"pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT, "languageCode": "en" };
    this.service.getFormData(apiData).subscribe(resp=>{
      let enquiryList;
      
      if(resp.status == 'success') {
      enquiryList = resp.data;
      let enquiryListArr = [];
      let preBuildEvFn = obj.eventHandler.preBuild;
      if (preBuildEvFn != '') {
        const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
        if (eventCalls[preBuildEvFn]) {
          let param = { formId: obj.formId,enquiryData:resp.data };
          let changed = eventCalls[preBuildEvFn](param);
          this.breadcrumbs = changed.breadcrumbs;
          this.subTitle = changed.subTitle;
          this.headerData = changed.headerData;
          this.footerData = changed.footerData;
          this.searchDataArr = changed.searchData;
          // console.log(this.searchDataArr)
        }
      }

      this.enquiryList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });


      setTimeout(() => {
        // this.buildData = {
        //   'fieldGroup': [{ 'FieldList': this.filterFields }]
        // }
        // console.log(this.buildData);
        // let buildData = this.qcs.buildForm(this.buildData);
        // this.fieldList = buildData['fields'];
        // this.form = buildData['controls'];
        let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
        if (postBuildEvFn != '') {
          const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
          if (eventCalls[postBuildEvFn]) {
            let param = { formId: obj.formId, rawData: this.enquiryList };
            let changed = eventCalls[postBuildEvFn](param);
          }
        }
      }, this.config.FORM_LOADING_SEC);
      
    }
    })
  }
 
  
  }
  
  pageEventInput:any;
  searchData:any = '';
  isNumber(val) { return typeof val === 'number'; } // To Remove empty chips
  paginationFunction(pageEvent) {
    let apiData;
    this.formBuildBaseObj = this.screenTB.formList(this.caseId);
    for (let obj of this.formBuildBaseObj.forms) {
      // console.log(obj) 
      // let showFields = this.headerData.concat(this.footerData);
      if (this.searchData != '') {
        let queryBuild = '';
        this.searchDataArr.map((showField, index) => {
          // console.log(index, obj.showFields.length)
          if (index == (this.searchDataArr.length - 1)) {
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData + '%"');
          }
          else
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + this.searchData + '%"') + ' OR ';
        })
        if (this.currentUser.userType == 'CLIENT')
        apiData = {
          "formId": obj.formId,
          "filterString": { "searchString": queryBuild},
          "pageNumber": pageEvent.pageIndex + 1, "limit": pageEvent.pageSize
        }
        else
        apiData = {
          "formId": obj.formId,
          "filterString": { "searchString": queryBuild },
          "pageNumber": pageEvent.pageIndex + 1, "limit": pageEvent.pageSize
        }
      } else {
        apiData = { "formId": obj.formId, "filterString": {}, "pageNumber": pageEvent.pageIndex + 1, "limit": pageEvent.pageSize };
      }
      this.service.getFormData(apiData).subscribe(resp => {
        // console.log(JSON.parse(JSON.stringify(resp)),apiData);
        if (resp.status == 'success') {
          // this.enquiryBuild(resp);
          // this.visaListParent = [];
          // this.formListBulid(resp, obj);
          // console.log(pageEvent._pageIndex);
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.enquiryList = [];
          this.enquiryList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, rawData: this.enquiryList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
        }
      })
     
    }
  }
  searchFunction(data) {
    this.searchData = data;
    // this.formBuildBaseObj = this.screenTB.formList(this.params.id);
    let apiData;
    for (let obj of this.formBuildBaseObj.forms) {
      let queryBuild = '';
      // let showFields = this.headerData.concat(this.footerData);
      if (data != '' && data != undefined) {
        this.searchDataArr.map((showField, index) => {
          // console.log(index, obj.showFields.length)
          if (index == (this.searchDataArr.length - 1)) {
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data + '%"');
          }
          else
            queryBuild = queryBuild + showField + ' LIKE ' + ('"%' + data + '%"') + ' OR ';
        })
        if (this.currentUser.userType == 'CLIENT')
        apiData = {
          "formId": obj.formId,
          "filterString": { "searchString": queryBuild },
          "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
        }
        else 
        apiData = {
          "formId": obj.formId,
          "filterString": { "searchString": queryBuild},
          "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT
        }
        
      } else {
        apiData = { "formId": obj.formId, "filterString": {}, "pageNumber": 1, "limit": this.config.PG_LIMIT_DEFAULT };
      }
      this.service.getFormData(apiData).subscribe(resp => {
        // console.log(resp,apiData);
        if (resp.status == 'success') {
          let preBuildEvFn = obj.eventHandler.preBuild;
          if (preBuildEvFn != '') {
            const eventCalls = (this.fbbService[preBuildEvFn]) ? this.fbbService : this.fbfService;
            if (eventCalls[preBuildEvFn]) {
              let param = { formId: obj.formId, resp: resp.data };
              let changed = eventCalls[preBuildEvFn](param);
              this.breadcrumbs = changed.breadcrumbs;
              this.subTitle = changed.subTitle;
              this.headerData = changed.headerData;
              this.footerData = changed.footerData;
            }
          }

          this.enquiryList = [];
          this.enquiryList = ({ records: this.gfService.buildView(resp.data), totalRecordsCount: resp.totalCount });

          setTimeout(() => {
            let postBuildEvFn = this.formBuildBaseObj.eventHandler.postBuild;
            if (postBuildEvFn != '') {
              const eventCalls = (this.fbbService[postBuildEvFn]) ? this.fbbService : this.fbfService;
              if (eventCalls[postBuildEvFn]) {
                let param = { formId: obj.formId, rawData: this.enquiryList };
                let changed = eventCalls[postBuildEvFn](param);
              }
            }
          }, this.config.FORM_LOADING_SEC);
          // this.formListBulid(resp, obj);
          // this.searchData = data;
        } else {
          this.enquiryList.records = [];
          // this.visaListParent[0] = [];
          // this.visaListParent.map(resp =>{
          //  console.log(resp);
          //  resp = [];
          // })
        }
      })
    }
  }

}
