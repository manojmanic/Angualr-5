import { Component, OnInit } from '@angular/core';
import { GlobalformService } from "../shared/services/globalform.service";
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { FormBuildFunctionsService } from '../shared/common/form-build-functions.service';
import { FormBuildBaseService } from '../forms/formbuilds/form-build-base.service';
import { ScreenTemplateJsonBuilder } from '../shared/common/screentemplate-jsonbuilder';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
  
  formBuildBaseObj: any;
  showFieldsList: any;
  form_title:any;
  breadcrumbs:any;
  innerTemplate:any;
  subTitle:any;

  constructor(
    private service: GlobalformService,
    private snackBar: MatSnackBar,
    private fbfService: FormBuildFunctionsService,
    private fbbService: FormBuildBaseService,
    private activateRoute: ActivatedRoute,
    private screenTB: ScreenTemplateJsonBuilder,
    private router: Router
  ) {
    this.formBuildBaseObj = this.screenTB.formView('payment');
    this.showFieldsList = Array.from(Object.keys(this.formBuildBaseObj.showFields));
    
    this.form_title = this.formBuildBaseObj.title;
    let preBuildEvFn = this.formBuildBaseObj.eventHandler.preBuild;
    if (preBuildEvFn != '') {
      const eventCalls = (fbbService[preBuildEvFn]) ? fbbService : fbfService;
      if (eventCalls[preBuildEvFn]) {
        let param = { formId: this.formBuildBaseObj.formId};
        let changed = eventCalls[preBuildEvFn](param);
        this.innerTemplate = changed.innerTemplate;
        this.breadcrumbs = changed.breadcrumbs;
        this.subTitle = changed.subTitle;
      }
    }
   }

  ngOnInit() {
  }
  paynow() {

    this.service.generateContract(this.activateRoute.params['value'].id).subscribe(resp => {
      console.log(resp);
      if (resp.status == "success") {
        this.openSnackBar(resp);
        let redirectTo="successScreen";
        let redirectData = 'payment'
        let contractId;
        this.router.navigate([redirectTo], { queryParams: {data: redirectData,contractId:resp.contractId}});
         
      }
      else {
        this.openSnackBar({ message: 'Something went wrong. Please try again later.', status: 'error' });
      }
    })
  }

  openSnackBar(resp) {
    var message = resp.message;
    var action = '';
    if (resp.status == 'success') {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['success']
      });
    }
    else {
      this.snackBar.open(message, action, {
        duration: 1000,
        extraClasses: ['error']
      });
    }

  }
  onSubmit(){}
}
